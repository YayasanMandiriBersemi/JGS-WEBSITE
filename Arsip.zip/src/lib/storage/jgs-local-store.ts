import { TradeJournalItem } from '@/lib/math/journal-analytics';

export interface OnboardingDossier {
  completedAt: string;
  capitalTier: 'DEMO' | 'MICRO_10_25' | 'BUILDER_25_100' | 'PLUS_100';
  experienceLevel: 'BEGINNER' | 'TRIED_DEMO' | 'ACTIVE_MICRO' | 'ALGO_CURIOUS';
  primaryInstrument: 'XAUUSD' | 'FOREX_MAJORS' | 'BOTH';
  primaryChallenge: 'SIZING' | 'EMOTION' | 'EXECUTION' | 'EA_SETUP';
  recommendedCapitalUsd: number;
  recommendedCapitalUsc: number;
  recommendedRiskPercent: number;
  recommendedDailyLossCapPercent: number;
  recommendedTrackSlug: string;
  recommendedTrackTitle: string;
  recommendedScenarioId: string;
  jeyPersonalBrief: string;
}

export interface SavedRiskRulePreset {
  id: string;
  name: string;
  depositUsd: number;
  accountMode: 'CENT_USC' | 'STANDARD_USD';
  instrument: 'XAUUSD' | 'EURUSD' | 'GBPUSD' | 'USDJPY';
  riskPercent: number;
  dailyMaxLossPercent: number;
  defaultStopLossPoints: number;
  createdAt: string;
}

export interface StrategistUserSession {
  id: string;
  email: string;
  displayName: string;
  role: 'GUEST' | 'STRATEGIST';
  signedInAt: string;
}

const KEYS = {
  ONBOARDING: 'jgs_onboarding_dossier_v1',
  ACADEMY_COMPLETED: 'jgs_academy_completed_slugs_v1',
  JOURNAL_ENTRIES: 'jgs_trader_journal_entries_v1',
  RISK_PRESETS: 'jgs_saved_risk_presets_v1',
  MT5_CHECKLIST: 'jgs_mt5_setup_checklist_v1',
  USER_SESSION: 'jgs_strategist_session_v1'
};

function isBrowser(): boolean {
  return typeof window !== 'undefined' && typeof window.localStorage !== 'undefined';
}

export function loadOnboardingDossier(): OnboardingDossier | null {
  if (!isBrowser()) return null;
  try {
    const raw = window.localStorage.getItem(KEYS.ONBOARDING);
    return raw ? (JSON.parse(raw) as OnboardingDossier) : null;
  } catch {
    return null;
  }
}

export function saveOnboardingDossier(dossier: OnboardingDossier): void {
  if (!isBrowser()) return;
  try {
    window.localStorage.setItem(KEYS.ONBOARDING, JSON.stringify(dossier));
  } catch {
    // Ignore storage quota errors
  }
}

export function loadCompletedLessonSlugs(): string[] {
  if (!isBrowser()) return [];
  try {
    const raw = window.localStorage.getItem(KEYS.ACADEMY_COMPLETED);
    return raw ? (JSON.parse(raw) as string[]) : [];
  } catch {
    return [];
  }
}

export function toggleCompletedLessonSlug(slug: string): string[] {
  if (!isBrowser()) return [];
  const current = loadCompletedLessonSlugs();
  const next = current.includes(slug)
    ? current.filter((item) => item !== slug)
    : [...current, slug];
  try {
    window.localStorage.setItem(KEYS.ACADEMY_COMPLETED, JSON.stringify(next));
  } catch {
    // Ignore
  }
  return next;
}

export function markLessonCompleted(slug: string): string[] {
  if (!isBrowser()) return [];
  const current = loadCompletedLessonSlugs();
  if (current.includes(slug)) return current;
  const next = [...current, slug];
  try {
    window.localStorage.setItem(KEYS.ACADEMY_COMPLETED, JSON.stringify(next));
  } catch {
    // Ignore
  }
  return next;
}

export const EDUCATIONAL_SAMPLE_JOURNAL_ENTRIES: TradeJournalItem[] = [
  {
    id: 'sample-1',
    tradedAt: '2026-11-06 15:30',
    instrument: 'XAUUSD',
    accountMode: 'CENT_USC',
    direction: 'LONG',
    entryPrice: 2642.5,
    stopLoss: 2640.0,
    takeProfit: 2648.0,
    exitPrice: 2648.0,
    lotSize: 0.1,
    realizedPnl: 55.0,
    realizedRMultiple: 2.2,
    setupTag: 'London Sweep + Displacement',
    emotionTag: 'DISCIPLINED',
    ruleFollowedStopLoss: true,
    ruleProperLotSize: true,
    ruleWaitedConfirmation: true,
    ruleWithinDailyLimit: true,
    notes: 'Waited for Asian low liquidity sweep to close back inside range before entering 0.10 Cent Lot (25 USC risk).'
  },
  {
    id: 'sample-2',
    tradedAt: '2026-11-07 20:15',
    instrument: 'EURUSD',
    accountMode: 'CENT_USC',
    direction: 'SHORT',
    entryPrice: 1.084,
    stopLoss: 1.0855,
    takeProfit: 1.081,
    exitPrice: 1.0855,
    lotSize: 0.16,
    realizedPnl: -24.0,
    realizedRMultiple: -1.0,
    setupTag: 'NY Session Pullback',
    emotionTag: 'CALM',
    ruleFollowedStopLoss: true,
    ruleProperLotSize: true,
    ruleWaitedConfirmation: true,
    ruleWithinDailyLimit: true,
    notes: 'Normal planned -1R stop loss hit. Kept lot size exact and did not re-enter out of frustration.'
  },
  {
    id: 'sample-3',
    tradedAt: '2026-11-08 16:05',
    instrument: 'XAUUSD',
    accountMode: 'CENT_USC',
    direction: 'LONG',
    entryPrice: 2655.0,
    stopLoss: 2652.0,
    takeProfit: 2661.0,
    exitPrice: 2651.4,
    lotSize: 0.15,
    realizedPnl: -54.0,
    realizedRMultiple: -1.2,
    setupTag: 'Unconfirmed Breakout Chase',
    emotionTag: 'FOMO',
    ruleFollowedStopLoss: false,
    ruleProperLotSize: false,
    ruleWaitedConfirmation: false,
    ruleWithinDailyLimit: true,
    notes: 'Chased green candle before 15m close and widened stop by 60 points. Logged honestly to audit FOMO leak.'
  },
  {
    id: 'sample-4',
    tradedAt: '2026-11-09 15:45',
    instrument: 'GBPUSD',
    accountMode: 'CENT_USC',
    direction: 'LONG',
    entryPrice: 1.292,
    stopLoss: 1.29,
    takeProfit: 1.297,
    exitPrice: 1.297,
    lotSize: 0.12,
    realizedPnl: 60.0,
    realizedRMultiple: 2.5,
    setupTag: 'London Open Liquidity Reclaim',
    emotionTag: 'DISCIPLINED',
    ruleFollowedStopLoss: true,
    ruleProperLotSize: true,
    ruleWaitedConfirmation: true,
    ruleWithinDailyLimit: true,
    notes: 'Clean 1:2.5 R:R execution. Covered previous day losses and restored positive expectancy.'
  }
];

export function loadJournalEntries(): TradeJournalItem[] {
  if (!isBrowser()) return [];
  try {
    const raw = window.localStorage.getItem(KEYS.JOURNAL_ENTRIES);
    if (!raw) return [];
    return JSON.parse(raw) as TradeJournalItem[];
  } catch {
    return [];
  }
}

export function saveJournalEntries(entries: TradeJournalItem[]): void {
  if (!isBrowser()) return;
  try {
    window.localStorage.setItem(KEYS.JOURNAL_ENTRIES, JSON.stringify(entries));
  } catch {
    // Ignore
  }
}

export function loadRiskPresets(): SavedRiskRulePreset[] {
  if (!isBrowser()) return [];
  try {
    const raw = window.localStorage.getItem(KEYS.RISK_PRESETS);
    return raw ? (JSON.parse(raw) as SavedRiskRulePreset[]) : [];
  } catch {
    return [];
  }
}

export function saveRiskPreset(preset: SavedRiskRulePreset): SavedRiskRulePreset[] {
  if (!isBrowser()) return [];
  const existing = loadRiskPresets();
  const next = [preset, ...existing.filter((p) => p.id !== preset.id)].slice(0, 10);
  try {
    window.localStorage.setItem(KEYS.RISK_PRESETS, JSON.stringify(next));
  } catch {
    // Ignore
  }
  return next;
}

export function loadStrategistSession(): StrategistUserSession | null {
  if (!isBrowser()) return null;
  try {
    const raw = window.localStorage.getItem(KEYS.USER_SESSION);
    return raw ? (JSON.parse(raw) as StrategistUserSession) : null;
  } catch {
    return null;
  }
}

export function saveStrategistSession(session: StrategistUserSession | null): void {
  if (!isBrowser()) return;
  try {
    if (!session) {
      window.localStorage.removeItem(KEYS.USER_SESSION);
    } else {
      window.localStorage.setItem(KEYS.USER_SESSION, JSON.stringify(session));
    }
  } catch {
    // Ignore
  }
}

export function loadMt5Checklist(defaultIds: string[] = ['mt5-step-1']): string[] {
  if (!isBrowser()) return defaultIds;
  try {
    const raw = window.localStorage.getItem(KEYS.MT5_CHECKLIST);
    return raw ? (JSON.parse(raw) as string[]) : defaultIds;
  } catch {
    return defaultIds;
  }
}

export function saveMt5Checklist(stepIds: string[]): void {
  if (!isBrowser()) return;
  try {
    window.localStorage.setItem(KEYS.MT5_CHECKLIST, JSON.stringify(stepIds));
  } catch {
    // Ignore
  }
}
