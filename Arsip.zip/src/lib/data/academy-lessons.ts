import type { Locale } from '@/i18n/config';

export interface AcademyTrack {
  id: string;
  trackNumber: string;
  slug: string;
  title: string;
  titleId?: string;
  subtitle: string;
  subtitleId?: string;
  targetAudience: string;
  targetAudienceId?: string;
  estimatedMinutes: number;
}

export interface AcademyLesson {
  slug: string;
  trackId: string;
  lessonNumber: string;
  title: string;
  titleId?: string;
  durationMinutes: number;
  difficulty: 'BEGINNER' | 'INTERMEDIATE' | 'QUANT';
  summary: string;
  summaryId?: string;
  plainEnglishSections: {
    heading: string;
    body: string;
  }[];
  plainEnglishSectionsId?: {
    heading: string;
    body: string;
  }[];
  technicalSections: {
    heading: string;
    body: string;
    formulaOrSpec?: string;
  }[];
  technicalSectionsId?: {
    heading: string;
    body: string;
    formulaOrSpec?: string;
  }[];
  microCapitalCaseStudy: {
    title: string;
    standardAccountOutcome: string;
    centAccountOutcome: string;
  };
  microCapitalCaseStudyId?: {
    title: string;
    standardAccountOutcome: string;
    centAccountOutcome: string;
  };
  jeyStreetRule: string;
  jeyStreetRuleId?: string;
  relatedTerms: string[];
  quiz: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
  quizId?: {
    question: string;
    options: string[];
    correctIndex: number;
    explanation: string;
  };
}

export const ACADEMY_TRACKS: AcademyTrack[] = [
  {
    id: 'track-01',
    trackNumber: '01',
    slug: 'micro-capital-foundations',
    title: 'Micro-Capital Foundations & Broker Specifications',
    titleId: 'Fondasi Modal Mikro & Spesifikasi Broker',
    subtitle:
      'Why small-capital accounts require careful contract-size verification, and how Cent denomination interacts with broker symbol rules.',
    subtitleId:
      'Mengapa akun bermodal kecil membutuhkan verifikasi ukuran kontrak yang teliti, serta bagaimana denominasi Cent bekerja dengan spesifikasi simbol broker.',
    targetAudience: 'Complete Beginners & $10–$100 Traders',
    targetAudienceId: 'Pemula & Trader Modal $10–$100',
    estimatedMinutes: 25,
  },
  {
    id: 'track-02',
    trackNumber: '02',
    slug: 'gold-and-fx-mechanics',
    title: 'Gold (XAUUSD) & Forex Session Structure',
    titleId: 'Struktur Sesi Emas (XAUUSD) & Forex',
    subtitle:
      'How Asian consolidation, London liquidity sweeps, and New York volatility shape intraday price delivery.',
    subtitleId:
      'Bagaimana konsolidasi sesi Asia, sapuan likuiditas London, dan volatilitas New York membentuk pergerakan harga harian.',
    targetAudience: 'Gold & Major FX Traders',
    targetAudienceId: 'Trader Emas & Pasangan Forex Utama',
    estimatedMinutes: 30,
  },
  {
    id: 'track-03',
    trackNumber: '03',
    slug: 'risk-engineering-and-survival',
    title: 'Risk Engineering & Drawdown Survival Math',
    titleId: 'Rekayasa Risiko & Matematika Pemulihan Drawdown',
    subtitle:
      'Asymmetric Risk-to-Reward, nonlinear drawdown recovery curves, and daily equity circuit breakers.',
    subtitleId:
      'Rasio Risk-to-Reward asimetris, kurva pemulihan drawdown non-linear, dan pembatas kerugian harian (circuit breaker).',
    targetAudience: 'All Retail Strategists',
    targetAudienceId: 'Seluruh Trader Ritel',
    estimatedMinutes: 28,
  },
  {
    id: 'track-04',
    trackNumber: '04',
    slug: 'mt5-and-quant-literacy',
    title: 'MT5 Execution & Algorithmic Literacy',
    titleId: 'Eksekusi MT5 & Literasi Algoritmik',
    subtitle:
      'Order mechanics, how Expert Advisors (EAs) process ticks, and how to spot high-risk martingale grids.',
    subtitleId:
      'Mekanisme order, cara Expert Advisor (EA) memproses data tick, dan cara mengenali risiko sistem martingale/grid.',
    targetAudience: 'MT5 Users & System Builders',
    targetAudienceId: 'Pengguna MT5 & Pembangun Sistem',
    estimatedMinutes: 32,
  },
];

export const ACADEMY_LESSONS: AcademyLesson[] = [
  {
    slug: 'why-small-accounts-blow-up',
    trackId: 'track-01',
    lessonNumber: '1.1',
    title: 'Why Small Accounts Struggle: The Minimum Lot & Contract Size Trap',
    titleId: 'Mengapa Akun Kecil Rentan Kalah: Jebakan Lot Minimum & Ukuran Kontrak',
    durationMinutes: 8,
    difficulty: 'BEGINNER',
    summary:
      'Understand how broker minimum volume and contract specifications can force disproportionate risk on a small balance if not checked before trading.',
    summaryId:
      'Pahami bagaimana volume minimum dan spesifikasi kontrak broker dapat memaksa risiko yang terlalu besar pada saldo kecil jika tidak diperiksa sebelum entry.',
    plainEnglishSections: [
      {
        heading: 'The Wholesale Package Problem',
        body: 'Imagine walking into a wholesale store with $25 in your pocket to buy coffee, but the store only sells coffee in large crates. Even if you only want a small cup, the minimum order rule forces you to commit a large portion of your wallet. That is what happens when your account balance is too small for the broker’s minimum contract size.',
      },
      {
        heading: 'Why 0.01 Lot Depends on the Symbol Specification',
        body: 'Beginners see "0.01 lot" in MetaTrader 5 and assume the risk is tiny. On a standard 100-ounce Gold (XAUUSD) contract, 0.01 lot controls 1 Troy Ounce of Gold. Every $1.00 move in Gold price changes your equity by $1.00. If your stop-loss is $3.00 wide, even the smallest 0.01 lot risks $3.00 (12% of a $25 balance). Always check the symbol contract specification in MT5 before placing a trade.',
      },
    ],
    plainEnglishSectionsId: [
      {
        heading: 'Masalah Pembelian Grosir pada Modal Kecil',
        body: 'Bayangkan Anda masuk ke toko grosir dengan uang $25 untuk membeli kopi, tetapi toko tersebut hanya menjual kopi dalam peti besar. Walaupun Anda hanya ingin mencoba sedikit, aturan pembelian minimum memaksa Anda mempertaruhkan sebagian besar uang di dompet. Itulah yang terjadi ketika saldo akun terlalu kecil dibandingkan ukuran kontrak minimum broker.',
      },
      {
        heading: 'Mengapa Risiko 0.01 Lot Bergantung pada Spesifikasi Simbol',
        body: 'Pemula sering melihat angka "0.01 lot" di MetaTrader 5 dan mengira risikonya pasti kecil. Pada kontrak emas (XAUUSD) standar 100 troy ons, 0.01 lot mengendalikan 1 troy ons emas. Setiap perubahan harga $1,00 mengubah ekuitas sebesar $1,00. Jika jarak stop-loss Anda $3,00, maka lot terkecil 0.01 sekalipun mempertaruhkan $3,00 (12% dari modal $25). Selalu periksa spesifikasi kontrak simbol di MT5 sebelum membuka posisi.',
      },
    ],
    technicalSections: [
      {
        heading: 'Contract Specification vs. Account Equity',
        body: 'On a standard 100 Troy Ounce XAUUSD specification, 0.01 lot equals 1 Troy Ounce ($1.00 PnL per $1.00 price move). However, contract sizes, tick values, and minimum volumes vary across brokers and account types. Traders must calculate minimum-lot risk before executing.',
        formulaOrSpec:
          'Min Lot Risk (%) = ((Stop_Distance / Tick_Size) × Tick_Value_Per_Lot × Min_Lot) / Equity × 100',
      },
      {
        heading: 'Rejecting Trades That Exceed Your Risk Cap',
        body: 'When the risk produced by the broker’s minimum lot exceeds your personal risk budget (for example, 1% to 2% per trade), you must reject the trade or widen capital/adjust to an account specification with smaller contract notional rather than rounding up volume.',
      },
    ],
    technicalSectionsId: [
      {
        heading: 'Spesifikasi Kontrak vs Ekuitas Akun',
        body: 'Pada spesifikasi XAUUSD standar 100 troy ons, 0.01 lot setara dengan 1 troy ons ($1,00 untung/rugi untuk setiap gerak harga $1,00). Namun, ukuran kontrak, nilai tick, dan volume minimum berbeda-beda antar broker dan jenis akun. Trader wajib menghitung risiko lot minimum sebelum mengeksekusi order.',
        formulaOrSpec:
          'Risiko Lot Min (%) = ((Jarak_Stop / Ukuran_Tick) × Nilai_Tick_Per_Lot × Lot_Min) / Ekuitas × 100',
      },
      {
        heading: 'Menolak Transaksi yang Melampaui Batas Risiko',
        body: 'Apabila risiko dari lot minimum broker melebihi anggaran risiko Anda (misalnya 1% hingga 2% per transaksi), Anda wajib menolak transaksi tersebut dan tidak boleh memaksakan entry dengan membulatkan lot ke atas.',
      },
    ],
    microCapitalCaseStudy: {
      title: '$25 Balance Trading XAUUSD with a $2.50 Stop Distance',
      standardAccountOutcome:
        'On a 100 oz/lot USD contract, 0.01 minimum lot risks $2.50 USD (10.0% of the $25 balance) on a single trade.',
      centAccountOutcome:
        'On a micro-scaled Cent specification (2,500 USC balance with 1 oz/lot Cent symbol), risk can be sized down to 25–50 USC ($0.25–$0.50 USD, or 1%–2%) after verifying the broker’s contract rules.',
    },
    microCapitalCaseStudyId: {
      title: 'Saldo $25 Trading XAUUSD dengan Jarak Stop-Loss $2,50',
      standardAccountOutcome:
        'Pada kontrak standar 100 oz/lot USD, lot minimum 0.01 mempertaruhkan $2,50 USD (10,0% dari saldo $25) dalam satu transaksi.',
      centAccountOutcome:
        'Pada spesifikasi simbol Cent berkontrak mikro (saldo 2.500 USC dengan simbol Cent 1 oz/lot), risiko dapat disesuaikan menjadi 25–50 USC ($0,25–$0,50 USD atau 1%–2%) setelah memverifikasi aturan kontrak broker.',
    },
    jeyStreetRule:
      'Always check the broker symbol specification before sizing a trade. If the minimum lot risks more than your planned risk limit, step back and reject the trade.',
    jeyStreetRuleId:
      'Selalu periksa spesifikasi simbol broker sebelum menghitung ukuran lot. Jika lot minimum melampaui batas risiko yang Anda rencanakan, batalkan rencana transaksi tersebut.',
    relatedTerms: ['cent-account', 'lot-size', 'stop-loss', 'risk-per-trade'],
    quiz: {
      question:
        'On a $25 Standard Account (100 oz/lot Gold contract), if you place a 0.01 lot trade on XAUUSD with a $3.00 stop loss, what percentage of your account is at risk?',
      options: ['1.0% ($0.25)', '3.0% ($0.75)', '12.0% ($3.00)', '0.3% ($0.07)'],
      correctIndex: 2,
      explanation:
        'At 0.01 lot on a 100 oz Gold contract, every $1.00 price move equals $1.00 USD. A $3.00 stop risks $3.00, which is 12% of a $25 account.',
    },
    quizId: {
      question:
        'Pada Akun Standar $25 (kontrak Emas 100 oz/lot), jika Anda membuka posisi 0.01 lot pada XAUUSD dengan jarak stop-loss $3,00, berapa persen saldo akun yang dipertaruhkan?',
      options: ['1,0% ($0,25)', '3,0% ($0,75)', '12,0% ($3,00)', '0,3% ($0,07)'],
      correctIndex: 2,
      explanation:
        'Pada 0.01 lot kontrak emas 100 oz, setiap pergerakan harga $1,00 bernilai $1,00 USD. Jarak stop-loss $3,00 mempertaruhkan $3,00 atau 12% dari modal $25.',
    },
  },
  {
    slug: 'how-cent-accounts-work',
    trackId: 'track-01',
    lessonNumber: '1.2',
    title: 'How Cent Accounts Work: Denomination (USC) vs. Broker Contract Size',
    titleId: 'Cara Kerja Akun Cent: Perbedaan Denominasi (USC) vs Ukuran Kontrak Broker',
    durationMinutes: 9,
    difficulty: 'BEGINNER',
    summary:
      'Learn how US Cent (USC) denomination converts $1 into 100 USC—and why you must still verify whether your broker reduces the symbol contract size.',
    summaryId:
      'Pelajari bagaimana denominasi US Cent (USC) mengubah $1 menjadi 100 USC—serta mengapa Anda tetap wajib memeriksa apakah broker mengecilkan ukuran kontrak simbol.',
    plainEnglishSections: [
      {
        heading: 'What Does USC Mean in MetaTrader 5?',
        body: 'USC stands for United States Cents. Since there are 100 cents in 1 dollar, depositing $25 USD into a Cent Account displays a balance of 2,500 USC in your MT5 terminal. Every 100 USC equals $1.00 USD of real money.',
      },
      {
        heading: 'CRITICAL: Cent Denomination Does Not Automatically Mean 100x Smaller Contracts',
        body: 'Never assume every Cent account has the same contract size! Changing the balance unit from USD to USC is only a currency denomination change. While many brokers pair Cent accounts with micro-scaled symbol contracts (100x smaller than standard), some brokers keep the standard contract size on Gold or certain symbols. Always right-click the symbol in MT5 Market Watch and select "Specification" to inspect Contract Size, Tick Value, and Minimum Volume.',
      },
    ],
    plainEnglishSectionsId: [
      {
        heading: 'Apa Arti USC di MetaTrader 5?',
        body: 'USC adalah singkatan dari United States Cents (Sen Dolar AS). Karena 1 dolar terdiri dari 100 sen, menyetorkan $25 USD ke Akun Cent akan menampilkan saldo sebesar 2.500 USC di terminal MT5 Anda. Setiap 100 USC bernilai $1,00 USD uang sungguhan.',
      },
      {
        heading: 'PENTING: Denominasi Cent Tidak Otomatis Berarti Ukuran Kontrak 100x Lebih Kecil',
        body: 'Jangan pernah berasumsi bahwa semua akun Cent memiliki ukuran kontrak yang sama! Mengubah satuan saldo dari USD ke USC hanyalah perubahan denominasi saldo. Meskipun banyak broker memasangkan akun Cent dengan kontrak simbol mikro (100x lebih kecil dari standar), sebagian broker tetap menggunakan ukuran kontrak standar pada Emas atau simbol tertentu. Selalu klik kanan simbol di Market Watch MT5 lalu pilih "Specification" untuk memeriksa Contract Size, Tick Value, dan Minimum Volume.',
      },
    ],
    technicalSections: [
      {
        heading: 'Separating Account Currency (USC) from Symbol Contract Size',
        body: 'Account Denomination defines the unit of AccountEquity() (1 USD = 100 USC). Contract Size defines the notional quantity per 1.00 lot inside the symbol specification. Position sizing must always read the broker’s actual Tick Size, Tick Value per Lot, Minimum Lot, and Volume Step.',
        formulaOrSpec:
          '1 USD = 100 USC | Always verify SymbolInfoDouble(symbol, SYMBOL_TRADE_CONTRACT_SIZE)',
      },
      {
        heading: 'Partial Take-Profit Divisibility When Contract Size Is Scaled',
        body: 'When a broker provides a micro-scaled Cent symbol contract, a small-capital trader can open 0.10 or 0.20 lots within their risk budget—allowing partial position closures (e.g., closing 50% at +1R) that would be impossible at the 0.01 lot floor.',
      },
    ],
    technicalSectionsId: [
      {
        heading: 'Memisahkan Mata Uang Akun (USC) dari Ukuran Kontrak Simbol',
        body: 'Denominasi Akun menentukan satuan AccountEquity() (1 USD = 100 USC). Ukuran Kontrak (Contract Size) menentukan jumlah nosional per 1.00 lot pada spesifikasi simbol. Perhitungan ukuran posisi wajib membaca Tick Size, Tick Value per Lot, Minimum Lot, dan Volume Step aktual dari broker.',
        formulaOrSpec:
          '1 USD = 100 USC | Wajib periksa SymbolInfoDouble(symbol, SYMBOL_TRADE_CONTRACT_SIZE)',
      },
      {
        heading: 'Fleksibilitas Partial Take-Profit pada Kontrak Mikro',
        body: 'Ketika broker menyediakan kontrak simbol Cent berskala mikro, trader bermodal kecil dapat membuka 0.10 atau 0.20 lot sesuai anggaran risikonya—sehingga memungkinkan penutupan posisi sebagian (partial close 50%) yang tidak bisa dilakukan jika terkunci di lot minimum 0.01.',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Checking Broker Symbol Specifications on a $50 (5,000 USC) Account',
      standardAccountOutcome:
        'Assumes all Cent accounts are identical without checking MT5 specifications, opening a trade on an unscaled symbol and risking far more than intended.',
      centAccountOutcome:
        'Verifies tick value and minimum volume in JGS Cent Lab first, confirming whether the symbol uses a micro Cent contract before sizing the order.',
    },
    microCapitalCaseStudyId: {
      title: 'Memeriksa Spesifikasi Simbol Broker pada Akun $50 (5.000 USC)',
      standardAccountOutcome:
        'Berasumsi semua akun Cent sama tanpa mengecek spesifikasi MT5, sehingga membuka posisi pada simbol yang ukurannya tidak diperkecil dan menanggung risiko berlebih.',
      centAccountOutcome:
        'Memverifikasi nilai tick dan volume minimum di JGS Cent Lab terlebih dahulu untuk memastikan apakah simbol tersebut menggunakan kontrak mikro sebelum menentukan lot.',
    },
    jeyStreetRule:
      '1 USD = 100 USC is an account balance conversion, not a universal contract guarantee. Inspect your broker’s symbol specification before every new instrument you trade.',
    jeyStreetRuleId:
      '1 USD = 100 USC adalah konversi satuan saldo, bukan jaminan ukuran kontrak universal. Periksa spesifikasi simbol broker Anda setiap kali hendak mentradingkan instrumen baru.',
    relatedTerms: ['cent-account', 'usc', 'partial-close', 'point'],
    quiz: {
      question:
        'Why must you still check the MT5 Symbol Specification even when trading on a Cent (USC) account?',
      options: [
        'Because USC denomination only changes the balance unit (1 USD = 100 USC); contract size, tick value, and minimum lot still depend on the specific broker’s symbol rules.',
        'Because Cent accounts only work on weekends.',
        'Because MT5 hides the chart on Cent accounts.',
        'Because 1 USD equals 1,000 USC.',
      ],
      correctIndex: 0,
      explanation:
        'Cent denomination converts $1 USD into 100 USC, but actual contract size, tick value, and minimum volume are defined per symbol by each broker.',
    },
    quizId: {
      question:
        'Mengapa Anda tetap wajib memeriksa Spesifikasi Simbol (Symbol Specification) di MT5 meskipun menggunakan akun Cent (USC)?',
      options: [
        'Karena denominasi USC hanya mengubah satuan saldo (1 USD = 100 USC); ukuran kontrak, nilai tick, dan lot minimum tetap bergantung pada aturan simbol masing-masing broker.',
        'Karena akun Cent hanya aktif di akhir pekan.',
        'Karena MT5 menyembunyikan grafik pada akun Cent.',
        'Karena 1 USD sama dengan 1.000 USC.',
      ],
      correctIndex: 0,
      explanation:
        'Denominasi Cent mengubah $1 USD menjadi 100 USC, tetapi ukuran kontrak, nilai tick, dan volume minimum ditetapkan per simbol oleh masing-masing broker.',
    },
  },
  {
    slug: 'pips-points-spread-and-leverage',
    trackId: 'track-01',
    lessonNumber: '1.3',
    title: 'Pips, Points, Spread & Leverage Without the Textbook Jargon',
    titleId: 'Memahami Pip, Point, Spread & Leverage Tanpa Istilah Rumit',
    durationMinutes: 8,
    difficulty: 'BEGINNER',
    summary:
      'Master the four numbers that govern every trade cost and margin requirement before you ever click Buy or Sell.',
    summaryId:
      'Kuasai empat angka utama yang menentukan biaya transaksi dan kebutuhan margin sebelum Anda menekan tombol Buy atau Sell.',
    plainEnglishSections: [
      {
        heading: 'Points vs. Pips: The Ruler of Price Distance',
        body: 'A Point is the smallest last-digit price change shown in your quote. On a 5-decimal EURUSD quote, moving from 1.08500 to 1.08510 is 10 Points (1 Pip). On a 2-decimal Gold (XAUUSD) quote, moving from 2650.00 to 2651.00 ($1.00 move) is 100 Points.',
      },
      {
        heading: 'Spread: The Transaction Cost Gap',
        body: 'The Spread is the gap between the Buy (Ask) price and the Sell (Bid) price. It is why every new position starts slightly negative. During major economic news releases or daily market rollover, spreads can widen substantially.',
      },
      {
        heading: 'Leverage: Margin Requirement, Not Free Money',
        body: 'Leverage (such as 1:100 or 1:500) reduces the margin deposit required to open a trade. Higher leverage does not change the value per point unless you choose to open a larger lot size.',
      },
    ],
    plainEnglishSectionsId: [
      {
        heading: 'Point vs Pip: Penggaris Jarak Harga',
        body: 'Point adalah perubahan digit desimal terkecil pada kuotasi harga di MT5. Pada kuotasi EURUSD 5 desimal, pergerakan dari 1.08500 ke 1.08510 adalah 10 Point (1 Pip). Pada kuotasi Emas (XAUUSD) 2 desimal, pergerakan dari 2650.00 ke 2651.00 ($1,00) adalah 100 Point.',
      },
      {
        heading: 'Spread: Selisih Harga Beli dan Jual',
        body: 'Spread adalah selisih antara harga Beli (Ask) dan harga Jual (Bid). Itulah sebabnya setiap posisi baru langsung dimulai sedikit negatif sebesar nilai spread. Saat rilis berita ekonomi besar atau pergantian hari server (rollover), spread dapat melebar secara signifikan.',
      },
      {
        heading: 'Leverage: Jaminan Margin, Bukan Uang Gratis',
        body: 'Leverage (seperti 1:100 atau 1:500) hanya memperkecil jaminan (Margin) yang dibutuhkan untuk membuka posisi. Leverage tinggi tidak memperbesar risiko per poin kecuali Anda memilih membuka ukuran lot yang lebih besar.',
      },
    ],
    technicalSections: [
      {
        heading: 'Bid-Ask Spread & Effective Stop Distance',
        body: 'Long orders open at the Ask price and close at the Bid price. Short orders open at the Bid price and close (including Stop Loss execution) at the Ask price. Therefore, wide spreads reduce effective stop distance.',
        formulaOrSpec: 'Margin Required = (Contract_Notional × Lots) / Leverage',
      },
    ],
    microCapitalCaseStudy: {
      title: 'High Leverage Used Responsibly vs. Over-Leveraging',
      standardAccountOutcome:
        'Beginner uses high leverage to open the maximum possible lot size, suffering a Margin Call on a minor fluctuation.',
      centAccountOutcome:
        'Disciplined trader uses leverage only to keep required margin low while strictly sizing the Stop Loss within their risk budget.',
    },
    jeyStreetRule:
      'Leverage is just the horsepower of the engine. Your Lot Size and Stop Loss are the brakes and steering wheel.',
    jeyStreetRuleId:
      'Leverage hanyalah tenaga mesin. Ukuran Lot dan Stop-Loss Anda adalah rem dan kemudinya.',
    relatedTerms: ['pip', 'point', 'spread', 'leverage', 'margin'],
    quiz: {
      question:
        'Why does a Short (Sell) trade sometimes hit Stop Loss just before the candle wick touches your line on the chart?',
      options: [
        'Because charts plot the Bid price, while Short positions close at the higher Ask price (Bid + Spread).',
        'Because MT5 deletes Stop Losses during the London session.',
        'Because leverage changes the candle color.',
        'Because Cent accounts use different timezones.',
      ],
      correctIndex: 0,
      explanation:
        'Standard candlestick charts plot the Bid price. Closing a Sell trade requires buying back at the Ask price (Bid + Spread).',
    },
  },
  {
    slug: 'anatomy-of-xauusd-gold',
    trackId: 'track-02',
    lessonNumber: '2.1',
    title: 'Anatomy of XAUUSD: Why Gold Moves Differently Than Forex',
    titleId: 'Anatomi XAUUSD: Mengapa Karakter Volatilitas Emas Berbeda dari Forex',
    durationMinutes: 10,
    difficulty: 'INTERMEDIATE',
    summary:
      'Understand Gold volatility profiles, US Dollar sensitivity, and why overly tight stops get swept during active sessions.',
    summaryId:
      'Pahami profil volatilitas emas, sensitivitas terhadap Dolar AS, dan mengapa stop-loss yang terlalu sempit mudah tersapu.',
    plainEnglishSections: [
      {
        heading: 'Gold Reacts Quickly to Macro Drivers',
        body: 'XAUUSD prices Gold in US Dollars. When US Treasury yields move, geopolitical headlines emerge, or the US Dollar shifts, Gold can cover wide price ranges in minutes.',
      },
      {
        heading: 'Match Stop Distance to Market Structure, Then Adjust Lot Size',
        body: 'Instead of forcing an artificially tiny stop-loss just to trade a larger lot size, place your stop-loss beyond the structural invalidation level and reduce your lot size so total monetary risk stays within your limit.',
      },
    ],
    technicalSections: [
      {
        heading: 'Average True Range (ATR) & Volatility Normalization',
        body: 'During the London-New York overlap (13:00–17:00 UTC), XAUUSD intraday volatility expands significantly. Position sizing must normalize for volatility: as structural stop distance widens, lot size scales inversely.',
        formulaOrSpec:
          'Lots = (Equity × Risk%) / ((Stop_Distance / Tick_Size) × Tick_Value_Per_Lot)',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Adapting Lot Size to Gold Volatility on a 5,000 USC ($50) Account',
      standardAccountOutcome:
        'Uses an overly tight stop to force a larger lot; gets stopped out repeatedly by normal market noise.',
      centAccountOutcome:
        'Places a structural stop behind the session swing and scales down lot size so monetary risk stays controlled.',
    },
    jeyStreetRule:
      'Never tighten your Stop Loss just to make your Lot Size bigger. Place the stop where your trade idea is invalidated, then let the calculator determine the lot size.',
    jeyStreetRuleId:
      'Jangan pernah mempersempit Stop-Loss hanya demi memperbesar Lot. Letakkan stop di titik invalidasi analisis Anda, lalu biarkan kalkulator menentukan ukuran lotnya.',
    relatedTerms: ['xauusd', 'atr', 'liquidity-sweep', 'stop-loss'],
    quiz: {
      question:
        'If Gold (XAUUSD) volatility doubles during the New York session requiring a wider stop-loss (2x normal distance), what should you do to keep monetary risk constant?',
      options: [
        'Double your lot size to make back the wider stop.',
        'Cut your lot size in half so the total amount risked at the wider stop stays identical.',
        'Remove your stop loss completely.',
        'Ignore the broker specification.',
      ],
      correctIndex: 1,
      explanation:
        'Doubling the stop distance while halving the lot size keeps your exact monetary risk constant.',
    },
  },
  {
    slug: 'trading-sessions-asian-london-ny',
    trackId: 'track-02',
    lessonNumber: '2.2',
    title: 'The 3-Session Clock: Asian Range, London Sweep & NY Expansion',
    titleId: 'Siklus 3 Sesi Pasar: Rentang Asia, Pembukaan London & Ekspansi New York',
    durationMinutes: 10,
    difficulty: 'BEGINNER',
    summary:
      'Learn how global liquidity cycles across Tokyo, London, and New York affect spread, volatility, and breakout reliability.',
    summaryId:
      'Pelajari bagaimana siklus likuiditas global di Tokyo, London, dan New York memengaruhi spread, volatilitas, dan kualitas breakout.',
    plainEnglishSections: [
      {
        heading: 'Asian Session: Consolidation & Range Formation',
        body: 'During the Tokyo/Asian session, Gold and European currency pairs often trade inside a narrower horizontal range while liquidity is lighter.',
      },
      {
        heading: 'London Open: Volume Expansion & Liquidity Sweeps',
        body: 'When European financial centers open, institutional order flow increases. Price frequently tests the edges of the Asian range before establishing its directional move.',
      },
      {
        heading: 'New York Session: US Economic Releases & Overlap',
        body: 'When New York opens—overlapping with London—major US economic data is released and daily trading volume peaks. Conversely, during daily rollover (21:00–23:00 UTC), liquidity thins and spreads widen.',
      },
    ],
    technicalSections: [
      {
        heading: 'Intraday Liquidity Distribution & Rollover Spread Widening',
        body: 'Order flow concentrates during the London open (07:00–10:00 UTC) and London-New York overlap (12:30–16:00 UTC). Executing market orders during the daily bank rollover window exposes positions to wide bid-ask spreads.',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Trading Liquid Session Hours vs. Daily Rollover Window',
      standardAccountOutcome:
        'Opens a trade at 22:00 UTC rollover when spreads widen sharply, starting the trade deeply negative.',
      centAccountOutcome:
        'Waits for normal session liquidity with normal spreads before executing the planned setup.',
    },
    jeyStreetRule:
      'You do not get paid for screen time; you get paid for timing liquidity. Avoid opening tight intraday trades during illiquid rollover hours.',
    jeyStreetRuleId:
      'Anda tidak dibayar dari lamanya menatap layar, melainkan dari disiplin menunggu likuiditas yang sehat. Hindari membuka posisi saat jam rollover yang sepi dan berspread lebar.',
    relatedTerms: ['asian-range', 'liquidity-sweep', 'spread', 'slippage'],
    quiz: {
      question:
        'Which intraday window typically delivers the highest combined liquidity for XAUUSD and EURUSD?',
      options: [
        'Daily Market Rollover (21:00–23:00 UTC)',
        'The London & New York Session Overlap (12:30–16:00 UTC)',
        'Sunday Market Open first 5 minutes',
        'Late Friday 5 minutes before market close',
      ],
      correctIndex: 1,
      explanation:
        'When both London and New York financial centers are open simultaneously, institutional volume is at its peak.',
    },
  },
  {
    slug: 'liquidity-sweeps-vs-real-breakouts',
    trackId: 'track-02',
    lessonNumber: '2.3',
    title: 'Market Structure: Liquidity Sweeps vs. Confirmed Breakouts',
    titleId: 'Struktur Market: Membedakan Sapuan Likuiditas vs Breakout Terkonfirmasi',
    durationMinutes: 10,
    difficulty: 'INTERMEDIATE',
    summary:
      'Learn how to distinguish between an impulsive wick that rejects a price level and a confirmed candle closure with structural acceptance.',
    summaryId:
      'Pelajari cara membedakan ekor candle (wick) yang menolak level harga dengan penutupan candle penuh yang mengonfirmasi penembusan struktur.',
    plainEnglishSections: [
      {
        heading: 'Why Chasing Fast Green Candles Is Risky',
        body: 'When price rushes toward an obvious resistance ceiling, impatient traders often buy right at the top of the spike. If resting sell orders absorb that buying pressure, price quickly snaps back inside the range, leaving a long rejection wick.',
      },
      {
        heading: 'Wait for Candle Closure & Structural Retest',
        body: 'A wick piercing a level shows temporary probing; a full-bodied candle closing firmly beyond the level followed by a measured retest offers clearer structural confirmation.',
      },
    ],
    technicalSections: [
      {
        heading: 'Order Book Absorption vs. Break of Structure (BOS)',
        body: 'Above prior swing highs rests clustered stop-buy and breakout flow. When price pierces the high and closes back inside the prior range, it indicates supply absorption. A sustained body close beyond the level signals structural continuation.',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Waiting for 15-Minute Candle Confirmation on XAUUSD',
      standardAccountOutcome:
        'Chases a mid-candle spike above resistance; the candle closes back below the level and hits stop loss.',
      centAccountOutcome:
        'Waits for the 15-minute candle close to confirm whether price accepted or rejected the level before committing risk.',
    },
    jeyStreetRule:
      'Wicks show where liquidity was tested. Candle closes show whether the market actually accepted the new price level.',
    jeyStreetRuleId:
      'Ekor candle (wick) menunjukkan di mana likuiditas diuji. Penutupan badan candle menunjukkan apakah pasar benar-benar menerima level harga baru tersebut.',
    relatedTerms: ['liquidity-sweep', 'break-of-structure', 'fomo', 'slippage'],
    quiz: {
      question:
        'What is a common sign that a move above a prior resistance high was a Liquidity Sweep rather than a sustained breakout?',
      options: [
        'Price pierces the high with a wick and quickly closes back inside the previous range.',
        'Price closes multiple full-bodied candles above the high and holds support.',
        'The spread remains constant.',
        'Your account is denominated in USC.',
      ],
      correctIndex: 0,
      explanation:
        'A spike through a key level that fails to close outside the range and rapidly reclaims the interior is a classic liquidity sweep.',
    },
  },
  {
    slug: 'asymmetric-risk-to-reward',
    trackId: 'track-03',
    lessonNumber: '3.1',
    title: 'Planned Risk Units (R-Multiples) & Asymmetric Risk-to-Reward',
    titleId: 'Satuan Risiko Terencana (R-Multiple) & Risk-to-Reward Asimetris',
    durationMinutes: 9,
    difficulty: 'BEGINNER',
    summary:
      'Why positive mathematical expectancy depends on the relationship between win rate and Risk-to-Reward—not win rate alone.',
    summaryId:
      'Mengapa ekspektasi matematis positif bergantung pada hubungan antara win rate dan rasio Risk-to-Reward—bukan sekadar win rate tinggi.',
    plainEnglishSections: [
      {
        heading: 'What Is 1R?',
        body: '"1R" stands for one unit of planned risk on a trade. For example, if your account is 5,000 USC ($50) and you decide to risk 50 USC on a setup, then 1R = 50 USC. Losing the trade costs -1R; making 100 USC profit earns +2R (a 1:2 Risk-to-Reward ratio).',
      },
      {
        heading: 'How Payoff Asymmetry Reduces Win-Rate Pressure',
        body: 'If you consistently risk 1R to target 2R (1:2 R:R), your breakeven win rate before costs is 33.3%. At a 45% win rate over 20 trades (9 wins × +2R = +18R, and 11 losses × -1R = -11R), the net outcome is +7R even though less than half the trades won.',
      },
    ],
    technicalSections: [
      {
        heading: 'Mathematical Expectancy & Breakeven Win Rate',
        body: 'Positive expectancy is a joint function of win probability (W) and payoff ratio (R). Strategies that boast very high win rates often invert their payoff ratio (risking 5R to make 0.5R), exposing the account to severe tail risk.',
        formulaOrSpec:
          'Breakeven Win Rate = 1 / (1 + R:R) | Expectancy E = (W × AvgWinR) - ((1 - W) × AvgLossR)',
      },
    ],
    microCapitalCaseStudy: {
      title: '10 Trades at 40% Win Rate with 1:2.5 Risk-to-Reward',
      standardAccountOutcome:
        'Cuts winning trades early at +0.4R out of fear, lets losers run to -2R. Ends down -6R despite winning 6 of 10 trades.',
      centAccountOutcome:
        'Wins 4 trades at +2.5R (+10R) and loses 6 trades at -1R (-6R), finishing the 10-trade sample at +4.0R net.',
    },
    jeyStreetRule:
      'Stop asking "How high is the win rate?" Start asking "How many R do I make when I am right versus how much I lose when I am wrong?"',
    jeyStreetRuleId:
      'Berhentilah hanya bertanya "Berapa persen win rate-nya?" Mulailah bertanya "Berapa R yang saya dapat saat benar dibandingkan saat salah?"',
    relatedTerms: ['r-multiple', 'risk-to-reward', 'expectancy', 'breakeven-win-rate'],
    quiz: {
      question:
        'If your average Risk-to-Reward ratio is 1:2 (you make +2R on winners and lose -1R on losers), what is your theoretical breakeven win rate before fees?',
      options: ['50.0%', '33.33%', '66.67%', '20.0%'],
      correctIndex: 1,
      explanation:
        'Using the formula 1 / (1 + 2) = 1 / 3 = 33.33%. Winning 1 out of 3 trades (+2R vs two -1R losses) equals 0R breakeven.',
    },
  },
  {
    slug: 'nonlinear-math-of-drawdown-recovery',
    trackId: 'track-03',
    lessonNumber: '3.2',
    title: 'The Nonlinear Math of Drawdown Recovery',
    titleId: 'Matematika Non-Linear dalam Pemulihan Drawdown',
    durationMinutes: 9,
    difficulty: 'BEGINNER',
    summary:
      'Why losing 50% of your account requires a +100% gain on remaining capital just to get back to breakeven.',
    summaryId:
      'Mengapa kehilangan 50% saldo akun membutuhkan keuntungan +100% dari sisa modal hanya untuk kembali impas (breakeven).',
    plainEnglishSections: [
      {
        heading: 'The Asymmetry of Losses vs. Recovery Gains',
        body: 'Suppose you start with $100 and lose 50% of your account, leaving $50. To recover from $50 back to your original $100, you must earn $50 on a $50 base—which requires a +100% return! If you lose 80% of your balance (down to $20), you need +400% just to break even.',
      },
      {
        heading: 'Why Containing Drawdowns Early Matters',
        body: 'When a drawdown is kept at 10%, only +11.1% is needed to recover. Once drawdown exceeds 30% to 50%, the required recovery percentage climbs steeply.',
      },
    ],
    technicalSections: [
      {
        heading: 'Hyperbolic Recovery Function',
        body: 'As fractional drawdown D approaches 1.0 (100%), required recovery gain approaches infinity hyperbolically.',
        formulaOrSpec: 'Required Recovery Gain (%) = ((1 / (1 - D)) - 1) × 100',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Surviving a 5-Trade Losing Streak on 5,000 USC',
      standardAccountOutcome:
        'Risks 10% per trade. After 5 losses, drawdown reaches ~41%, requiring nearly +70% gain just to return to starting balance.',
      centAccountOutcome:
        'Uses conservative risk sizing (e.g., 1% per trade). After 5 losses, drawdown is ~4.9%, requiring +5.15% to recover.',
    },
    jeyStreetRule:
      'Capital preservation comes first. A shallow 10% drawdown requires +11.1% to recover; a 60% drawdown requires +150% just to break even.',
    jeyStreetRuleId:
      'Perlindungan modal adalah prioritas utama. Drawdown 10% hanya butuh +11,1% untuk pulih; drawdown 60% butuh +150% hanya untuk kembali impas.',
    relatedTerms: ['drawdown', 'recovery-factor', 'risk-of-ruin', 'equity'],
    quiz: {
      question:
        'If a trader loses 50% of their account balance, what percentage gain on their remaining capital is required to return to breakeven?',
      options: ['50%', '75%', '100%', '200%'],
      correctIndex: 2,
      explanation:
        'Dropping from 100 to 50 is a 50% loss, but growing from 50 back to 100 requires gaining 50 on a base of 50, which is +100%.',
    },
  },
  {
    slug: 'circuit-breakers-and-daily-loss-limits',
    trackId: 'track-03',
    lessonNumber: '3.3',
    title: 'Circuit Breakers: Daily Loss Limits & Revenge Trade Protection',
    titleId: 'Circuit Breaker: Batas Rugi Harian & Perlindungan dari Revenge Trading',
    durationMinutes: 10,
    difficulty: 'INTERMEDIATE',
    summary:
      'Install clear daily stop rules into your trading routine so a single difficult session never spirals into an emotional blowout.',
    summaryId:
      'Pasang aturan batas kerugian harian yang tegas agar satu sesi pasar yang buruk tidak berkembang menjadi kehancuran akun akibat emosi.',
    plainEnglishSections: [
      {
        heading: 'How Emotional Spirals Happen',
        body: 'Many severe account losses happen in a single afternoon: a trader takes a normal loss, feels frustrated, increases lot size to "win it back quickly," takes a second loss, and spirals into emotional revenge trading.',
      },
      {
        heading: 'Setting a Personal Daily Circuit Breaker',
        body: 'Define a clear daily loss cap before the session begins (for example, stopping after 2 consecutive losses or a set percentage of daily equity). If hit, close the trading platform and review your journal the next day.',
      },
    ],
    technicalSections: [
      {
        heading: 'Automated & Behavioral Equity Locks',
        body: 'Quantitative risk frameworks implement a daily equity circuit breaker: if intraday closed plus floating PnL reaches the predefined daily loss threshold relative to the 00:00 UTC equity baseline, new order submission is halted until the next trading day.',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Volatile Economic News Session on XAUUSD',
      standardAccountOutcome:
        'Takes 7 emotional trades in one hour trying to force a recovery, compounding losses.',
      centAccountOutcome:
        'Stops trading immediately after hitting the planned daily loss limit, preserving capital for future setups.',
    },
    jeyStreetRule:
      'A planned stop-loss is a normal cost of doing business. A revenge trade is self-sabotage. Respect your daily loss limit without exception.',
    jeyStreetRuleId:
      'Stop-loss yang terencana adalah biaya bisnis yang wajar. Revenge trade adalah sabotase diri. Patuhi batas rugi harian Anda tanpa kompromi.',
    relatedTerms: ['daily-loss-limit', 'revenge-trading', 'drawdown', 'discipline-score'],
    quiz: {
      question: 'What is the primary purpose of a Daily Loss Limit (Circuit Breaker)?',
      options: [
        'To guarantee every trade wins.',
        'To prevent emotional tilt and choppy market conditions from compounding into severe account drawdown in a single day.',
        'To increase broker commissions.',
        'To avoid using a Stop Loss.',
      ],
      correctIndex: 1,
      explanation:
        'A daily circuit breaker caps single-day damage and interrupts emotional revenge-trading spirals.',
    },
  },
  {
    slug: 'mastering-mt5-order-types',
    trackId: 'track-04',
    lessonNumber: '4.1',
    title: 'Mastering MT5 Order Types: Market, Limit, Stop & SL/TP',
    titleId: 'Menguasai Jenis Order MT5: Market, Limit, Stop & SL/TP',
    durationMinutes: 10,
    difficulty: 'BEGINNER',
    summary:
      'Understand Market Execution, Buy Limit, Sell Limit, Buy Stop, Sell Stop, and server-side Stop Loss / Take Profit mechanics.',
    summaryId:
      'Pahami perbedaan Market Execution, Buy Limit, Sell Limit, Buy Stop, Sell Stop, serta cara kerja Stop-Loss / Take-Profit di server broker.',
    plainEnglishSections: [
      {
        heading: 'Market Execution vs. Pending Orders',
        body: 'A Market Order buys or sells immediately at the current available price. A Pending Order instructs MT5 to open the position only if price reaches your specified entry level, with your pre-set Stop Loss and Take Profit attached.',
      },
      {
        heading: 'Limit Orders (Pullback Entry) vs. Stop Orders (Breakout Entry)',
        body: 'Use a Limit Order when you want to enter at a more favorable price on a pullback (Buy Limit is placed BELOW current price; Sell Limit is placed ABOVE current price). Use a Stop Order when you want to enter only if price breaks through a level with momentum (Buy Stop ABOVE current price; Sell Stop BELOW current price).',
      },
    ],
    technicalSections: [
      {
        heading: 'Server-Side SL/TP vs. Client-Side Execution',
        body: 'Hard Stop Loss (SL) and Take Profit (TP) parameters attached to an MT5 position are stored on the broker trade server—meaning they remain active even if your local device disconnects. Client-side trailing stops and Expert Advisors require an active terminal or VPS.',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Planning a Pullback Entry With Pre-Defined Risk',
      standardAccountOutcome:
        'Clicks market order impulsively without calculating lot size or attaching a Stop Loss.',
      centAccountOutcome:
        'Places a Limit order at the planned structural level with pre-calculated lot size, hard SL, and TP stored on the server.',
    },
    jeyStreetRule:
      'Never submit an order to the market without a defined Stop Loss level and verified lot size.',
    jeyStreetRuleId:
      'Jangan pernah mengirim order ke pasar tanpa titik Stop-Loss yang jelas dan ukuran lot yang sudah dihitung.',
    relatedTerms: ['limit-order', 'stop-order', 'market-order', 'stop-loss', 'take-profit'],
    quiz: {
      question:
        'Current XAUUSD price is $2,650.00. You want to automatically BUY only if price pulls back lower to $2,642.00. Which MT5 pending order do you use?',
      options: [
        'Buy Stop at $2,642.00',
        'Buy Limit at $2,642.00',
        'Sell Limit at $2,642.00',
        'Sell Stop at $2,642.00',
      ],
      correctIndex: 1,
      explanation:
        'A Buy Limit order is placed below the current market price to buy on a pullback at a lower price.',
    },
  },
  {
    slug: 'how-expert-advisors-think-vs-martingale-danger',
    trackId: 'track-04',
    lessonNumber: '4.2',
    title: 'How Expert Advisors (EAs) Work: Rule-Based Execution vs. Martingale Risks',
    titleId: 'Cara Kerja Expert Advisor (EA): Eksekusi Berbasis Aturan vs Bahaya Martingale',
    durationMinutes: 11,
    difficulty: 'QUANT',
    summary:
      'Learn how rule-based algorithmic trading systems execute on MT5—and how to identify high-risk uncapped Martingale and Grid bots.',
    summaryId:
      'Pelajari bagaimana sistem trading algoritmik berbasis aturan bekerja di MT5—serta cara mengenali risiko tinggi pada bot Martingale dan Grid tanpa batas.',
    plainEnglishSections: [
      {
        heading: 'What Is an Expert Advisor (EA)?',
        body: 'An EA is an automated program running inside MetaTrader 5 that monitors market data and executes predefined trading and risk-management rules without human emotion or fatigue.',
      },
      {
        heading: 'The Hidden Risk of Uncapped Martingale Grids',
        body: 'Some commercial bots advertise artificially smooth balance curves by refusing to close losing trades and repeatedly doubling lot sizes (0.01, 0.02, 0.04, 0.08, 0.16 lots) as price moves against them. While the balance line looks flat or rising temporarily, floating equity drops rapidly during sustained trends until the account suffers a margin call.',
      },
      {
        heading: 'Principles of Responsible Algorithmic Design',
        body: 'A disciplined quantitative EA attaches a hard Stop Loss to every position, checks current broker spread before execution, respects session filters, and enforces a daily drawdown circuit breaker.',
      },
    ],
    technicalSections: [
      {
        heading: 'Deterministic OnTick() Pipeline & Risk Guards',
        body: 'In MQL5, a defensive EA evaluates conditions sequentially: (1) Spread & Margin Check -> (2) Daily Equity Drawdown Lock Check -> (3) Session & Volatility Filter -> (4) Signal Validation -> (5) Dynamic Lot Calculation from Broker Symbol Specs -> (6) Order Execution with MagicNumber isolation.',
        formulaOrSpec:
          'AVOID: Uncapped exponential lot multiplication (Lot_n = Lot_(n-1) × k) on losing positions.',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Sustained One-Way Trend Day on Gold',
      standardAccountOutcome:
        'Uncapped Martingale grid keeps adding losing positions against the trend without a stop loss, leading to severe equity depletion.',
      centAccountOutcome:
        'Rule-based EA with a hard stop loss exits when structure is invalidated, preserving capital.',
    },
    jeyStreetRule:
      'Any algorithm that hides losing trades in deep floating drawdown instead of respecting a hard Stop Loss carries severe tail risk.',
    jeyStreetRuleId:
      'Algoritma apa pun yang menyembunyikan posisi rugi di dalam floating drawdown tanpa Stop-Loss menyimpan risiko kehancuran modal yang besar.',
    relatedTerms: ['expert-advisor', 'martingale', 'magic-number', 'vps', 'drawdown'],
    quiz: {
      question:
        'How can you spot an uncapped Martingale / Grid EA when inspecting a trading history?',
      options: [
        'Every trade has a fixed Stop Loss.',
        'Lot sizes increase repeatedly while price moves against open positions, causing floating Equity to drop far below Balance.',
        'The EA uses a Magic Number.',
        'The EA checks broker spread before entering.',
      ],
      correctIndex: 1,
      explanation:
        'Repeatedly increasing lot sizes into losing positions while floating Equity diverges sharply below Balance is the signature of a Martingale grid.',
    },
  },
  {
    slug: 'auditing-verified-performance-telemetry',
    trackId: 'track-04',
    lessonNumber: '4.3',
    title: 'Auditing Performance: Evaluating Track Records & Key Risk Metrics',
    titleId: 'Mengaudit Performa: Cara Mengevaluasi Rekam Jejak & Metrik Risiko Utama',
    durationMinutes: 11,
    difficulty: 'QUANT',
    summary:
      'Learn how to evaluate Balance vs. Equity curves, Maximum Drawdown, Profit Factor, Trading Costs, and Reporting Periods objectively.',
    summaryId:
      'Pelajari cara mengevaluasi kurva Balance vs Equity, Maximum Drawdown, Profit Factor, Biaya Trading, dan Periode Pelaporan secara objektif.',
    plainEnglishSections: [
      {
        heading: 'Why Cropped Screenshots Are Incomplete',
        body: 'A cropped screenshot of a single winning day never reveals how much capital was risked, how deep floating drawdown reached, what trading costs (spread, commission, swap) were paid, or how long the strategy was tested.',
      },
      {
        heading: 'The 11 Core Metrics of Transparent Reporting',
        body: 'Comprehensive performance evaluation requires inspecting: Balance, Equity, Net Return, Maximum Equity Drawdown, Trading History, Profit Factor, Trading Frequency, Exposure, Trading Costs, Verification Source, and the exact Reporting Period.',
      },
    ],
    technicalSections: [
      {
        heading: 'Core Quantitative Audit Metrics',
        body: 'When evaluating any strategy or copy-trading system, inspect the joint relationship between Profit Factor (Gross Profit / Gross Loss), Maximum Equity Drawdown, Net Return after costs, and sample duration.',
        formulaOrSpec:
          'Profit Factor = Σ(Gross Winning Trades) / |Σ(Gross Losing Trades)|',
      },
    ],
    microCapitalCaseStudy: {
      title: 'Comparing Two Track Records Over 6 Months',
      standardAccountOutcome:
        'Strategy A shows high headline return but suffered an -80% floating equity drawdown by holding unhedged losing positions.',
      centAccountOutcome:
        'Strategy B reports both Balance and Equity curves transparently, keeping maximum equity drawdown strictly bounded.',
    },
    jeyStreetRule:
      'Never evaluate a return without checking the Maximum Equity Drawdown and Reporting Period behind it.',
    jeyStreetRuleId:
      'Jangan pernah menilai persentase profit tanpa memeriksa Maximum Equity Drawdown dan Periode Pelaporan di baliknya.',
    relatedTerms: ['profit-factor', 'drawdown', 'equity', 'expectancy', 'recovery-factor'],
    quiz: {
      question:
        'Why must you always check the Equity curve alongside the Balance curve when auditing a trading track record?',
      options: [
        'Because Balance only updates when trades close, so a smooth Balance curve can hide large open floating losses that appear in the Equity curve.',
        'Because Equity is always higher than Balance.',
        'Because brokers do not calculate Balance on Fridays.',
        'Because Equity only applies to Forex, not Gold.',
      ],
      correctIndex: 0,
      explanation:
        'Balance ignores open floating losses. Only the Equity curve reveals whether a strategy held deep underwater positions.',
    },
  },
];

export function getLocalizedTrack(track: AcademyTrack, locale: Locale): AcademyTrack {
  if (locale !== 'id') return track;
  return {
    ...track,
    title: track.titleId ?? track.title,
    subtitle: track.subtitleId ?? track.subtitle,
    targetAudience: track.targetAudienceId ?? track.targetAudience,
  };
}

export function getLocalizedLesson(lesson: AcademyLesson, locale: Locale): AcademyLesson {
  if (locale !== 'id') return lesson;
  return {
    ...lesson,
    title: lesson.titleId ?? lesson.title,
    summary: lesson.summaryId ?? lesson.summary,
    plainEnglishSections: lesson.plainEnglishSectionsId ?? lesson.plainEnglishSections,
    technicalSections: lesson.technicalSectionsId ?? lesson.technicalSections,
    microCapitalCaseStudy: lesson.microCapitalCaseStudyId ?? lesson.microCapitalCaseStudy,
    jeyStreetRule: lesson.jeyStreetRuleId ?? lesson.jeyStreetRule,
    quiz: lesson.quizId ?? lesson.quiz,
  };
}
