import React from 'react';
import type { Metadata } from 'next';
import { AcademyHub } from '@/components/academy/AcademyHub';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/academy',
    title:
      locale === 'id'
        ? 'JGS Academy — Kurikulum Edukasi Trading & Risiko Gratis'
        : 'JGS Academy — Free Trading & Risk Engineering Curriculum',
    description:
      locale === 'id'
        ? 'Jalur belajar terstruktur untuk pemula, trader modal mikro, dan pembangun sistem MT5.'
        : 'Structured learning paths for beginners, micro-capital traders, and MT5 system builders.',
  });
}

export default function AcademyPage() {
  return <AcademyHub />;
}
