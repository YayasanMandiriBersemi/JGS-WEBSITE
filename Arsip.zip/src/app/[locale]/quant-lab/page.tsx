import React from 'react';
import type { Metadata } from 'next';
import { QuantLabDocs } from '@/components/quant/QuantLabDocs';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/quant-lab',
    title:
      locale === 'id'
        ? 'JGS Quant Lab — Dokumentasi Arsitektur Expert Advisor (EA) MT5'
        : 'JGS Quant Lab — MT5 Expert Advisor (EA) Architecture Documentation',
    description:
      locale === 'id'
        ? 'Dokumentasi alur eksekusi OnTick() deterministik, parameter pengaman risiko, dan checklist persiapan VPS/MT5.'
        : 'Documentation on deterministic OnTick() execution pipelines, risk guard parameters, and VPS/MT5 deployment checklists.',
  });
}

export default function QuantLabPage() {
  return <QuantLabDocs />;
}
