import React from 'react';
import type { Metadata } from 'next';
import { EaTestingToolkit } from '@/components/quant/EaTestingToolkit';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/ea-testing',
    title:
      locale === 'id'
        ? 'EA Testing Toolkit — Panduan & Simulator Audit Backtest MT5'
        : 'EA Testing Toolkit — MT5 Backtest Quality & Friction Stress-Tester',
    description:
      locale === 'id'
        ? 'Audit kualitas backtest Strategy Tester MT5 dan uji ketahanan ekspektasi sistem terhadap pelebaran spread dan slippage.'
        : 'Audit MT5 Strategy Tester backtest integrity and stress-test strategy expectancy against spread widening and slippage.',
  });
}

export default function EaTestingPage() {
  return <EaTestingToolkit />;
}
