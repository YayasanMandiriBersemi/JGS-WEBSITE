import React from 'react';
import type { Metadata } from 'next';
import { CopyTradingGuide } from '@/components/copy-trading/CopyTradingGuide';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/copy-trading',
    title:
      locale === 'id'
        ? 'Informasi Copy Trading, Simulasi High-Water Mark & Risiko — JGS'
        : 'Copy Trading Information, High-Water Mark Simulator & Risk Disclosures — JGS',
    description:
      locale === 'id'
        ? 'Penjelasan transparan mekanisme penyalinan posisi, risiko eksekusi, kompatibilitas spesifikasi broker, dan simulasi High-Water Mark 30% (Status Pra-Peluncuran).'
        : 'Transparent guide to trade replication mechanics, execution risks, broker compatibility, and the proposed 30% High-Water Mark fee model (Pre-Launch State).',
  });
}

export default function CopyTradingPage() {
  return <CopyTradingGuide />;
}
