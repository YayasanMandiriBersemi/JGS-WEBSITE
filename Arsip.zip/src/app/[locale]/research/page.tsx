import React from 'react';
import type { Metadata } from 'next';
import { MarketResearchHub } from '@/components/research/MarketResearchHub';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/research',
    title:
      locale === 'id'
        ? 'JGS Intelligence — Riset Struktur Market & Spesifikasi Kontrak'
        : 'JGS Intelligence — Market Structure & Contract Specification Research',
    description:
      locale === 'id'
        ? 'Artikel riset edukasi mengenai likuiditas sesi global, spesifikasi kontrak broker, dan mekanisme High-Water Mark dengan tanggal dan sumber resmi.'
        : 'Educational research articles on global session liquidity, broker contract specifications, and High-Water Mark mechanics with dates and primary citations.',
  });
}

export default function ResearchPage() {
  return <MarketResearchHub />;
}
