import React from 'react';
import type { Metadata } from 'next';
import { CentLabCalculator } from '@/components/calculators/CentLabCalculator';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/calculators/position-size',
    title:
      locale === 'id'
        ? 'Kalkulator Position Sizing — Ukuran Lot Berbasis Spesifikasi Simbol Broker'
        : 'Position Sizing Calculator — Broker Symbol Specification Lot Sizer',
    description:
      locale === 'id'
        ? 'Hitung ukuran lot berdasarkan ekuitas, jarak stop-loss, tick size, tick value, dan lot minimum broker.'
        : 'Calculate trade volume from equity, stop-loss distance, tick size, tick value, and broker minimum lot.',
  });
}

export default function PositionSizeCalculatorPage() {
  return <CentLabCalculator />;
}
