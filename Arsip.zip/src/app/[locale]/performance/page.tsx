import React from 'react';
import type { Metadata } from 'next';
import { PerformanceDashboard } from '@/components/performance/PerformanceDashboard';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/performance',
    title:
      locale === 'id'
        ? 'Pusat Transparansi Performa — Skema Audit 11 Metrik JGS'
        : 'Performance Transparency Center — JGS 11-Metric Audit Schema',
    description:
      locale === 'id'
        ? 'Arsitektur 11 metrik transparansi performa (Balance, Equity, Max Drawdown, Profit Factor, Biaya Trading) dalam status pra-peluncuran yang jujur.'
        : '11-metric performance transparency schema (Balance, Equity, Max Drawdown, Profit Factor, Trading Costs) in an honest pre-launch state.',
  });
}

export default function PerformancePage() {
  return <PerformanceDashboard />;
}
