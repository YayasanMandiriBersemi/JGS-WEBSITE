import React from 'react';
import type { Metadata } from 'next';
import { OurStrategyHubView } from '@/components/about/AboutJgsView';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/strategy',
    title:
      locale === 'id'
        ? 'Strategi Kami — Quant Lab, EA Testing Toolkit & Informasi Copy Trading'
        : 'Our Strategy — Quant Lab, EA Testing Toolkit & Copy Trading Disclosures',
    description:
      locale === 'id'
        ? 'Pelajari metodologi sistem berbasis aturan, alat uji kualitas backtest MT5, dan transparansi mekanisme High-Water Mark.'
        : 'Explore rule-based system methodology, MT5 backtest auditing tools, and High-Water Mark transparency.',
  });
}

export default function StrategyPage() {
  return <OurStrategyHubView />;
}
