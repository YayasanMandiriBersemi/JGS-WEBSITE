import React from 'react';
import type { Metadata } from 'next';
import { RegisterView } from '@/components/account/StrategistWorkspaceViews';
import { buildLocalizedMetadata, isValidLocale, DEFAULT_LOCALE } from '@/i18n/config';

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const resolvedParams = await params;
  const locale = isValidLocale(resolvedParams.locale) ? resolvedParams.locale : DEFAULT_LOCALE;
  return buildLocalizedMetadata({
    locale,
    pathname: '/register',
    title:
      locale === 'id'
        ? 'Buat Profil Belajar Lokal (Opsional) — JGS'
        : 'Create Local Learning Profile (Optional) — JGS',
    description:
      locale === 'id'
        ? 'Buat profil belajar lokal opsional di JGS.'
        : 'Create an optional local learning profile on JGS.',
  });
}

export default function RegisterPage() {
  return <RegisterView />;
}
