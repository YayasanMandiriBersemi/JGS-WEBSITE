'use client';

import React from 'react';
import { Crown, ShieldCheck } from 'lucide-react';
import { useLocale } from '@/i18n/LocaleContext';

interface JeyStrategistCalloutProps {
  title?: string;
  ruleText: string;
  contextTag?: string;
  variant?: 'gold' | 'purple';
  showAvatar?: boolean;
}

export function JeyStrategistCallout({
  title,
  ruleText,
  contextTag,
  variant = 'gold',
  showAvatar = false
}: JeyStrategistCalloutProps) {
  const { isId } = useLocale();
  const displayTitle = title ?? (isId ? 'Catatan Strategi JGS' : 'JGS Strategy Note');
  const displayTag = contextTag ?? (isId ? 'Prinsip Manajemen Risiko' : 'Risk Management Principle');

  const borderClass =
    variant === 'gold'
      ? 'border-[#D4AF37]/30 bg-gradient-to-r from-[#170F26] via-[#130C20] to-[#100A1B]'
      : 'border-[#A882DD]/30 bg-[#150E23]';

  return (
    <div className={`rounded-2xl border p-5 sm:p-6 ${borderClass}`}>
      <div className="flex flex-col sm:flex-row sm:items-center gap-4">
        {showAvatar && (
          <div className="relative shrink-0 w-12 h-12 rounded-xl overflow-hidden border border-[#D4AF37]/50 bg-[#A882DD]/20">
            <img
              src="/images/jey-mascot.png"
              alt="Jey — Mascot of The Jey Gang Strategist"
              width={48}
              height={48}
              decoding="async"
              className="w-full h-full object-cover object-top"
            />
          </div>
        )}
        <div className="flex-1 min-w-0">
          <div className="flex flex-wrap items-center gap-2.5 mb-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D4AF37]">
              <Crown className="w-3.5 h-3.5 text-[#D4AF37]" />
              {displayTitle}
            </span>
            <span className="text-xs px-2.5 py-0.5 rounded-full bg-[#08050E]/80 text-[#BEB6CE] border border-white/10">
              {displayTag}
            </span>
          </div>
          <p className="text-sm sm:text-base text-[#F7F4EE] leading-relaxed">
            “{ruleText}”
          </p>
        </div>
        <div className="hidden lg:flex items-center justify-center shrink-0 w-9 h-9 rounded-xl bg-[#08050E]/70 border border-[#D4AF37]/20 text-[#D4AF37]">
          <ShieldCheck className="w-4 h-4" />
        </div>
      </div>
    </div>
  );
}
