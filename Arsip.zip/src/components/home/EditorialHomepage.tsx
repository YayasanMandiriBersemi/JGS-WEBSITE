'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  ArrowRight,
  BookOpen,
  Calculator,
  Cpu,
  ShieldCheck,
  CheckCircle2,
  Compass,
  Newspaper,
  Scale,
  AlertTriangle,
  Sparkles,
  FileCheck2,
  Layers,
} from 'lucide-react';
import { useLocale } from '@/i18n/LocaleContext';
import { calculateBrokerSymbolPositionSize } from '@/lib/math/cent-calculator';

type PersonaId = 'beginner' | 'micro' | 'system' | 'copy';

interface PersonaJourney {
  id: PersonaId;
  selectorLabel: { id: string; en: string };
  personaTitle: { id: string; en: string };
  subtitle: { id: string; en: string };
  description: { id: string; en: string };
  keyFocus: { id: string[]; en: string[] };
  primaryAction: {
    label: { id: string; en: string };
    href: string;
  };
  secondaryAction: {
    label: { id: string; en: string };
    href: string;
  };
  recommendedModules: {
    title: { id: string; en: string };
    desc: { id: string; en: string };
    href: string;
    tag: { id: string; en: string };
  }[];
}

const PERSONA_JOURNEYS: PersonaJourney[] = [
  {
    id: 'beginner',
    selectorLabel: {
      id: 'Saya baru mulai.',
      en: 'I am just starting out.',
    },
    personaTitle: {
      id: 'Curious Beginner — Pemula yang Ingin Paham Dasar',
      en: 'Curious Beginner — Building Foundational Clarity',
    },
    subtitle: {
      id: 'Belajar cara kerja market dan risiko dari nol tanpa biaya, tanpa deposit, dan tanpa istilah rumit.',
      en: 'Learn how markets and risk management work from scratch—with zero cost, no deposits, and plain-language explanations.',
    },
    description: {
      id: 'Anda tidak perlu langsung membuka akun broker atau menyetor uang untuk belajar trading. Mulailah dengan memahami apa itu pip, spread, leverage, dan mengapa perlindungan modal jauh lebih penting daripada mengejar profit cepat.',
      en: 'You do not need to open a broker account or deposit money to learn how trading works. Start by understanding pips, spread, leverage, and why capital preservation matters far more than chasing quick profits.',
    },
    keyFocus: {
      id: [
        'Penjelasan bahasa sederhana tanpa jargon yang mengintimidasi',
        '100% gratis tanpa langganan atau paksaan daftar broker',
        'Simulasi keputusan di skenario historis tanpa uang sungguhan',
      ],
      en: [
        'Plain-language explanations free of intimidating jargon',
        '100% free with no subscriptions or forced broker sign-ups',
        'Practice decisions on historical scenarios without real money',
      ],
    },
    primaryAction: {
      label: { id: 'Mulai Jalur Pemula di Academy', en: 'Start Beginner Path in Academy' },
      href: '/academy?track=Beginner',
    },
    secondaryAction: {
      label: { id: 'Buka Kamus Trading', en: 'Open Trading Dictionary' },
      href: '/dictionary',
    },
    recommendedModules: [
      {
        title: { id: 'JGS Academy — Jalur Pemula', en: 'JGS Academy — Beginner Track' },
        desc: {
          id: 'Pelajari mekanisme dasar akun Cent, ukuran kontrak, dan manajemen risiko sebelum menyentuh grafik live.',
          en: 'Understand Cent account mechanics, contract specifications, and risk management before touching a live chart.',
        },
        href: '/academy?track=Beginner',
        tag: { id: 'Langkah 1', en: 'Step 1' },
      },
      {
        title: { id: 'Kamus Trading Jey', en: "Jey's Trading Dictionary" },
        desc: {
          id: 'Cari arti istilah seperti Equity, Margin, Drawdown, dan Stop-Loss dengan contoh perhitungan nyata.',
          en: 'Look up terms like Equity, Margin, Drawdown, and Stop-Loss with clear, practical examples.',
        },
        href: '/dictionary',
        tag: { id: 'Langkah 2', en: 'Step 2' },
      },
      {
        title: { id: 'Trading Playground Historis', en: 'Historical Trading Playground' },
        desc: {
          id: 'Uji keputusan Buy, Sell, atau Wait pada skenario market historis dan pelajari kualitas keputusan Anda.',
          en: 'Test Buy, Sell, or Wait decisions on historical market scenarios and review objective feedback.',
        },
        href: '/playground',
        tag: { id: 'Langkah 3', en: 'Step 3' },
      },
    ],
  },
  {
    id: 'micro',
    selectorLabel: {
      id: 'Saya sudah trading.',
      en: 'I already trade.',
    },
    personaTitle: {
      id: 'Micro-Capital Trader — Fokus Presisi Risiko & Akun Cent',
      en: 'Micro-Capital Trader — Precision Sizing & Cent Account Mechanics',
    },
    subtitle: {
      id: 'Kelola modal kecil ($10–$100) dengan disiplin posisi, spesifikasi simbol broker yang akurat, dan batas drawdown ketat.',
      en: 'Manage small capital ($10–$100) with disciplined position sizing, accurate broker symbol specifications, and strict drawdown limits.',
    },
    description: {
      id: 'Trader bermodal kecil sering mengalami kerugian besar bukan karena arah analisis yang salah, melainkan karena ukuran lot tidak sesuai dengan spesifikasi kontrak broker. Gunakan kalkulator gratis JGS untuk menghitung ukuran lot sebelum membuka posisi di MT5.',
      en: 'Small-capital traders often suffer heavy losses not from directional analysis alone, but because lot sizing mismatches the broker’s contract specification. Use free JGS calculators to verify exact lot size before placing any MT5 order.',
    },
    keyFocus: {
      id: [
        'Konversi USD ke USC (Cent) beserta pemeriksaan spesifikasi kontrak broker',
        'Penolakan otomatis jika lot minimum broker melanggar batas risiko Anda',
        'Simulasi pemulihan drawdown dan pencatatan disiplin di Jurnal Trader',
      ],
      en: [
        'USD to USC (Cent) conversion paired with broker contract specification checks',
        'Automatic trade rejection when broker minimum lot exceeds your risk limit',
        'Drawdown recovery simulation and disciplined tracking in the Trader Journal',
      ],
    },
    primaryAction: {
      label: { id: 'Buka Kalkulator Position Sizing', en: 'Open Position Sizing Calculator' },
      href: '/calculators/position-size',
    },
    secondaryAction: {
      label: { id: 'Simulasi Drawdown & Risiko', en: 'Simulate Drawdown & Risk' },
      href: '/calculators/drawdown',
    },
    recommendedModules: [
      {
        title: { id: 'JGS Cent Lab & Position Sizing', en: 'JGS Cent Lab & Position Sizing' },
        desc: {
          id: 'Hitung ukuran lot berdasarkan ekuitas, jarak stop-loss, ukuran tick, nilai tick, dan volume minimum broker.',
          en: 'Calculate exact lot size using equity, stop-loss distance, tick size, tick value, and broker minimum volume.',
        },
        href: '/calculators/cent',
        tag: { id: 'Kalkulator Utama', en: 'Core Calculator' },
      },
      {
        title: { id: 'Drawdown Simulator', en: 'Drawdown Simulator' },
        desc: {
          id: 'Lihat dampak beruntun dari kekalahan berturut-turut dan berapa persen profit yang dibutuhkan untuk kembali impas.',
          en: 'Visualize consecutive loss streaks and the exact percentage gain required to recover to break-even.',
        },
        href: '/calculators/drawdown',
        tag: { id: 'Manajemen Modal', en: 'Capital Defense' },
      },
      {
        title: { id: 'Jurnal Trader JGS', en: 'JGS Trader Journal' },
        desc: {
          id: 'Catat alasan entry, kepatuhan terhadap aturan risiko, dan kondisi emosi di setiap transaksi.',
          en: 'Log entry rationale, risk-rule compliance, and emotional state across every trade.',
        },
        href: '/journal',
        tag: { id: 'Evaluasi Mandiri', en: 'Self Review' },
      },
    ],
  },
  {
    id: 'system',
    selectorLabel: {
      id: 'Saya ingin mempelajari sistem trading.',
      en: 'I want to study trading systems.',
    },
    personaTitle: {
      id: 'System Builder — Arsitektur MT5, EA, & Pengujian Kuantitatif',
      en: 'System Builder — MT5 Architecture, EAs, & Quantitative Testing',
    },
    subtitle: {
      id: 'Pelajari cara merancang sistem berbasis aturan, menghindari bahaya martingale/grid tanpa batas, dan mengaudit kualitas backtest MT5.',
      en: 'Study rule-based system design, avoid uncapped martingale/grid hazards, and audit MT5 Strategy Tester backtest quality.',
    },
    description: {
      id: 'Otomatisasi bukan mesin pencetak uang ajaib. Di Quant Lab dan EA Testing Toolkit, kami membedah cara kerja Expert Advisor (EA), filter sesi likuiditas, pembatas kerugian harian (circuit breaker), serta cara menguji strategi dengan data tick nyata.',
      en: 'Automation is not a magic money printer. Inside Quant Lab and the EA Testing Toolkit, we break down Expert Advisor (EA) logic, liquidity session filters, daily loss circuit breakers, and how to stress-test strategies with real tick data.',
    },
    keyFocus: {
      id: [
        'Dokumentasi terbuka arsitektur eksekusi deterministik dan circuit breaker harian',
        'Audit kualitas backtest MT5 (Real Ticks vs Every Tick, uji pelebaran spread, Out-of-Sample)',
        'Riset struktur mikro market XAUUSD dan pasangan mata uang utama di JGS Intelligence',
      ],
      en: [
        'Open documentation on deterministic execution architecture and daily circuit breakers',
        'MT5 backtest quality auditing (Real Ticks vs Every Tick, spread stress testing, Out-of-Sample)',
        'Market microstructure research on XAUUSD and major FX pairs in JGS Intelligence',
      ],
    },
    primaryAction: {
      label: { id: 'Pelajari Dokumentasi Quant Lab', en: 'Explore Quant Lab Documentation' },
      href: '/quant-lab',
    },
    secondaryAction: {
      label: { id: 'Buka EA Testing Toolkit', en: 'Open EA Testing Toolkit' },
      href: '/ea-testing',
    },
    recommendedModules: [
      {
        title: { id: 'JGS Quant Lab', en: 'JGS Quant Lab' },
        desc: {
          id: 'Pelajari lima lapisan pertahanan algoritma: batas lot, stop-loss di sisi server, filter spread, dan penghentian drawdown harian.',
          en: 'Study five layers of algorithmic defense: lot caps, server-side stops, spread filters, and daily drawdown halts.',
        },
        href: '/quant-lab',
        tag: { id: 'Arsitektur Sistem', en: 'System Architecture' },
      },
      {
        title: { id: 'EA Testing Toolkit', en: 'EA Testing Toolkit' },
        desc: {
          id: 'Gunakan daftar periksa interaktif dan kalkulator degradasi ekspektasi untuk mengevaluasi laporan Strategy Tester MT5.',
          en: 'Use interactive checklists and expectancy degradation calculators to audit MT5 Strategy Tester reports.',
        },
        href: '/ea-testing',
        tag: { id: 'Audit Backtest', en: 'Backtest Audit' },
      },
      {
        title: { id: 'JGS Intelligence — Riset Market', en: 'JGS Intelligence — Market Research' },
        desc: {
          id: 'Baca kajian mendalam tentang likuiditas sesi London/New York, spesifikasi kontrak emas, dan dinamika volatilitas.',
          en: 'Read deep-dive research on London/New York session liquidity, gold contract specs, and volatility dynamics.',
        },
        href: '/research',
        tag: { id: 'Riset Terverifikasi', en: 'Verified Research' },
      },
    ],
  },
  {
    id: 'copy',
    selectorLabel: {
      id: 'Saya ingin mempelajari transparansi & copy trading.',
      en: 'I want to review performance transparency & copy trading.',
    },
    personaTitle: {
      id: 'Potential Copy Follower — Transparansi Metrik & Struktur Biaya',
      en: 'Potential Copy Follower — Metric Transparency & Fee Structure',
    },
    subtitle: {
      id: 'Pahami risiko eksekusi, kesesuaian spesifikasi broker, mekanisme High-Water Mark (HWM), dan status pra-peluncuran kami.',
      en: 'Understand execution risks, broker specification compatibility, the High-Water Mark (HWM) mechanism, and our pre-launch status.',
    },
    description: {
      id: 'Edukasi dan tools JGS gratis selamanya. Ke depan, monetisasi utama yang direncanakan adalah layanan copy trading opsional berbasis bagi hasil (usulan 30% dari profit bersih baru melalui mekanisme High-Water Mark). Saat ini layanan copy trading BELUM dibuka untuk publik.',
      en: 'JGS education and tools are permanently free. Our planned future monetization is an optional performance-based copy trading service (proposed 30% fee on eligible net new profits under a High-Water Mark mechanism). Copy trading is currently NOT open for public launch.',
    },
    keyFocus: {
      id: [
        'Skema 11 metrik transparansi performa tanpa angka rekayasa atau klaim palsu',
        'Simulasi terbuka perhitungan High-Water Mark (HWM) 30% hanya pada rekor profit bersih baru',
        'Penjelasan lengkap risiko slippage, perbedaan spesifikasi kontrak broker, dan mekanisme penghentian',
      ],
      en: [
        '11-metric performance transparency schema with zero fabricated numbers or false claims',
        'Interactive simulation of the proposed 30% High-Water Mark (HWM) fee on net new profit highs only',
        'Full disclosure of slippage risks, broker contract mismatches, and withdrawal/termination rules',
      ],
    },
    primaryAction: {
      label: { id: 'Baca Informasi Copy Trading & HWM', en: 'Read Copy Trading & HWM Disclosures' },
      href: '/copy-trading',
    },
    secondaryAction: {
      label: { id: 'Lihat Skema Transparansi Performa', en: 'View Performance Transparency Schema' },
      href: '/performance',
    },
    recommendedModules: [
      {
        title: { id: 'Informasi Copy Trading & Simulasi HWM', en: 'Copy Trading Disclosures & HWM Simulator' },
        desc: {
          id: 'Pelajari cara kerja penyalinan posisi, perbedaan profit terealisasi vs mengambang, dan simulasi High-Water Mark.',
          en: 'Learn how trade replication works, realized vs. unrealized profit distinctions, and simulate High-Water Mark fees.',
        },
        href: '/copy-trading',
        tag: { id: 'Edukasi & Ketentuan', en: 'Disclosure & Rules' },
      },
      {
        title: { id: 'Pusat Transparansi Performa', en: 'Performance Transparency Center' },
        desc: {
          id: 'Tinjau 11 metrik wajib (Balance, Equity, Max Drawdown, Profit Factor, Biaya Trading) dalam status pra-peluncuran yang jujur.',
          en: 'Inspect the 11 required metrics (Balance, Equity, Max Drawdown, Profit Factor, Trading Costs) in an honest pre-launch state.',
        },
        href: '/performance',
        tag: { id: 'Audit Pra-Peluncuran', en: 'Pre-Launch Audit' },
      },
      {
        title: { id: 'Tentang Model Bisnis Gratis JGS', en: 'About the JGS Free Ecosystem Model' },
        desc: {
          id: 'Mengapa seluruh kurikulum dan kalkulator kami gratis tanpa paywall atau kewajiban deposit.',
          en: 'Why all of our curriculum modules and calculators remain free without paywalls or deposit requirements.',
        },
        href: '/about',
        tag: { id: 'Piagam Transparansi', en: 'Transparency Charter' },
      },
    ],
  },
];

interface BrokerDemoPreset {
  id: string;
  label: { id: string; en: string };
  denomination: 'USC' | 'USD';
  contractNote: { id: string; en: string };
  tickSize: number;
  tickValuePerLot: number;
  minLot: number;
}

const BROKER_DEMO_PRESETS: BrokerDemoPreset[] = [
  {
    id: 'cent-micro-spec',
    label: {
      id: 'Contoh Spesifikasi A: Akun Cent (Kontrak Mikro 1 oz / lot)',
      en: 'Sample Spec A: Cent Account (Micro Contract 1 oz / lot)',
    },
    denomination: 'USC',
    contractNote: {
      id: 'Saldo dalam USC (2.500 USC = $25). Broker ini menetapkan kontrak simbol Cent 100x lebih kecil dari standar (nilai tick 10 USC per $0,10 gerak harga per 1.00 lot).',
      en: 'Balance in USC (2,500 USC = $25). This broker defines its Cent symbol contract 100x smaller than standard (tick value 10 USC per $0.10 price move per 1.00 lot).',
    },
    tickSize: 0.1,
    tickValuePerLot: 10, // 10 USC per 0.10 move per 1.0 lot => 0.01 lot = 0.10 USC per 0.10 move
    minLot: 0.01,
  },
  {
    id: 'cent-standard-contract',
    label: {
      id: 'Contoh Spesifikasi B: Akun Cent (Ukuran Kontrak Tetap 100 oz / lot)',
      en: 'Sample Spec B: Cent Account (Full 100 oz Contract Size in USC)',
    },
    denomination: 'USC',
    contractNote: {
      id: 'PENTING: Saldo ditampilkan dalam USC (2.500 USC = $25), tetapi broker ini TIDAK mengecilkan ukuran kontrak simbol XAUUSD (tetap 100 oz / lot = 1.000 USC per gerak $0,10 per 1.00 lot).',
      en: 'IMPORTANT: Balance is denominated in USC (2,500 USC = $25), but this broker does NOT shrink the XAUUSD symbol contract size (still 100 oz / lot = 1,000 USC per $0.10 move per 1.00 lot).',
    },
    tickSize: 0.1,
    tickValuePerLot: 1000, // 1,000 USC ($10) per 0.10 move per 1.0 lot => 0.01 lot = 10 USC ($0.10) per 0.10 move
    minLot: 0.01,
  },
  {
    id: 'usd-standard',
    label: {
      id: 'Contoh Spesifikasi C: Akun Standar USD (100 oz / lot)',
      en: 'Sample Spec C: Standard USD Account (100 oz / lot)',
    },
    denomination: 'USD',
    contractNote: {
      id: 'Saldo dalam USD ($25). Kontrak standar 100 troy oz per 1.00 lot ($10 per gerak $0,10 per 1.00 lot). Pada modal $25, lot minimum 0,01 sering kali melampaui batas risiko ketat.',
      en: 'Balance in USD ($25). Standard 100 troy oz contract per 1.00 lot ($10 per $0.10 move per 1.00 lot). On a $25 balance, the 0.01 minimum lot frequently exceeds strict risk limits.',
    },
    tickSize: 0.1,
    tickValuePerLot: 10, // $10 USD per 0.10 move per 1.0 lot
    minLot: 0.01,
  },
];

export function EditorialHomepage() {
  const { isId, l } = useLocale();
  const [selectedPersona, setSelectedPersona] = useState<PersonaId>('beginner');

  // Interactive Broker Specification & Position Sizing preview state
  const [selectedSpecId, setSelectedSpecId] = useState<string>('cent-micro-spec');
  const [capitalUsd, setCapitalUsd] = useState<number>(25);
  const [riskPercent, setRiskPercent] = useState<number>(2.0);
  const [stopDistancePrice, setStopDistancePrice] = useState<number>(8.0); // $8 gold price stop distance

  const activePersona = useMemo(
    () => PERSONA_JOURNEYS.find((p) => p.id === selectedPersona) ?? PERSONA_JOURNEYS[0],
    [selectedPersona]
  );

  const activeBrokerPreset = useMemo(
    () => BROKER_DEMO_PRESETS.find((b) => b.id === selectedSpecId) ?? BROKER_DEMO_PRESETS[0],
    [selectedSpecId]
  );

  const sizingPreview = useMemo(() => {
    const equityInAccountUnits =
      activeBrokerPreset.denomination === 'USC' ? capitalUsd * 100 : capitalUsd;

    return calculateBrokerSymbolPositionSize({
      equity: equityInAccountUnits,
      accountDenomination: activeBrokerPreset.denomination,
      riskPercentage: riskPercent,
      stopLossDistance: stopDistancePrice,
      tickSize: activeBrokerPreset.tickSize,
      tickValuePerLot: activeBrokerPreset.tickValuePerLot,
      minimumLot: activeBrokerPreset.minLot,
      maximumLot: 100,
      volumeStep: 0.01,
    });
  }, [activeBrokerPreset, capitalUsd, riskPercent, stopDistancePrice]);

  return (
    <div className="min-h-screen bg-plum-deep text-ivory selection:bg-gold-metallic selection:text-plum-deep">
      {/* =====================================================================
          SECTION 1: HERO SECTION (CLARITY, POSITIONING, SELECTIVE MASCOT)
         ===================================================================== */}
      <section className="relative overflow-hidden border-b border-white/[0.08] pt-10 pb-16 lg:pt-16 lg:pb-24">
        <div
          aria-hidden="true"
          className="pointer-events-none absolute -top-28 left-1/4 h-[460px] w-[460px] rounded-full bg-purple-royal/25 blur-[130px]"
        />
        <div
          aria-hidden="true"
          className="pointer-events-none absolute bottom-0 right-10 h-[360px] w-[360px] rounded-full bg-gold-metallic/10 blur-[120px]"
        />

        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 items-center gap-12 lg:grid-cols-12 lg:gap-10">
            {/* Left Editorial Column (7 cols) */}
            <div className="lg:col-span-7">
              <div className="mb-6 inline-flex flex-wrap items-center gap-2.5 rounded-full border border-gold-metallic/35 bg-plum-surface/90 px-4 py-1.5 text-sm font-medium text-gold-champagne">
                <Sparkles className="h-4 w-4 text-gold-metallic" />
                <span>
                  {isId
                    ? 'Ekosistem Edukasi & Teknologi Trading 100% Gratis'
                    : '100% Free Trading Education & Financial Technology Ecosystem'}
                </span>
              </div>

              <h1 className="font-display text-4xl font-bold leading-[1.12] tracking-tight text-ivory sm:text-5xl lg:text-6xl">
                {isId ? (
                  <>
                    Mulai dari paham.{' '}
                    <span className="text-gold-metallic">Bukan dari modal.</span>
                  </>
                ) : (
                  <>
                    Start with understanding.{' '}
                    <span className="text-gold-metallic">Not account size.</span>
                  </>
                )}
              </h1>

              <p className="mt-6 max-w-2xl text-lg leading-relaxed text-ivory/85 sm:text-xl">
                {isId
                  ? 'Belajar memahami market, mengelola risiko, dan membangun strategi trading melalui edukasi dan tools gratis.'
                  : 'Learn to understand markets, manage risk, and develop trading strategies through free education and practical tools.'}
              </p>

              {/* Core Value Badges — Clear, beginner-friendly, zero jargon */}
              <div className="mt-6 flex flex-wrap items-center gap-3 text-sm text-ivory/80">
                <span className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/[0.03] px-3.5 py-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  {isId ? 'Tanpa Biaya Langganan' : 'No Subscription Fees'}
                </span>
                <span className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/[0.03] px-3.5 py-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  {isId ? 'Tanpa Paywall' : 'No Paywalls'}
                </span>
                <span className="inline-flex items-center gap-2 rounded-lg border border-white/10 bg-white/[0.03] px-3.5 py-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  {isId ? 'Tanpa Paksaan Deposit Broker' : 'No Forced Broker Deposits'}
                </span>
              </div>

              {/* Primary & Secondary CTAs */}
              <div className="mt-9 flex flex-col gap-4 sm:flex-row sm:items-center">
                <Link
                  href={l('/academy')}
                  className="inline-flex items-center justify-center gap-3 rounded-xl bg-gold-metallic px-7 py-4 text-base font-semibold text-plum-deep shadow-[0_12px_32px_rgba(212,175,55,0.25)] transition-all hover:bg-gold-champagne"
                >
                  <span>{isId ? 'Mulai Belajar' : 'Start Learning'}</span>
                  <ArrowRight className="h-5 w-5" />
                </Link>
                <Link
                  href={l('/tools')}
                  className="inline-flex items-center justify-center gap-3 rounded-xl border border-white/20 bg-plum-surface/80 px-7 py-4 text-base font-semibold text-ivory transition-all hover:border-gold-metallic/50 hover:bg-white/[0.06]"
                >
                  <Calculator className="h-5 w-5 text-gold-metallic" />
                  <span>{isId ? 'Coba Trading Tools' : 'Explore Trading Tools'}</span>
                </Link>
              </div>
            </div>

            {/* Right Column: Selective Jey Mascot Brand Card (5 cols) */}
            <div className="lg:col-span-5">
              <div className="relative mx-auto max-w-md overflow-hidden rounded-2xl border border-gold-metallic/30 bg-gradient-to-b from-[#170E28] via-[#10091D] to-[#0B0614] p-6 shadow-2xl">
                <div className="flex items-center justify-between border-b border-white/10 pb-4">
                  <div>
                    <p className="text-xs font-semibold text-gold-metallic">
                      THE JEY GANG STRATEGIST
                    </p>
                    <p className="text-sm font-medium text-ivory/80">
                      Small Capital. Serious Strategy.
                    </p>
                  </div>
                  <span className="rounded-full border border-purple-electric/40 bg-purple-royal/30 px-3 py-1 text-xs font-medium text-purple-electric">
                    {isId ? 'Edukasi Terbuka' : 'Open Education'}
                  </span>
                </div>

                <div className="relative my-5 aspect-[4/4] w-full overflow-hidden rounded-xl border border-white/10 bg-[#08050E]">
                  <Image
                    src="/images/jey-mascot.png"
                    alt="Jey — Chief Risk Strategist Mascot of The Jey Gang Strategist"
                    fill
                    priority
                    sizes="(max-width: 768px) 90vw, 420px"
                    className="object-cover object-top"
                  />
                </div>

                <div className="rounded-xl border border-white/10 bg-white/[0.03] p-4">
                  <p className="text-sm leading-relaxed text-ivory/90">
                    {isId
                      ? '“Keahlian utama dalam trading bukanlah menebak arah harga berikutnya, melainkan memastikan satu kesalahan tidak pernah menghentikan langkahmu di market.”'
                      : '“The foundational skill in trading is not predicting the next candle—it is making sure a single mistake never takes you out of the market.”'}
                  </p>
                  <div className="mt-3 flex items-center justify-between border-t border-white/10 pt-2.5 text-xs text-ivory/65">
                    <span>Jey — Chief Risk Strategist</span>
                    <Link
                      href={l('/onboarding')}
                      className="font-semibold text-gold-champagne hover:text-gold-metallic"
                    >
                      {isId ? 'Panduan Pemula →' : 'Guided Onboarding →'}
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          SECTION 2: INTERACTIVE 4-PERSONA USER JOURNEY SELECTOR
         ===================================================================== */}
      <section
        id="user-journey-selector"
        className="border-b border-white/[0.08] bg-[#0B0714] py-16 lg:py-24"
      >
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="max-w-3xl">
            <span className="inline-flex items-center gap-2 rounded-md border border-purple-electric/30 bg-purple-royal/20 px-3 py-1 text-xs font-semibold text-purple-electric">
              <Compass className="h-3.5 w-3.5" />
              {isId ? 'Pilih Jalur Belajar Anda' : 'Choose Your Starting Path'}
            </span>
            <h2 className="mt-3 font-display text-3xl font-bold text-ivory sm:text-4xl">
              {isId
                ? 'Mulai Sesuai Posisi Anda Saat Ini'
                : 'Start From Where You Are Today'}
            </h2>
            <p className="mt-3 text-base leading-relaxed text-ivory/75 sm:text-lg">
              {isId
                ? 'Setiap orang datang dengan kebutuhan berbeda. Pilih pernyataan yang paling menggambarkan diri Anda untuk melihat rekomendasi modul dan langkah belajar yang paling relevan.'
                : 'Every visitor arrives with different goals. Select the statement that best describes you to unlock a tailored learning path and toolset.'}
            </p>
          </div>

          {/* 4 Persona Selector Buttons */}
          <div
            role="tablist"
            aria-label={isId ? 'Pilih profil pengguna' : 'Select user persona'}
            className="mt-8 grid grid-cols-1 gap-3.5 sm:grid-cols-2 lg:grid-cols-4"
          >
            {PERSONA_JOURNEYS.map((journey, index) => {
              const isSelected = journey.id === selectedPersona;
              return (
                <button
                  key={journey.id}
                  type="button"
                  role="tab"
                  aria-selected={isSelected}
                  onClick={() => setSelectedPersona(journey.id)}
                  className={`flex flex-col justify-between rounded-xl border p-5 text-left transition-all ${
                    isSelected
                      ? 'border-gold-metallic bg-plum-surface shadow-[0_10px_30px_rgba(212,175,55,0.12)]'
                      : 'border-white/10 bg-white/[0.02] hover:border-white/25 hover:bg-white/[0.04]'
                  }`}
                >
                  <div className="flex items-center justify-between gap-2">
                    <span
                      className={`inline-flex h-7 w-7 items-center justify-center rounded-lg text-xs font-bold ${
                        isSelected
                          ? 'bg-gold-metallic text-plum-deep'
                          : 'bg-white/10 text-ivory/70'
                      }`}
                    >
                      0{index + 1}
                    </span>
                    <span
                      className={`text-xs font-medium ${
                        isSelected ? 'text-gold-metallic' : 'text-ivory/50'
                      }`}
                    >
                      {isSelected
                        ? isId
                          ? 'Jalur Aktif'
                          : 'Active Path'
                        : isId
                        ? 'Klik untuk memilih'
                        : 'Select path'}
                    </span>
                  </div>
                  <p className="mt-4 font-display text-lg font-bold text-ivory">
                    “{isId ? journey.selectorLabel.id : journey.selectorLabel.en}”
                  </p>
                </button>
              );
            })}
          </div>

          {/* Active Persona Detail Panel */}
          <div className="mt-8 rounded-2xl border border-white/15 bg-plum-surface/90 p-6 sm:p-8 lg:p-10">
            <div className="grid grid-cols-1 gap-8 lg:grid-cols-12">
              <div className="lg:col-span-5 flex flex-col justify-between">
                <div>
                  <p className="text-sm font-semibold text-gold-metallic">
                    {isId ? activePersona.personaTitle.id : activePersona.personaTitle.en}
                  </p>
                  <h3 className="mt-2 font-display text-2xl font-bold text-ivory sm:text-3xl">
                    {isId ? activePersona.subtitle.id : activePersona.subtitle.en}
                  </h3>
                  <p className="mt-4 text-base leading-relaxed text-ivory/80">
                    {isId ? activePersona.description.id : activePersona.description.en}
                  </p>

                  <ul className="mt-6 space-y-2.5">
                    {(isId ? activePersona.keyFocus.id : activePersona.keyFocus.en).map(
                      (point) => (
                        <li
                          key={point}
                          className="flex items-start gap-2.5 text-sm text-ivory/85"
                        >
                          <CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-gold-metallic" />
                          <span>{point}</span>
                        </li>
                      )
                    )}
                  </ul>
                </div>

                <div className="mt-8 flex flex-wrap items-center gap-3">
                  <Link
                    href={l(activePersona.primaryAction.href)}
                    className="inline-flex items-center gap-2 rounded-xl bg-gold-metallic px-5 py-3 text-sm font-semibold text-plum-deep transition-colors hover:bg-gold-champagne"
                  >
                    <span>
                      {isId
                        ? activePersona.primaryAction.label.id
                        : activePersona.primaryAction.label.en}
                    </span>
                    <ArrowRight className="h-4 w-4" />
                  </Link>
                  <Link
                    href={l(activePersona.secondaryAction.href)}
                    className="inline-flex items-center gap-2 rounded-xl border border-white/15 bg-white/[0.04] px-5 py-3 text-sm font-semibold text-ivory transition-colors hover:border-gold-metallic/40 hover:text-gold-champagne"
                  >
                    <span>
                      {isId
                        ? activePersona.secondaryAction.label.id
                        : activePersona.secondaryAction.label.en}
                    </span>
                  </Link>
                </div>
              </div>

              {/* 3 Recommended Modules for the Selected Persona */}
              <div className="lg:col-span-7 grid grid-cols-1 gap-4 sm:grid-cols-3">
                {activePersona.recommendedModules.map((mod) => (
                  <Link
                    key={mod.href}
                    href={l(mod.href)}
                    className="group flex flex-col justify-between rounded-xl border border-white/10 bg-[#0B0714] p-5 transition-all hover:border-gold-metallic/45 hover:bg-white/[0.03]"
                  >
                    <div>
                      <span className="inline-block rounded-md bg-purple-royal/30 px-2.5 py-1 text-xs font-semibold text-purple-electric">
                        {isId ? mod.tag.id : mod.tag.en}
                      </span>
                      <h4 className="mt-3 font-display text-lg font-bold text-ivory group-hover:text-gold-champagne">
                        {isId ? mod.title.id : mod.title.en}
                      </h4>
                      <p className="mt-2 text-sm leading-relaxed text-ivory/70">
                        {isId ? mod.desc.id : mod.desc.en}
                      </p>
                    </div>
                    <div className="mt-5 inline-flex items-center gap-1.5 text-xs font-semibold text-gold-metallic">
                      <span>{isId ? 'Buka Modul' : 'Open Module'}</span>
                      <ArrowRight className="h-3.5 w-3.5 transition-transform group-hover:translate-x-1" />
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          SECTION 3: BROKER SPECIFICATION & CENT DENOMINATION INTERACTIVE LAB
         ===================================================================== */}
      <section className="border-b border-white/[0.08] py-16 lg:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:items-start">
            {/* Left Explanation Column (5 cols) */}
            <div className="lg:col-span-5">
              <span className="inline-flex items-center gap-2 rounded-md border border-gold-metallic/30 bg-gold-metallic/10 px-3 py-1 text-xs font-semibold text-gold-champagne">
                <Scale className="h-3.5 w-3.5 text-gold-metallic" />
                {isId ? 'Akurasi Finansial & Teknis' : 'Financial & Technical Accuracy'}
              </span>
              <h2 className="mt-3 font-display text-3xl font-bold text-ivory sm:text-4xl">
                {isId
                  ? 'Mengapa Denominasi Cent Berbeda dengan Ukuran Kontrak'
                  : 'Why Cent Denomination Is Distinct From Contract Size'}
              </h2>
              <p className="mt-4 text-base leading-relaxed text-ivory/80">
                {isId
                  ? 'Banyak pemula mengira semua akun Cent otomatis memperkecil risiko 100 kali lipat pada semua instrumen. Faktanya, konversi 1 USD = 100 USC hanyalah satuan saldo akun.'
                  : 'Many beginners assume every Cent account automatically shrinks risk by 100x across all symbols. In reality, 1 USD = 100 USC only changes the balance display unit.'}
              </p>

              <div className="mt-6 space-y-4 rounded-xl border border-white/10 bg-plum-surface/70 p-5">
                <h3 className="text-base font-bold text-gold-champagne">
                  {isId
                    ? '3 Hal yang Wajib Diperiksa di MT5:'
                    : '3 Specifications You Must Verify in MT5:'}
                </h3>
                <ul className="space-y-3 text-sm leading-relaxed text-ivory/80">
                  <li className="flex items-start gap-2.5">
                    <span className="mt-0.5 font-bold text-gold-metallic">1.</span>
                    <span>
                      <strong>{isId ? 'Ukuran Kontrak (Contract Size):' : 'Contract Size:'}</strong>{' '}
                      {isId
                        ? 'Apakah simbol Cent di broker Anda menggunakan kontrak mikro atau tetap menggunakan ukuran kontrak standar?'
                        : 'Does your broker’s Cent symbol use a reduced micro contract or keep the standard contract size?'}
                    </span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="mt-0.5 font-bold text-gold-metallic">2.</span>
                    <span>
                      <strong>{isId ? 'Nilai Tick & Ukuran Tick:' : 'Tick Size & Tick Value:'}</strong>{' '}
                      {isId
                        ? 'Berapa nilai untung/rugi per 1.00 lot untuk setiap perubahan harga minimum?'
                        : 'What is the exact profit/loss per 1.00 lot for each minimum price increment?'}
                    </span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="mt-0.5 font-bold text-gold-metallic">3.</span>
                    <span>
                      <strong>{isId ? 'Lot Minimum & Step Volume:' : 'Minimum Lot & Volume Step:'}</strong>{' '}
                      {isId
                        ? 'Jika lot minimum (misal 0.01) menghasilkan kerugian lebih besar dari batas risiko Anda, transaksi tersebut harus ditolak.'
                        : 'If the minimum lot (e.g., 0.01) creates a loss larger than your risk budget, the trade must be rejected.'}
                    </span>
                  </li>
                </ul>
              </div>

              <div className="mt-6 flex flex-wrap gap-3">
                <Link
                  href={l('/calculators/cent')}
                  className="inline-flex items-center gap-2 rounded-xl bg-white/10 px-5 py-3 text-sm font-semibold text-ivory transition-colors hover:bg-white/15"
                >
                  <span>{isId ? 'Buka Cent Lab Lengkap' : 'Open Full Cent Lab'}</span>
                  <ArrowRight className="h-4 w-4 text-gold-metallic" />
                </Link>
                <Link
                  href={l('/calculators/position-size')}
                  className="inline-flex items-center gap-2 rounded-xl border border-gold-metallic/35 px-5 py-3 text-sm font-semibold text-gold-champagne transition-colors hover:bg-gold-metallic/10"
                >
                  <span>
                    {isId ? 'Kalkulator Position Sizing' : 'Position Sizing Calculator'}
                  </span>
                </Link>
              </div>
            </div>

            {/* Right Interactive Simulator Column (7 cols) */}
            <div className="lg:col-span-7 rounded-2xl border border-white/15 bg-plum-surface/90 p-6 sm:p-8 shadow-xl">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
                <div>
                  <h3 className="font-display text-xl font-bold text-ivory">
                    {isId
                      ? 'Simulasi Cepat: Spesifikasi Broker vs Ukuran Lot'
                      : 'Interactive Preview: Broker Spec vs. Lot Sizing'}
                  </h3>
                  <p className="text-sm text-ivory/70">
                    {isId
                      ? 'Bandingkan bagaimana modal $25 yang sama menghasilkan status risiko berbeda tergantung spesifikasi simbol broker.'
                      : 'Compare how the exact same $25 capital yields different risk outcomes depending on the broker’s symbol specification.'}
                  </p>
                </div>
              </div>

              {/* Broker Preset Selector */}
              <div className="mt-5">
                <label className="jgs-label">
                  {isId
                    ? 'Pilih Contoh Spesifikasi Simbol Broker'
                    : 'Select Sample Broker Symbol Specification'}
                </label>
                <div className="grid grid-cols-1 gap-2.5">
                  {BROKER_DEMO_PRESETS.map((preset) => {
                    const active = preset.id === selectedSpecId;
                    return (
                      <button
                        key={preset.id}
                        type="button"
                        onClick={() => setSelectedSpecId(preset.id)}
                        className={`rounded-xl border p-3.5 text-left transition-all ${
                          active
                            ? 'border-gold-metallic bg-gold-metallic/10 text-ivory'
                            : 'border-white/10 bg-[#0B0714] text-ivory/75 hover:border-white/25'
                        }`}
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold">
                            {isId ? preset.label.id : preset.label.en}
                          </span>
                          <span className="rounded bg-white/10 px-2 py-0.5 font-mono text-xs text-gold-champagne">
                            {preset.denomination}
                          </span>
                        </div>
                        <p className="mt-1.5 text-xs leading-relaxed text-ivory/70">
                          {isId ? preset.contractNote.id : preset.contractNote.en}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Sliders / Numeric Controls */}
              <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
                <div className="rounded-xl border border-white/10 bg-[#0B0714] p-4">
                  <div className="flex items-center justify-between text-xs text-ivory/70">
                    <span>{isId ? 'Modal (USD)' : 'Capital (USD)'}</span>
                    <span className="font-mono font-bold text-gold-champagne">
                      ${capitalUsd}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={10}
                    max={200}
                    step={5}
                    value={capitalUsd}
                    onChange={(e) => setCapitalUsd(Number(e.target.value))}
                    aria-label={isId ? 'Modal dalam USD' : 'Capital in USD'}
                    className="mt-3 w-full accent-gold-metallic"
                  />
                  <p className="mt-1 text-xs text-ivory/55">
                    {activeBrokerPreset.denomination === 'USC'
                      ? `${(capitalUsd * 100).toLocaleString()} USC`
                      : `$${capitalUsd.toFixed(2)} USD`}
                  </p>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#0B0714] p-4">
                  <div className="flex items-center justify-between text-xs text-ivory/70">
                    <span>{isId ? 'Batas Risiko / Trade' : 'Risk Limit / Trade'}</span>
                    <span className="font-mono font-bold text-gold-champagne">
                      {riskPercent.toFixed(1)}%
                    </span>
                  </div>
                  <input
                    type="range"
                    min={0.5}
                    max={5}
                    step={0.5}
                    value={riskPercent}
                    onChange={(e) => setRiskPercent(Number(e.target.value))}
                    aria-label={isId ? 'Persentase risiko' : 'Risk percentage'}
                    className="mt-3 w-full accent-gold-metallic"
                  />
                  <p className="mt-1 text-xs text-ivory/55">
                    {isId ? 'Anggaran risiko:' : 'Risk budget:'} $
                    {((capitalUsd * riskPercent) / 100).toFixed(2)} USD
                  </p>
                </div>

                <div className="rounded-xl border border-white/10 bg-[#0B0714] p-4">
                  <div className="flex items-center justify-between text-xs text-ivory/70">
                    <span>{isId ? 'Jarak Stop-Loss' : 'Stop-Loss Distance'}</span>
                    <span className="font-mono font-bold text-gold-champagne">
                      ${stopDistancePrice.toFixed(1)}
                    </span>
                  </div>
                  <input
                    type="range"
                    min={2}
                    max={20}
                    step={1}
                    value={stopDistancePrice}
                    onChange={(e) => setStopDistancePrice(Number(e.target.value))}
                    aria-label={isId ? 'Jarak Stop Loss' : 'Stop Loss Distance'}
                    className="mt-3 w-full accent-gold-metallic"
                  />
                  <p className="mt-1 text-xs text-ivory/55">
                    {(stopDistancePrice / activeBrokerPreset.tickSize).toFixed(0)} ticks
                  </p>
                </div>
              </div>

              {/* Calculation Result Display */}
              <div
                className={`mt-6 rounded-xl border p-5 ${
                  sizingPreview.isExecutable
                    ? 'border-emerald-500/40 bg-emerald-950/20'
                    : 'border-rose-500/50 bg-rose-950/25'
                }`}
              >
                <div className="flex flex-wrap items-center justify-between gap-4">
                  <div>
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-md px-2.5 py-1 text-xs font-semibold ${
                        sizingPreview.isExecutable
                          ? 'bg-emerald-500/20 text-emerald-300'
                          : 'bg-rose-500/20 text-rose-300'
                      }`}
                    >
                      {sizingPreview.isExecutable ? (
                        <CheckCircle2 className="h-3.5 w-3.5" />
                      ) : (
                        <AlertTriangle className="h-3.5 w-3.5" />
                      )}
                      {sizingPreview.isExecutable
                        ? isId
                          ? 'Ukuran Lot Valid & Sesuai Batas Risiko'
                          : 'Valid Lot Size Within Risk Budget'
                        : isId
                        ? 'DITOLAK — Lot Minimum Broker Melampaui Batas Risiko'
                        : 'REJECTED — Broker Minimum Lot Exceeds Risk Limit'}
                    </span>
                    <p className="mt-2 text-sm text-ivory/85">
                      {sizingPreview.isExecutable &&
                      sizingPreview.approvedLotSize !== null &&
                      sizingPreview.actualRiskAmount !== null &&
                      sizingPreview.actualRiskPercentage !== null
                        ? isId
                          ? `Ukuran lot yang direkomendasikan: ${sizingPreview.approvedLotSize.toFixed(
                              2
                            )} lot (Risiko aktual: ${sizingPreview.actualRiskAmount.toFixed(
                              2
                            )} ${activeBrokerPreset.denomination} / ${sizingPreview.actualRiskPercentage.toFixed(
                              2
                            )}% dari ekuitas).`
                          : `Recommended volume: ${sizingPreview.approvedLotSize.toFixed(
                              2
                            )} lots (Actual risk: ${sizingPreview.actualRiskAmount.toFixed(
                              2
                            )} ${activeBrokerPreset.denomination} / ${sizingPreview.actualRiskPercentage.toFixed(
                              2
                            )}% of equity).`
                        : isId
                        ? `Pada spesifikasi ini, lot minimum ${
                            activeBrokerPreset.minLot
                          } lot membutuhkan risiko ${sizingPreview.lossAtMinimumLot.toFixed(
                            2
                          )} ${activeBrokerPreset.denomination} (${sizingPreview.minimumLotRiskPercentage.toFixed(
                            2
                          )}% dari saldo), melampaui batas ${riskPercent.toFixed(
                            1
                          )}% Anda. Jangan membulatkan lot ke atas!`
                        : `Under this specification, the minimum ${
                            activeBrokerPreset.minLot
                          } lot risks ${sizingPreview.lossAtMinimumLot.toFixed(
                            2
                          )} ${activeBrokerPreset.denomination} (${sizingPreview.minimumLotRiskPercentage.toFixed(
                            2
                          )}% of equity), exceeding your ${riskPercent.toFixed(
                            1
                          )}% cap. Never round up to minimum volume!`}
                    </p>
                  </div>

                  <div className="text-right">
                    <span className="block text-xs text-ivory/60">
                      {isId ? 'Lot Direkomendasikan' : 'Recommended Lot'}
                    </span>
                    <span className="font-mono text-3xl font-bold text-gold-metallic">
                      {sizingPreview.isExecutable && sizingPreview.approvedLotSize !== null
                        ? `${sizingPreview.approvedLotSize.toFixed(2)}`
                        : isId
                        ? '0.00 (TOLAK)'
                        : '0.00 (REJECT)'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          SECTION 4: COMPLETE FREE ECOSYSTEM ARCHITECTURE (6 PILLARS)
         ===================================================================== */}
      <section className="border-b border-white/[0.08] bg-[#0B0714] py-16 lg:py-24">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
            <div className="max-w-2xl">
              <span className="inline-flex items-center gap-2 rounded-md border border-white/15 bg-white/[0.04] px-3 py-1 text-xs font-semibold text-gold-champagne">
                <Layers className="h-3.5 w-3.5 text-gold-metallic" />
                {isId ? 'Arsitektur Platform JGS' : 'JGS Platform Architecture'}
              </span>
              <h2 className="mt-3 font-display text-3xl font-bold text-ivory sm:text-4xl">
                {isId
                  ? 'Seluruh Modul Edukasi, Riset, & Kalkulator Gratis'
                  : 'Complete Suite of Free Education, Research, & Tools'}
              </h2>
            </div>
            <p className="max-w-md text-sm leading-relaxed text-ivory/70">
              {isId
                ? 'Navigasi sederhana yang dirancang agar pemula maupun trader berpengalaman dapat langsung mengakses materi tanpa penghalang registrasi.'
                : 'Streamlined navigation built so beginners and experienced traders alike can access every module immediately with zero registration barriers.'}
            </p>
          </div>

          <div className="mt-10 grid grid-cols-1 gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Pillar 1: Learn */}
            <div className="flex flex-col justify-between rounded-2xl border border-white/10 bg-plum-surface/75 p-6">
              <div>
                <div className="flex items-center justify-between">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-purple-royal/35 text-gold-metallic">
                    <BookOpen className="h-5 w-5" />
                  </span>
                  <span className="rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-300">
                    {isId ? '100% Gratis' : '100% Free'}
                  </span>
                </div>
                <h3 className="mt-5 font-display text-xl font-bold text-ivory">
                  {isId ? '1. Belajar (Academy & Kamus)' : '1. Learn (Academy & Dictionary)'}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-ivory/75">
                  {isId
                    ? 'Kurikulum terstruktur dari tingkat Pemula hingga Mahir, dilengkapi Kamus Trading interaktif dan Simulasi Skenario Historis.'
                    : 'Structured curriculum from Beginner to Advanced tracks, paired with an interactive Trading Dictionary and Historical Scenario Playground.'}
                </p>
              </div>
              <div className="mt-6 flex flex-wrap gap-2 border-t border-white/10 pt-4">
                <Link
                  href={l('/academy')}
                  className="text-xs font-semibold text-gold-champagne hover:text-gold-metallic"
                >
                  JGS Academy →
                </Link>
                <span className="text-white/20">•</span>
                <Link
                  href={l('/dictionary')}
                  className="text-xs font-semibold text-ivory/80 hover:text-gold-champagne"
                >
                  {isId ? 'Kamus Trading' : 'Dictionary'} →
                </Link>
                <span className="text-white/20">•</span>
                <Link
                  href={l('/playground')}
                  className="text-xs font-semibold text-ivory/80 hover:text-gold-champagne"
                >
                  Playground →
                </Link>
              </div>
            </div>

            {/* Pillar 2: Trading Tools */}
            <div className="flex flex-col justify-between rounded-2xl border border-white/10 bg-plum-surface/75 p-6">
              <div>
                <div className="flex items-center justify-between">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-purple-royal/35 text-gold-metallic">
                    <Calculator className="h-5 w-5" />
                  </span>
                  <span className="rounded-full bg-emerald-500/15 px-3 py-1 text-xs font-semibold text-emerald-300">
                    {isId ? 'Tanpa Login' : 'No Login Needed'}
                  </span>
                </div>
                <h3 className="mt-5 font-display text-xl font-bold text-ivory">
                  {isId ? '2. Trading Tools & Kalkulator' : '2. Trading Tools & Calculators'}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-ivory/75">
                  {isId
                    ? 'Cent Lab, Position Sizing berbasis spesifikasi simbol broker, Simulator Drawdown, dan Jurnal Trader dengan ekspor CSV aman.'
                    : 'Cent Lab, broker-symbol Position Sizing Calculator, Drawdown Simulator, and Trader Journal with safe CSV export.'}
                </p>
              </div>
              <div className="mt-6 flex flex-wrap gap-2 border-t border-white/10 pt-4">
                <Link
                  href={l('/calculators/cent')}
                  className="text-xs font-semibold text-gold-champagne hover:text-gold-metallic"
                >
                  Cent Lab →
                </Link>
                <span className="text-white/20">•</span>
                <Link
                  href={l('/calculators/position-size')}
                  className="text-xs font-semibold text-ivory/80 hover:text-gold-champagne"
                >
                  Position Sizing →
                </Link>
                <span className="text-white/20">•</span>
                <Link
                  href={l('/journal')}
                  className="text-xs font-semibold text-ivory/80 hover:text-gold-champagne"
                >
                  {isId ? 'Jurnal' : 'Journal'} →
                </Link>
              </div>
            </div>

            {/* Pillar 3: Market Research */}
            <div className="flex flex-col justify-between rounded-2xl border border-white/10 bg-plum-surface/75 p-6">
              <div>
                <div className="flex items-center justify-between">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-purple-royal/35 text-gold-metallic">
                    <Newspaper className="h-5 w-5" />
                  </span>
                  <span className="rounded-full bg-purple-royal/40 px-3 py-1 text-xs font-semibold text-purple-electric">
                    {isId ? 'Sumber Terverifikasi' : 'Verified Sources'}
                  </span>
                </div>
                <h3 className="mt-5 font-display text-xl font-bold text-ivory">
                  {isId
                    ? '3. Riset Market (JGS Intelligence)'
                    : '3. Market Research (JGS Intelligence)'}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-ivory/75">
                  {isId
                    ? 'Artikel edukasi struktur market, likuiditas sesi global, dan panduan spesifikasi kontrak dengan tanggal publikasi dan referensi resmi.'
                    : 'Market structure articles, global session liquidity guides, and contract specification breakdowns with explicit dates and primary citations.'}
                </p>
              </div>
              <div className="mt-6 flex flex-wrap gap-2 border-t border-white/10 pt-4">
                <Link
                  href={l('/research')}
                  className="text-xs font-semibold text-gold-champagne hover:text-gold-metallic"
                >
                  {isId ? 'Buka JGS Intelligence →' : 'Open JGS Intelligence →'}
                </Link>
              </div>
            </div>

            {/* Pillar 4: Our Strategy & Quant Lab */}
            <div className="flex flex-col justify-between rounded-2xl border border-white/10 bg-plum-surface/75 p-6">
              <div>
                <div className="flex items-center justify-between">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-purple-royal/35 text-gold-metallic">
                    <Cpu className="h-5 w-5" />
                  </span>
                  <span className="rounded-full bg-purple-royal/40 px-3 py-1 text-xs font-semibold text-purple-electric">
                    MT5 & EA
                  </span>
                </div>
                <h3 className="mt-5 font-display text-xl font-bold text-ivory">
                  {isId
                    ? '4. Strategi Kami (Quant Lab & Audit EA)'
                    : '4. Our Strategy (Quant Lab & EA Testing)'}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-ivory/75">
                  {isId
                    ? 'Dokumentasi sistem berbasis aturan, arsitektur pengendalian risiko otomatis, serta EA Testing Toolkit untuk menguji kualitas backtest MT5.'
                    : 'Rule-based strategy documentation, automated risk control architecture, and the EA Testing Toolkit for auditing MT5 backtests.'}
                </p>
              </div>
              <div className="mt-6 flex flex-wrap gap-2 border-t border-white/10 pt-4">
                <Link
                  href={l('/quant-lab')}
                  className="text-xs font-semibold text-gold-champagne hover:text-gold-metallic"
                >
                  Quant Lab →
                </Link>
                <span className="text-white/20">•</span>
                <Link
                  href={l('/ea-testing')}
                  className="text-xs font-semibold text-ivory/80 hover:text-gold-champagne"
                >
                  EA Testing Toolkit →
                </Link>
              </div>
            </div>

            {/* Pillar 5: Performance Transparency */}
            <div className="flex flex-col justify-between rounded-2xl border border-white/10 bg-plum-surface/75 p-6">
              <div>
                <div className="flex items-center justify-between">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-purple-royal/35 text-gold-metallic">
                    <ShieldCheck className="h-5 w-5" />
                  </span>
                  <span className="rounded-full border border-amber-400/40 bg-amber-500/10 px-3 py-1 text-xs font-semibold text-amber-300">
                    {isId ? 'Pra-Peluncuran' : 'Pre-Launch State'}
                  </span>
                </div>
                <h3 className="mt-5 font-display text-xl font-bold text-ivory">
                  {isId
                    ? '5. Transparansi Performa & Copy Trading'
                    : '5. Performance Transparency & Copy Info'}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-ivory/75">
                  {isId
                    ? 'Arsitektur 11 metrik audit terverifikasi tanpa angka palsu, ditambah penjelasan transparan mekanisme High-Water Mark (HWM) 30%.'
                    : '11-metric verified audit schema with zero fabricated data, plus transparent explanations of the proposed 30% High-Water Mark (HWM) model.'}
                </p>
              </div>
              <div className="mt-6 flex flex-wrap gap-2 border-t border-white/10 pt-4">
                <Link
                  href={l('/performance')}
                  className="text-xs font-semibold text-gold-champagne hover:text-gold-metallic"
                >
                  {isId ? 'Skema 11 Metrik' : '11-Metric Schema'} →
                </Link>
                <span className="text-white/20">•</span>
                <Link
                  href={l('/copy-trading')}
                  className="text-xs font-semibold text-ivory/80 hover:text-gold-champagne"
                >
                  {isId ? 'Info Copy Trading' : 'Copy Trading Info'} →
                </Link>
              </div>
            </div>

            {/* Pillar 6: About JGS & Free Charter */}
            <div className="flex flex-col justify-between rounded-2xl border border-white/10 bg-plum-surface/75 p-6">
              <div>
                <div className="flex items-center justify-between">
                  <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-purple-royal/35 text-gold-metallic">
                    <FileCheck2 className="h-5 w-5" />
                  </span>
                  <span className="rounded-full bg-white/10 px-3 py-1 text-xs font-semibold text-ivory/85">
                    {isId ? 'Piagam JGS' : 'JGS Charter'}
                  </span>
                </div>
                <h3 className="mt-5 font-display text-xl font-bold text-ivory">
                  {isId
                    ? '6. Tentang JGS & Model Bisnis Jujur'
                    : '6. About JGS & Honest Business Model'}
                </h3>
                <p className="mt-2.5 text-sm leading-relaxed text-ivory/75">
                  {isId
                    ? 'Pelajari misi kami membangun literasi manajemen risiko untuk trader modal mikro tanpa menjual kelas berbayar atau sinyal VIP.'
                    : 'Read our mission to build risk-management literacy for micro-capital traders without selling paid courses or VIP signal groups.'}
                </p>
              </div>
              <div className="mt-6 flex flex-wrap gap-2 border-t border-white/10 pt-4">
                <Link
                  href={l('/about')}
                  className="text-xs font-semibold text-gold-champagne hover:text-gold-metallic"
                >
                  {isId ? 'Tentang JGS →' : 'About JGS →'}
                </Link>
                <span className="text-white/20">•</span>
                <Link
                  href={l('/community')}
                  className="text-xs font-semibold text-ivory/80 hover:text-gold-champagne"
                >
                  {isId ? 'Standar Komunitas →' : 'Community Standards →'}
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================================
          SECTION 5: HONEST PRE-LAUNCH COPY TRADING & PERFORMANCE NOTICE
         ===================================================================== */}
      <section className="py-16 lg:py-20">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="rounded-2xl border border-gold-metallic/30 bg-gradient-to-r from-[#160D26] via-[#110A1E] to-[#0B0714] p-7 sm:p-10">
            <div className="grid grid-cols-1 gap-8 lg:grid-cols-12 lg:items-center">
              <div className="lg:col-span-8">
                <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-500/10 px-3.5 py-1 text-xs font-semibold text-amber-300">
                  <AlertTriangle className="h-3.5 w-3.5" />
                  {isId
                    ? 'Pemberitahuan Transparansi & Status Pra-Peluncuran'
                    : 'Transparency & Pre-Launch Status Notice'}
                </div>
                <h2 className="mt-4 font-display text-2xl font-bold text-ivory sm:text-3xl">
                  {isId
                    ? 'Mengapa Edukasi & Tools JGS Gratis? Bagaimana JGS Berencana Menghasilkan Pendapatan?'
                    : 'Why Are JGS Education & Tools Free? How Does JGS Plan to Monetize?'}
                </h2>
                <p className="mt-3 text-base leading-relaxed text-ivory/80">
                  {isId
                    ? 'Seluruh modul belajar, kamus, riset market, dan kalkulator risiko di JGS gratis tanpa syarat. Rencana monetisasi jangka panjang kami adalah layanan copy trading opsional berbasis bagi hasil (usulan biaya kinerja 30% hanya dari profit bersih baru melalui mekanisme High-Water Mark, tunduk pada tinjauan hukum dan aturan platform broker). Saat ini layanan copy trading BELUM diluncurkan untuk publik dan kami tidak menerima deposit apa pun.'
                    : 'All learning modules, dictionary terms, market research, and risk calculators on JGS are unconditionally free. Our planned long-term monetization is an optional performance-based copy trading service (proposed 30% performance fee on eligible net new profits only under a High-Water Mark mechanism, subject to legal review and broker platform rules). Copy trading is currently NOT launched to the public, and we do not accept deposits.'}
                </p>
              </div>
              <div className="lg:col-span-4 flex flex-col gap-3 sm:flex-row lg:flex-col">
                <Link
                  href={l('/copy-trading')}
                  className="inline-flex items-center justify-center gap-2 rounded-xl bg-gold-metallic px-6 py-3.5 text-sm font-semibold text-plum-deep transition-colors hover:bg-gold-champagne"
                >
                  <span>
                    {isId
                      ? 'Pelajari Mekanisme Copy Trading & HWM'
                      : 'Read Copy Trading & HWM Guide'}
                  </span>
                  <ArrowRight className="h-4 w-4" />
                </Link>
                <Link
                  href={l('/performance')}
                  className="inline-flex items-center justify-center gap-2 rounded-xl border border-white/20 bg-white/[0.04] px-6 py-3.5 text-sm font-semibold text-ivory transition-colors hover:border-gold-metallic/40"
                >
                  <span>
                    {isId
                      ? 'Tinjau Arsitektur 11 Metrik Performa'
                      : 'Inspect 11-Metric Performance Schema'}
                  </span>
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
