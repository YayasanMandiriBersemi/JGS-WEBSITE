'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import {
  ACADEMY_TRACKS,
  ACADEMY_LESSONS,
  getLocalizedTrack,
  getLocalizedLesson,
} from '@/lib/data/academy-lessons';
import {
  loadCompletedLessonSlugs,
  toggleCompletedLessonSlug,
} from '@/lib/storage/jgs-local-store';
import { useLocale } from '@/i18n/LocaleContext';
import {
  Clock,
  CheckCircle2,
  Circle,
  ArrowRight,
  GraduationCap,
  Sparkles,
  Search,
  Layers,
  RotateCcw,
  BookOpen,
} from 'lucide-react';

type LearningPathTier = 'ALL' | 'BEGINNER' | 'INTERMEDIATE' | 'QUANT';

export function AcademyHub() {
  const { locale, isId, l } = useLocale();
  const [isLoaded, setIsLoaded] = useState(false);
  const [completedSlugs, setCompletedSlugs] = useState<string[]>([]);
  const [selectedPath, setSelectedPath] = useState<LearningPathTier>('ALL');
  const [selectedTrackId, setSelectedTrackId] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');

  useEffect(() => {
    setCompletedSlugs(loadCompletedLessonSlugs());
    setIsLoaded(true);
  }, []);

  const learningPaths: {
    id: LearningPathTier;
    title: string;
    badge: string;
    description: string;
  }[] = useMemo(
    () => [
      {
        id: 'ALL',
        title: isId ? 'Kurikulum Lengkap JGS' : 'Complete Master Curriculum',
        badge: isId ? 'SEMUA 12 MODUL' : 'ALL 12 MODULES',
        description: isId
          ? 'Tampilkan seluruh 4 jalur belajar mulai dari Fondasi Modal Mikro hingga Literasi Algoritmik MT5.'
          : 'View all 4 tracks from Micro-Capital Foundations to Algorithmic Quant Literacy.',
      },
      {
        id: 'BEGINNER',
        title: isId ? 'Jalur 01: Fondasi Pemula' : 'Path 01: Beginner Foundation',
        badge: isId ? 'MULAI DI SINI' : 'START HERE',
        description: isId
          ? 'Pelajari akun Cent (USC), spesifikasi kontrak broker, pip, point, spread, rasio R:R, pemulihan drawdown, dan jenis order MT5.'
          : 'Master Cent accounts (USC), broker contract specs, pips, points, spread, R:R math, drawdown recovery, and MT5 order types.',
      },
      {
        id: 'INTERMEDIATE',
        title: isId ? 'Jalur 02: Struktur & Manajemen Risiko' : 'Path 02: Intermediate Technician',
        badge: 'XAUUSD & RISK',
        description: isId
          ? 'Kuasai karakter volatilitas Emas (XAUUSD), sapuan likuiditas vs breakout terkonfirmasi, dan batas kerugian harian.'
          : 'Master Gold (XAUUSD) volatility, liquidity sweeps vs. confirmed breakouts, and daily loss circuit breakers.',
      },
      {
        id: 'QUANT',
        title: isId ? 'Jalur 03: Sistem & Audit Kuantitatif' : 'Path 03: Advanced & Quant Strategist',
        badge: 'MT5 EA & AUDIT',
        description: isId
          ? 'Pahami alur kerja Expert Advisor (EA) di MT5, bahaya sistem Martingale tanpa batas, dan cara mengaudit metrik performa.'
          : 'Understand MT5 Expert Advisor execution pipelines, uncapped Martingale risks, and how to audit performance metrics.',
      },
    ],
    [isId]
  );

  const localizedTracks = useMemo(
    () => ACADEMY_TRACKS.map((t) => getLocalizedTrack(t, locale)),
    [locale]
  );

  const localizedLessons = useMemo(
    () => ACADEMY_LESSONS.map((les) => getLocalizedLesson(les, locale)),
    [locale]
  );

  function handleToggleComplete(slug: string, e: React.MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    const updated = toggleCompletedLessonSlug(slug);
    setCompletedSlugs(updated);
  }

  function handleResetFilters() {
    setSearchQuery('');
    setSelectedPath('ALL');
    setSelectedTrackId('ALL');
  }

  const filteredLessons = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return localizedLessons.filter((lesson) => {
      if (selectedPath !== 'ALL' && lesson.difficulty !== selectedPath) return false;
      if (selectedTrackId !== 'ALL' && lesson.trackId !== selectedTrackId) return false;
      if (!q) return true;

      const inTitle = lesson.title.toLowerCase().includes(q);
      const inSummary = lesson.summary.toLowerCase().includes(q);
      const inRule = lesson.jeyStreetRule.toLowerCase().includes(q);
      const inPlain = lesson.plainEnglishSections.some(
        (s) => s.heading.toLowerCase().includes(q) || s.body.toLowerCase().includes(q)
      );
      const inTech = lesson.technicalSections.some(
        (s) =>
          s.heading.toLowerCase().includes(q) ||
          s.body.toLowerCase().includes(q) ||
          (s.formulaOrSpec && s.formulaOrSpec.toLowerCase().includes(q))
      );
      const inTerms = lesson.relatedTerms.some((t) => t.toLowerCase().includes(q));

      return inTitle || inSummary || inRule || inPlain || inTech || inTerms;
    });
  }, [localizedLessons, searchQuery, selectedPath, selectedTrackId]);

  const totalLessons = localizedLessons.length;
  const completedCount = completedSlugs.length;
  const progressPct = Math.round((completedCount / totalLessons) * 100);

  function getPathStats(tier: 'BEGINNER' | 'INTERMEDIATE' | 'QUANT') {
    const pathLessons = localizedLessons.filter((les) => les.difficulty === tier);
    const done = pathLessons.filter((les) => completedSlugs.includes(les.slug)).length;
    return {
      done,
      total: pathLessons.length,
      pct: pathLessons.length > 0 ? Math.round((done / pathLessons.length) * 100) : 0,
    };
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-10">
      {/* Header & Overall Progress Panel */}
      <div className="jgs-panel p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#D4AF37]">
            <GraduationCap className="w-4 h-4" />
            <span>
              {isId
                ? 'JGS ACADEMY • PUSAT EDUKASI TRADING 100% GRATIS'
                : 'JGS ACADEMY • 100% FREE TRADING EDUCATION HUB'}
            </span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#F7F4EE]">
            {isId
              ? 'Kurikulum Terstruktur untuk Pemula hingga Pembangun Sistem'
              : 'Structured Learning Paths for Every Experience Level'}
          </h1>
          <p className="text-sm sm:text-base text-[#BEB6CE] leading-relaxed">
            {isId
              ? 'Pilih jalur belajar sesuai tingkat pemahaman Anda, cari topik spesifik, dan beralih antara penjelasan Bahasa Sederhana maupun Mode Teknis di setiap modul—100% gratis tanpa paywall.'
              : 'Choose your learning path, search across all lesson materials, and switch between Plain-Language and Technical Mode inside every module—100% free with zero paywalls.'}
          </p>
        </div>

        <div className="bg-[#08050E] border border-[#D4AF37]/30 rounded-xl p-5 min-w-[280px] space-y-3">
          <div className="flex items-center justify-between text-xs font-medium">
            <span className="text-[#BEB6CE]">
              {isId ? 'Progres Belajar Anda' : 'Overall Mastery'}
            </span>
            <span className="text-[#D4AF37] font-bold">
              {isLoaded
                ? `${completedCount}/${totalLessons} (${progressPct}%)`
                : isId
                ? 'Memuat...'
                : 'Loading...'}
            </span>
          </div>
          <div className="w-full h-2.5 rounded-full bg-[#191129] overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-[#D4AF37] to-[#10B981] transition-all duration-300"
              style={{ width: `${isLoaded ? progressPct : 0}%` }}
            />
          </div>
          <div className="grid grid-cols-3 gap-2 pt-1 text-xs text-[#BEB6CE]">
            <div>
              {isId ? 'Pemula' : 'Beg'}: {getPathStats('BEGINNER').pct}%
            </div>
            <div>
              {isId ? 'Menengah' : 'Int'}: {getPathStats('INTERMEDIATE').pct}%
            </div>
            <div>
              {isId ? 'Sistem' : 'Quant'}: {getPathStats('QUANT').pct}%
            </div>
          </div>
        </div>
      </div>

      {/* Learning Path Selector Cards */}
      <section className="space-y-3">
        <div className="flex items-center justify-between text-xs font-semibold text-[#D4AF37]">
          <span className="inline-flex items-center gap-1.5">
            <Layers className="w-3.5 h-3.5" />
            {isId ? '1. Pilih Jalur Kurikulum Anda' : '1. Select Your Learning Path Tier'}
          </span>
          <span className="text-[#BEB6CE] font-normal">
            {isId ? 'Progres tersimpan otomatis di perangkat Anda' : 'Progress saved automatically'}
          </span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {learningPaths.map((path) => {
            const isSelected = selectedPath === path.id;
            const stats =
              path.id === 'ALL'
                ? { done: completedCount, total: totalLessons, pct: progressPct }
                : getPathStats(path.id);

            return (
              <button
                key={path.id}
                type="button"
                onClick={() => setSelectedPath(path.id)}
                className={`text-left p-5 rounded-xl border transition-all flex flex-col justify-between space-y-4 ${
                  isSelected
                    ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F7F4EE] shadow-gold-subtle'
                    : 'bg-[#120B1E] border-white/10 text-[#BEB6CE] hover:border-[#D4AF37]/40'
                }`}
              >
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="px-2.5 py-0.5 rounded bg-[#08050E] text-[#D4AF37] font-semibold">
                      {path.badge}
                    </span>
                    <span className="text-[#10B981] font-medium">
                      {stats.done}/{stats.total} {isId ? 'Selesai' : 'Done'}
                    </span>
                  </div>
                  <h2 className="font-display font-bold text-base text-[#F7F4EE] pt-1">
                    {path.title}
                  </h2>
                  <p className="text-xs text-[#BEB6CE] leading-relaxed">{path.description}</p>
                </div>

                <div className="w-full h-1.5 rounded-full bg-[#08050E] overflow-hidden">
                  <div
                    className="h-full bg-[#D4AF37] transition-all duration-300"
                    style={{ width: `${stats.pct}%` }}
                  />
                </div>
              </button>
            );
          })}
        </div>
      </section>

      {/* Search Bar & Track Filter Controls */}
      <div className="jgs-panel p-5 space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 items-center">
          <div className="lg:col-span-6 relative">
            <Search className="w-4 h-4 text-[#D4AF37] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                isId
                  ? 'Cari materi, rumus, atau topik (misal: Cent, XAUUSD, Drawdown, Martingale, MT5)...'
                  : 'Search lessons, formulas, topics (e.g. Cent Lot, XAUUSD, Drawdown, Martingale, MT5)...'
              }
              className="jgs-input pl-10 font-sans"
              aria-label={
                isId ? 'Cari materi belajar Academy' : 'Search Academy learning materials'
              }
            />
          </div>

          <div className="lg:col-span-6 flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={() => setSelectedTrackId('ALL')}
              className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-all ${
                selectedTrackId === 'ALL'
                  ? 'bg-[#D4AF37] text-[#08050E] font-bold'
                  : 'bg-[#08050E] border border-white/10 text-[#BEB6CE] hover:text-[#F7F4EE]'
              }`}
            >
              {isId ? 'Semua Topik' : 'All Tracks'}
            </button>
            {localizedTracks.map((track) => (
              <button
                key={track.id}
                type="button"
                onClick={() => setSelectedTrackId(track.id)}
                className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-all ${
                  selectedTrackId === track.id
                    ? 'bg-[#D4AF37] text-[#08050E] font-bold'
                    : 'bg-[#08050E] border border-white/10 text-[#BEB6CE] hover:text-[#F7F4EE]'
                }`}
              >
                {isId ? `Bab ${track.trackNumber}` : `Track ${track.trackNumber}`}
              </button>
            ))}
            {(searchQuery || selectedPath !== 'ALL' || selectedTrackId !== 'ALL') && (
              <button
                type="button"
                onClick={handleResetFilters}
                className="px-3 py-2 rounded-lg text-xs bg-white/5 text-[#F3E5AB] hover:bg-white/10 inline-flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                {isId ? 'Reset' : 'Reset'}
              </button>
            )}
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-[#BEB6CE] pt-1 border-t border-white/5">
          <span>
            {isId
              ? `Menampilkan ${filteredLessons.length} dari ${totalLessons} modul`
              : `Showing ${filteredLessons.length} of ${totalLessons} modules`}
          </span>
          <Link
            href={l('/onboarding')}
            className="text-[#D4AF37] hover:underline inline-flex items-center gap-1 font-medium"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>
              {isId
                ? 'Bingung mulai dari mana? Buka Panduan Jey'
                : 'Not sure where to start? Launch Jey Onboarding'}
            </span>
          </Link>
        </div>
      </div>

      {/* Empty State when no lessons match */}
      {filteredLessons.length === 0 ? (
        <div className="jgs-panel p-12 text-center space-y-4">
          <BookOpen className="w-10 h-10 text-[#D4AF37] mx-auto opacity-80" />
          <h3 className="font-display text-xl font-bold text-[#F7F4EE]">
            {isId
              ? 'Tidak Ada Modul yang Cocok dengan Pencarian Anda'
              : 'No Learning Modules Match Your Filter'}
          </h3>
          <p className="text-sm text-[#BEB6CE] max-w-md mx-auto">
            {isId
              ? `Kami tidak menemukan modul untuk kata kunci "${searchQuery}". Coba reset filter atau cari di Kamus Trading Jey.`
              : `We could not find any lessons matching "${searchQuery}". Try resetting your filters or searching Jey's Dictionary.`}
          </p>
          <div className="flex justify-center gap-3 pt-2">
            <button
              type="button"
              onClick={handleResetFilters}
              className="px-5 py-2.5 rounded-lg bg-[#D4AF37] text-[#08050E] font-semibold text-xs"
            >
              {isId ? 'Reset Filter Pencarian' : 'Reset Search Filters'}
            </button>
            <Link
              href={l('/dictionary')}
              className="px-5 py-2.5 rounded-lg border border-white/15 text-[#F7F4EE] hover:border-[#D4AF37] text-xs font-medium"
            >
              {isId ? 'Buka Kamus Trading' : "Search Jey's Dictionary"}
            </Link>
          </div>
        </div>
      ) : (
        /* Tracks & Lessons List */
        <div className="space-y-12">
          {localizedTracks.map((track) => {
            const trackLessons = filteredLessons.filter((les) => les.trackId === track.id);
            if (trackLessons.length === 0) return null;

            const trackDoneCount = trackLessons.filter((les) =>
              completedSlugs.includes(les.slug)
            ).length;

            return (
              <section key={track.id} className="space-y-5">
                <div className="flex flex-col md:flex-row md:items-end justify-between border-b border-white/10 pb-4 gap-3">
                  <div>
                    <div className="flex items-center gap-2.5">
                      <span className="px-2.5 py-0.5 rounded bg-[#D4AF37]/15 border border-[#D4AF37]/40 text-xs font-semibold text-[#D4AF37]">
                        {isId ? `BAB ${track.trackNumber}` : `TRACK ${track.trackNumber}`}
                      </span>
                      <span className="text-xs text-[#BEB6CE]">
                        {track.targetAudience} • ~{track.estimatedMinutes}{' '}
                        {isId ? 'menit' : 'min'}
                      </span>
                    </div>
                    <h2 className="font-display text-2xl font-bold text-[#F7F4EE] mt-2">
                      {track.title}
                    </h2>
                    <p className="text-sm text-[#BEB6CE] mt-1">{track.subtitle}</p>
                  </div>

                  <div className="text-xs font-medium text-[#10B981]">
                    {trackDoneCount}/{trackLessons.length}{' '}
                    {isId ? 'Modul Selesai' : 'Modules Completed'}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                  {trackLessons.map((lesson) => {
                    const isDone = completedSlugs.includes(lesson.slug);
                    const difficultyLabel =
                      lesson.difficulty === 'BEGINNER'
                        ? isId
                          ? 'PEMULA'
                          : 'BEGINNER'
                        : lesson.difficulty === 'INTERMEDIATE'
                        ? isId
                          ? 'MENENGAH'
                          : 'INTERMEDIATE'
                        : isId
                        ? 'SISTEM / QUANT'
                        : 'QUANT';

                    return (
                      <Link
                        key={lesson.slug}
                        href={l(`/academy/${lesson.slug}`)}
                        className={`group jgs-panel p-6 flex flex-col justify-between transition-all hover:-translate-y-0.5 hover:border-[#D4AF37]/50 ${
                          isDone ? 'border-[#10B981]/35' : ''
                        }`}
                      >
                        <div className="space-y-3">
                          <div className="flex items-center justify-between">
                            <span className="text-xs font-semibold text-[#D4AF37]">
                              {isId ? `MODUL ${lesson.lessonNumber}` : `LESSON ${lesson.lessonNumber}`}{' '}
                              • {difficultyLabel}
                            </span>
                            <button
                              type="button"
                              onClick={(e) => handleToggleComplete(lesson.slug, e)}
                              title={
                                isDone
                                  ? isId
                                    ? 'Tandai belum selesai'
                                    : 'Mark as incomplete'
                                  : isId
                                  ? 'Tandai selesai'
                                  : 'Mark as completed'
                              }
                              aria-label={
                                isDone
                                  ? `Mark ${lesson.title} as incomplete`
                                  : `Mark ${lesson.title} as completed`
                              }
                              className="text-[#BEB6CE] hover:text-[#10B981] transition-colors"
                            >
                              {isDone ? (
                                <CheckCircle2 className="w-5 h-5 text-[#10B981]" />
                              ) : (
                                <Circle className="w-5 h-5" />
                              )}
                            </button>
                          </div>

                          <h3 className="font-display text-lg font-bold text-[#F7F4EE] group-hover:text-[#F3E5AB] transition-colors">
                            {lesson.title}
                          </h3>

                          <p className="text-sm text-[#BEB6CE] leading-relaxed">
                            {lesson.summary}
                          </p>
                        </div>

                        <div className="pt-5 mt-5 border-t border-white/10 flex items-center justify-between text-xs font-medium">
                          <span className="inline-flex items-center gap-1 text-[#BEB6CE]">
                            <Clock className="w-3.5 h-3.5 text-[#D4AF37]" />
                            {lesson.durationMinutes} {isId ? 'menit baca' : 'min read'}
                          </span>
                          <span className="inline-flex items-center gap-1 text-[#D4AF37] group-hover:translate-x-1 transition-transform font-semibold">
                            <span>
                              {isDone
                                ? isId
                                  ? 'Ulas Kembali'
                                  : 'Review Lesson'
                                : isId
                                ? 'Mulai Modul'
                                : 'Start Lesson'}
                            </span>
                            <ArrowRight className="w-3.5 h-3.5" />
                          </span>
                        </div>
                      </Link>
                    );
                  })}
                </div>
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
}
