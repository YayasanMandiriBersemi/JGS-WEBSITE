'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import {
  AcademyLesson,
  ACADEMY_LESSONS,
  getLocalizedLesson,
} from '@/lib/data/academy-lessons';
import { DICTIONARY_TERMS } from '@/lib/data/dictionary-terms';
import {
  loadCompletedLessonSlugs,
  markLessonCompleted,
} from '@/lib/storage/jgs-local-store';
import { JeyStrategistCallout } from '@/components/brand/JeyStrategistCallout';
import { useLocale } from '@/i18n/LocaleContext';
import {
  ArrowLeft,
  ArrowRight,
  CheckCircle2,
  BookOpen,
  Cpu,
  HelpCircle,
  ExternalLink,
} from 'lucide-react';

interface LessonInteractiveViewProps {
  lesson: AcademyLesson;
}

export function LessonInteractiveView({ lesson: rawLesson }: LessonInteractiveViewProps) {
  const { locale, isId, l } = useLocale();
  const lesson = useMemo(() => getLocalizedLesson(rawLesson, locale), [rawLesson, locale]);

  const [mode, setMode] = useState<'PLAIN_ENGLISH' | 'TECHNICAL'>('PLAIN_ENGLISH');
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [isCompleted, setIsCompleted] = useState(false);

  useEffect(() => {
    const slugs = loadCompletedLessonSlugs();
    setIsCompleted(slugs.includes(lesson.slug));
    setSelectedOption(null);
    setQuizSubmitted(false);
  }, [lesson.slug]);

  const currentIndex = ACADEMY_LESSONS.findIndex((les) => les.slug === lesson.slug);
  const prevLesson =
    currentIndex > 0 ? getLocalizedLesson(ACADEMY_LESSONS[currentIndex - 1], locale) : null;
  const nextLesson =
    currentIndex < ACADEMY_LESSONS.length - 1
      ? getLocalizedLesson(ACADEMY_LESSONS[currentIndex + 1], locale)
      : null;

  function handleCheckAnswer() {
    if (selectedOption === null) return;
    setQuizSubmitted(true);
    if (selectedOption === lesson.quiz.correctIndex) {
      markLessonCompleted(lesson.slug);
      setIsCompleted(true);
    }
  }

  const linkedTerms = DICTIONARY_TERMS.filter((t) => lesson.relatedTerms.includes(t.slug));

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Top Breadcrumb & Status */}
      <div className="flex flex-wrap items-center justify-between gap-4">
        <Link
          href={l('/academy')}
          className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#B8B0C8] hover:text-[#D4AF37]"
        >
          <ArrowLeft className="w-3.5 h-3.5" />
          <span>{isId ? 'Kembali ke Kurikulum Academy' : 'Back to Academy Curriculum'}</span>
        </Link>

        <div className="flex items-center gap-2">
          {isCompleted && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded bg-[#10B981]/15 border border-[#10B981]/40 text-xs font-semibold text-[#10B981]">
              <CheckCircle2 className="w-3.5 h-3.5" />
              {isId ? 'SELESAI' : 'COMPLETED'}
            </span>
          )}
          <span className="text-xs font-semibold px-2.5 py-1 rounded bg-[#191129] border border-[#D4AF37]/30 text-[#D4AF37]">
            {isId ? `MODUL ${lesson.lessonNumber}` : `LESSON ${lesson.lessonNumber}`} •{' '}
            {lesson.durationMinutes} {isId ? 'MENIT' : 'MIN'}
          </span>
        </div>
      </div>

      {/* Title & Mode Toggle Switch */}
      <div className="jgs-panel p-6 sm:p-8 space-y-6">
        <div>
          <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#F7F4EE]">
            {lesson.title}
          </h1>
          <p className="text-sm sm:text-base text-[#B8B0C8] mt-2 leading-relaxed">
            {lesson.summary}
          </p>
        </div>

        {/* Plain-Language vs Technical Toggle */}
        <div className="bg-[#09060F] p-3.5 rounded-xl border border-white/10 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="text-xs text-[#B8B0C8]">
            <span className="font-semibold text-[#F7F4EE]">
              {isId ? 'Mode Penjelasan: ' : 'Explanation Mode: '}
            </span>
            {isId
              ? 'Pilih antara penjelasan bahasa sederhana untuk pemula atau spesifikasi teknis.'
              : 'Switch anytime between beginner-friendly language and technical specifications.'}
          </div>
          <div className="inline-flex rounded-lg bg-[#191129] p-1 border border-white/10 shrink-0">
            <button
              type="button"
              onClick={() => setMode('PLAIN_ENGLISH')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                mode === 'PLAIN_ENGLISH'
                  ? 'bg-[#D4AF37] text-[#09060F]'
                  : 'text-[#B8B0C8] hover:text-[#F7F4EE]'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>{isId ? 'Bahasa Sederhana' : 'Plain-Language Mode'}</span>
            </button>
            <button
              type="button"
              onClick={() => setMode('TECHNICAL')}
              className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-semibold transition-all ${
                mode === 'TECHNICAL'
                  ? 'bg-[#A882DD] text-[#09060F]'
                  : 'text-[#B8B0C8] hover:text-[#F7F4EE]'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              <span>{isId ? 'Mode Teknis & Rumus' : 'Technical & Quant Mode'}</span>
            </button>
          </div>
        </div>

        {/* Lesson Body Sections */}
        {mode === 'PLAIN_ENGLISH' ? (
          <div className="space-y-6">
            {lesson.plainEnglishSections.map((sec, idx) => (
              <div
                key={idx}
                className="bg-[#09060F]/70 border border-white/10 rounded-xl p-5 space-y-2"
              >
                <h2 className="font-display text-lg font-bold text-[#F3E5AB]">{sec.heading}</h2>
                <p className="text-sm sm:text-base text-[#F7F4EE]/90 leading-relaxed">
                  {sec.body}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="space-y-6">
            {lesson.technicalSections.map((sec, idx) => (
              <div
                key={idx}
                className="bg-[#09060F]/70 border border-[#A882DD]/30 rounded-xl p-5 space-y-3"
              >
                <h2 className="font-display text-lg font-bold text-[#A882DD]">{sec.heading}</h2>
                <p className="text-sm sm:text-base text-[#F7F4EE]/90 leading-relaxed">
                  {sec.body}
                </p>
                {sec.formulaOrSpec && (
                  <div className="p-3 rounded-lg bg-[#110B1C] border border-[#D4AF37]/30 font-mono text-xs text-[#F3E5AB]">
                    {sec.formulaOrSpec}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}

        {/* Micro-Capital Case Study Box */}
        <div className="rounded-xl border border-[#D4AF37]/30 bg-[#191129]/60 p-5 space-y-4">
          <div className="text-xs font-semibold text-[#D4AF37]">
            {isId ? 'STUDI KASUS MODAL MIKRO • ' : 'WORKED MICRO-CAPITAL CASE STUDY • '}
            {lesson.microCapitalCaseStudy.title}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg bg-[#1A0D16] border border-[#EF4444]/35">
              <div className="text-xs text-[#EF4444] font-semibold mb-1">
                {isId ? 'Kesalahan Umum Tanpa Perhitungan' : 'Unchecked Risk Trap'}
              </div>
              <p className="text-xs sm:text-sm text-[#F7F4EE] leading-relaxed">
                {lesson.microCapitalCaseStudy.standardAccountOutcome}
              </p>
            </div>
            <div className="p-4 rounded-lg bg-[#0F1B1D] border border-[#10B981]/35">
              <div className="text-xs text-[#10B981] font-semibold mb-1">
                {isId ? 'Pendekatan Disiplin JGS' : 'Disciplined JGS Execution'}
              </div>
              <p className="text-xs sm:text-sm text-[#F7F4EE] leading-relaxed">
                {lesson.microCapitalCaseStudy.centAccountOutcome}
              </p>
            </div>
          </div>
        </div>

        {/* Jey's Street Rule */}
        <JeyStrategistCallout
          ruleText={lesson.jeyStreetRule}
          contextTag={
            isId ? `PRINSIP MODUL ${lesson.lessonNumber}` : `LESSON ${lesson.lessonNumber} PRINCIPLE`
          }
        />
      </div>

      {/* Linked Dictionary Glossary Pills */}
      {linkedTerms.length > 0 && (
        <div className="jgs-panel p-5 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-[#B8B0C8]">
              {isId ? 'ISTILAH PENTING DALAM MODUL INI' : 'KEY TRADING TERMS IN THIS LESSON'}
            </span>
            <Link
              href={l('/dictionary')}
              className="text-xs font-semibold text-[#D4AF37] hover:underline inline-flex items-center gap-1"
            >
              <span>{isId ? 'Buka Kamus Lengkap' : 'Open Full Dictionary'}</span>
              <ExternalLink className="w-3 h-3" />
            </Link>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {linkedTerms.map((term) => (
              <div
                key={term.slug}
                className="p-3.5 rounded-lg bg-[#09060F] border border-white/10 space-y-1"
              >
                <div className="text-xs font-bold text-[#D4AF37]">{term.term}</div>
                <p className="text-xs text-[#B8B0C8] leading-relaxed">{term.plainEnglish}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Interactive Comprehension Quiz */}
      <div className="jgs-panel p-6 sm:p-8 border-[#D4AF37]/40 space-y-5">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#D4AF37]">
          <HelpCircle className="w-4 h-4" />
          <span>
            {isId
              ? 'UJI PEMAHAMAN — PASTIKAN KONSEP SUDAH JELAS'
              : 'COMPREHENSION CHECKPOINT — VERIFY YOUR UNDERSTANDING'}
          </span>
        </div>
        <h3 className="font-display text-lg font-bold text-[#F7F4EE]">{lesson.quiz.question}</h3>

        <div className="space-y-2.5">
          {lesson.quiz.options.map((opt, idx) => {
            const isSelected = selectedOption === idx;
            const isCorrect = idx === lesson.quiz.correctIndex;
            let cardStyle = 'bg-[#09060F] border-white/10 text-[#B8B0C8] hover:border-white/30';

            if (quizSubmitted) {
              if (isCorrect) {
                cardStyle = 'bg-[#0F1B1D] border-[#10B981] text-[#F7F4EE]';
              } else if (isSelected && !isCorrect) {
                cardStyle = 'bg-[#1A0D16] border-[#EF4444] text-[#F7F4EE]';
              }
            } else if (isSelected) {
              cardStyle = 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F7F4EE]';
            }

            return (
              <button
                key={idx}
                type="button"
                onClick={() => {
                  setSelectedOption(idx);
                  setQuizSubmitted(false);
                }}
                className={`w-full text-left p-4 rounded-xl border text-sm transition-all flex items-center justify-between gap-3 ${cardStyle}`}
              >
                <span>{opt}</span>
                {quizSubmitted && isCorrect && (
                  <CheckCircle2 className="w-4 h-4 text-[#10B981] shrink-0" />
                )}
              </button>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center justify-between gap-4 pt-2">
          <button
            type="button"
            disabled={selectedOption === null}
            onClick={handleCheckAnswer}
            className="px-5 py-2.5 rounded-lg bg-[#D4AF37] hover:bg-[#F3E5AB] disabled:opacity-40 text-[#09060F] font-semibold text-sm transition-all"
          >
            {isId
              ? 'Periksa Jawaban & Tandai Selesai'
              : 'Verify Answer & Mark Lesson Complete'}
          </button>

          {quizSubmitted && (
            <div
              className={`text-xs font-semibold ${
                selectedOption === lesson.quiz.correctIndex ? 'text-[#10B981]' : 'text-[#EF4444]'
              }`}
            >
              {selectedOption === lesson.quiz.correctIndex
                ? isId
                  ? 'Jawaban Tepat! Modul ditandai selesai.'
                  : 'Correct! Lesson marked as completed.'
                : isId
                ? 'Belum tepat. Baca penjelasan di bawah dan coba lagi.'
                : 'Not quite. Read the explanation below and try again.'}
            </div>
          )}
        </div>

        {quizSubmitted && (
          <div className="p-4 rounded-lg bg-[#09060F] border border-white/10 text-xs sm:text-sm text-[#B8B0C8] leading-relaxed">
            <span className="font-semibold text-[#F3E5AB]">
              {isId ? 'Penjelasan: ' : 'Explanation: '}
            </span>
            {lesson.quiz.explanation}
          </div>
        )}
      </div>

      {/* Bottom Lesson Navigation */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4 pt-4">
        {prevLesson ? (
          <Link
            href={l(`/academy/${prevLesson.slug}`)}
            className="jgs-panel p-4 flex items-center gap-3 hover:border-[#D4AF37]/40 transition-colors"
          >
            <ArrowLeft className="w-4 h-4 text-[#D4AF37] shrink-0" />
            <div>
              <div className="text-xs text-[#7D7490]">
                {isId ? 'Modul Sebelumnya' : 'Previous Lesson'}
              </div>
              <div className="text-sm font-bold text-[#F7F4EE]">{prevLesson.title}</div>
            </div>
          </Link>
        ) : (
          <div />
        )}

        {nextLesson ? (
          <Link
            href={l(`/academy/${nextLesson.slug}`)}
            className="jgs-panel p-4 flex items-center justify-end gap-3 text-right hover:border-[#D4AF37]/40 transition-colors"
          >
            <div>
              <div className="text-xs text-[#7D7490]">
                {isId ? 'Modul Berikutnya' : 'Next Lesson'}
              </div>
              <div className="text-sm font-bold text-[#F7F4EE]">{nextLesson.title}</div>
            </div>
            <ArrowRight className="w-4 h-4 text-[#D4AF37] shrink-0" />
          </Link>
        ) : (
          <Link
            href={l('/playground')}
            className="jgs-panel p-4 flex items-center justify-end gap-3 text-right border-[#D4AF37]/50 hover:bg-[#D4AF37]/10 transition-colors"
          >
            <div>
              <div className="text-xs text-[#D4AF37]">
                {isId ? 'Kurikulum Selesai' : 'Curriculum Complete'}
              </div>
              <div className="text-sm font-bold text-[#F7F4EE]">
                {isId ? 'Uji Kemampuan di Trading Playground' : 'Test Skills in Trading Playground'}
              </div>
            </div>
            <ArrowRight className="w-4 h-4 text-[#D4AF37] shrink-0" />
          </Link>
        )}
      </div>
    </div>
  );
}
