'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { calculateRiskMetrics } from '@/lib/math/risk-engine';
import { JeyStrategistCallout } from '@/components/brand/JeyStrategistCallout';
import { useLocale } from '@/i18n/LocaleContext';
import { ShieldCheck, TrendingDown, Calculator, ArrowRight } from 'lucide-react';

export function RiskManagementCalculator() {
  const { isId, l } = useLocale();
  const [accountBalance, setAccountBalance] = useState<number>(5000);
  const [accountUnit, setAccountUnit] = useState<'USC' | 'USD'>('USC');
  const [riskPercent, setRiskPercent] = useState<number>(1.0);
  const [stopLossPoints, setStopLossPoints] = useState<number>(250);
  const [rewardToRiskRatio, setRewardToRiskRatio] = useState<number>(2.0);
  const [dailyMaxLossPercent, setDailyMaxLossPercent] = useState<number>(3.0);
  const [pointValuePerMinLot, setPointValuePerMinLot] = useState<number>(0.01);

  const metrics = calculateRiskMetrics({
    accountBalance,
    accountUnit,
    riskPercent,
    stopLossPoints,
    rewardToRiskRatio,
    dailyMaxLossPercent,
    pointValuePerMinLot
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-10">
      {/* Header */}
      <div className="jgs-panel p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D4AF37]">
            <ShieldCheck className="w-4 h-4" />
            <span>
              {isId
                ? 'JGS LAB REKAYASA RISIKO & SIMULATOR DRAWDOWN'
                : 'JGS RISK & DRAWDOWN ENGINEERING LAB'}
            </span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#F7F4EE]">
            {isId
              ? 'Kalkulator Ukuran Posisi, Rasio R:R Asimetris & Kurva Pemulihan Drawdown'
              : 'Position Sizer, Asymmetric R:R & Drawdown Recovery Curve'}
          </h1>
          <p className="text-sm sm:text-base text-[#B8B0C8] leading-relaxed">
            {isId
              ? 'Hitung ukuran lot berdasarkan spesifikasi nilai poin broker Anda, tingkat win rate impas (breakeven), batas kerugian harian, serta visualisasikan matematika pemulihan drawdown.'
              : 'Calculate your exact lot size based on your broker’s point value specification, breakeven win rate, daily circuit-breaker limit, and visualize nonlinear drawdown recovery.'}
          </p>
        </div>

        <Link href={l('/calculators/cent')} className="jgs-btn-outline text-xs shrink-0">
          <Calculator className="w-4 h-4 text-[#D4AF37]" />
          <span>
            {isId ? 'Buka Kalkulator Spesifikasi Simbol & Cent Lab' : 'Open Broker Spec & Cent Lab'}
          </span>
        </Link>
      </div>

      {/* Main Sizer + Outputs */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs */}
        <div className="lg:col-span-5 jgs-panel p-6 space-y-5">
          <h2 className="font-display text-lg font-bold text-[#F7F4EE] border-b border-white/10 pb-3">
            1. Risk & Reward Parameters
          </h2>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-1">
              <label htmlFor="risk-unit" className="jgs-label">
                Account Unit
              </label>
              <select
                id="risk-unit"
                value={accountUnit}
                onChange={(e) => setAccountUnit(e.target.value as 'USC' | 'USD')}
                className="jgs-input"
              >
                <option value="USC">USC (Cent)</option>
                <option value="USD">USD ($)</option>
              </select>
            </div>
            <div className="col-span-2">
              <label htmlFor="risk-balance" className="jgs-label">
                Account Equity ({accountUnit})
              </label>
              <input
                id="risk-balance"
                type="number"
                min={10}
                step={100}
                value={accountBalance}
                onChange={(e) => setAccountBalance(Number(e.target.value))}
                className="jgs-input"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label htmlFor="risk-pct" className="jgs-label">
                Risk Per Trade (%)
              </label>
              <input
                id="risk-pct"
                type="number"
                min={0.25}
                max={10}
                step={0.25}
                value={riskPercent}
                onChange={(e) => setRiskPercent(Number(e.target.value))}
                className="jgs-input"
              />
            </div>
            <div>
              <label htmlFor="daily-cap-pct" className="jgs-label">
                Daily Loss Lock (%)
              </label>
              <input
                id="daily-cap-pct"
                type="number"
                min={1}
                max={20}
                step={0.5}
                value={dailyMaxLossPercent}
                onChange={(e) => setDailyMaxLossPercent(Number(e.target.value))}
                className="jgs-input"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label htmlFor="risk-sl" className="jgs-label">
                {isId ? 'Jarak Stop Loss (Poin MT5)' : 'Stop Loss Distance (MT5 Points)'}
              </label>
              <input
                id="risk-sl"
                type="number"
                min={10}
                max={5000}
                step={10}
                value={stopLossPoints}
                onChange={(e) => setStopLossPoints(Number(e.target.value))}
                className="jgs-input"
              />
            </div>
            <div>
              <label htmlFor="risk-pt-val" className="jgs-label">
                {isId
                  ? `Nilai Poin / 0.01 Lot (${accountUnit})`
                  : `Point Value / 0.01 Lot (${accountUnit})`}
              </label>
              <input
                id="risk-pt-val"
                type="number"
                min={0.001}
                step={0.01}
                value={pointValuePerMinLot}
                onChange={(e) => setPointValuePerMinLot(Number(e.target.value))}
                className="jgs-input"
              />
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="risk-rr" className="jgs-label mb-0">
                Target Reward-to-Risk Ratio (1 : {rewardToRiskRatio})
              </label>
              <span className="text-xs font-mono text-[#10B981]">
                TP Distance: {metrics.takeProfitPoints} pts
              </span>
            </div>
            <input
              id="risk-rr"
              type="range"
              min={1.0}
              max={5.0}
              step={0.25}
              value={rewardToRiskRatio}
              onChange={(e) => setRewardToRiskRatio(Number(e.target.value))}
              className="w-full accent-[#D4AF37] cursor-pointer"
            />
            <div className="flex justify-between text-[11px] font-mono text-[#7E7494] mt-1">
              <span>1:1 (50% BE)</span>
              <span>1:2 (33.3% BE)</span>
              <span>1:3 (25% BE)</span>
              <span>1:5 (16.7% BE)</span>
            </div>
          </div>
        </div>

        {/* Right Computed Metrics */}
        <div className="lg:col-span-7 space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 font-mono tabular-nums">
            <div
              className={`jgs-panel p-5 ${
                metrics.isRejectedBelowMinLot ? 'border-[#EF4444]/60 bg-[#1A0D16]' : ''
              }`}
            >
              <div className="text-[11px] text-[#7E7494] uppercase">Approved Volume</div>
              {metrics.approvedLotSizeOrNull !== null ? (
                <>
                  <div className="text-2xl font-bold text-[#D4AF37] mt-1">
                    {metrics.approvedLotSizeOrNull.toFixed(2)}{' '}
                    <span className="text-xs font-normal text-[#B8B0C8]">
                      {accountUnit === 'USC' ? 'Cent Lots' : 'Std Lots'}
                    </span>
                  </div>
                  <div className="text-[11px] text-[#B8B0C8] mt-1">
                    For {metrics.stopLossPoints} pt Stop Loss
                  </div>
                </>
              ) : (
                <>
                  <div className="text-lg font-bold text-[#EF4444] mt-1">
                    REJECTED (&lt; 0.01 Lot)
                  </div>
                  <div className="text-[11px] text-[#F3E5AB] mt-1">
                    Ideal {metrics.rawIdealLotSize} lot &lt; min 0.01. Switch to USC!
                  </div>
                </>
              )}
            </div>

            <div className="jgs-panel p-5">
              <div className="text-[11px] text-[#7E7494] uppercase">1R Monetary Risk</div>
              <div className="text-2xl font-bold text-[#EF4444] mt-1">
                -{metrics.riskAmountInUnit.toFixed(2)} {accountUnit}
              </div>
              <div className="text-[11px] text-[#B8B0C8] mt-1">
                {metrics.riskPercent}% of {accountBalance.toLocaleString()} {accountUnit}
              </div>
            </div>

            <div className="jgs-panel p-5">
              <div className="text-[11px] text-[#7E7494] uppercase">
                Target Reward (+{metrics.rewardToRiskRatio}R)
              </div>
              <div className="text-2xl font-bold text-[#10B981] mt-1">
                +{metrics.projectedRewardInUnit.toFixed(2)} {accountUnit}
              </div>
              <div className="text-[11px] text-[#B8B0C8] mt-1">
                TP at +{metrics.takeProfitPoints} points
              </div>
            </div>

            <div className="jgs-panel p-5">
              <div className="text-[11px] text-[#7E7494] uppercase">Breakeven Win Rate</div>
              <div className="text-2xl font-bold text-[#F7F4EE] mt-1">
                {metrics.breakevenWinRatePercent}%
              </div>
              <div className="text-[11px] text-[#10B981] mt-1">
                Win &gt; {metrics.breakevenWinRatePercent}% = Profitable
              </div>
            </div>

            <div className="jgs-panel p-5">
              <div className="text-[11px] text-[#7E7494] uppercase">Expectancy @ 45% Win Rate</div>
              <div
                className={`text-2xl font-bold mt-1 ${
                  metrics.expectedValueAt45PercentWinRateR > 0
                    ? 'text-[#10B981]'
                    : 'text-[#EF4444]'
                }`}
              >
                {metrics.expectedValueAt45PercentWinRateR > 0 ? '+' : ''}
                {metrics.expectedValueAt45PercentWinRateR}R / trade
              </div>
              <div className="text-[11px] text-[#B8B0C8] mt-1">
                Mathematical edge per setup
              </div>
            </div>

            <div className="jgs-panel p-5">
              <div className="text-[11px] text-[#7E7494] uppercase">Daily Circuit Breaker</div>
              <div className="text-2xl font-bold text-[#F59E0B] mt-1">
                {metrics.maxTradesBeforeDailyLock} Losses
              </div>
              <div className="text-[11px] text-[#B8B0C8] mt-1">
                Max -{metrics.dailyLossCapInUnit.toFixed(0)} {accountUnit} / day
              </div>
            </div>
          </div>

          {/* Consecutive Loss Streak Comparison */}
          <div className="jgs-panel p-6 space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37]">
                  LOSING STREAK STRESS-TESTER (10 CONSECUTIVE LOSSES)
                </span>
                <h3 className="font-display text-lg font-bold text-[#F7F4EE]">
                  Your {metrics.riskPercent}% Risk Rule vs. 5% Retail Over-Risking
                </h3>
              </div>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-left font-mono text-xs tabular-nums">
                <thead>
                  <tr className="border-b border-white/10 text-[#7E7494]">
                    <th className="py-2 pr-3">Streak</th>
                    <th className="py-2 px-3">Your Equity ({metrics.riskPercent}% Risk)</th>
                    <th className="py-2 px-3">Your Drawdown</th>
                    <th className="py-2 px-3">Gambler Equity (5% Risk)</th>
                    <th className="py-2 pl-3">Gambler Drawdown</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {metrics.streakSimulation.slice(0, 6).map((row) => (
                    <tr key={row.lossNumber}>
                      <td className="py-2 pr-3 text-[#B8B0C8]">Loss #{row.lossNumber}</td>
                      <td className="py-2 px-3 text-[#F7F4EE] font-semibold">
                        {row.remainingBalanceFixedPercent.toLocaleString()} {accountUnit}
                      </td>
                      <td className="py-2 px-3 text-[#10B981]">-{row.drawdownFixedPercent}%</td>
                      <td className="py-2 px-3 text-[#B8B0C8]">
                        {row.remainingBalanceAggressive5Percent.toLocaleString()} {accountUnit}
                      </td>
                      <td className="py-2 pl-3 text-[#EF4444]">
                        -{row.drawdownAggressive5Percent}%
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>

      {/* Nonlinear Drawdown Recovery Curve Visualizer */}
      <div className="jgs-panel p-6 sm:p-8 space-y-6">
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4">
          <div>
            <div className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-widest text-[#EF4444] font-semibold">
              <TrendingDown className="w-4 h-4" />
              NONLINEAR DRAWDOWN RECOVERY MATHEMATICS
            </div>
            <h2 className="font-display text-2xl font-bold text-[#F7F4EE] mt-1">
              Why Deep Drawdowns Are Mathematically Lethal
            </h2>
            <p className="text-sm text-[#B8B0C8] mt-1 max-w-2xl">
              Losing 10% requires only +11.1% to recover. Losing 50% requires +100% to recover.
              Losing 80% requires +400% just to return to breakeven.
            </p>
          </div>
          <Link href="/journal" className="jgs-btn-outline text-xs self-start">
            <span>Audit My Discipline in Journal</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 font-mono tabular-nums">
          {metrics.drawdownRecoveryTable.map((pt) => {
            const badgeColor =
              pt.severityZone === 'SAFE_BUFFER'
                ? 'border-[#10B981]/35 bg-[#0F1B1D] text-[#10B981]'
                : pt.severityZone === 'CAUTION_ZONE'
                  ? 'border-[#F59E0B]/35 bg-[#1D160B] text-[#F59E0B]'
                  : 'border-[#EF4444]/40 bg-[#1A0D16] text-[#EF4444]';

            return (
              <div key={pt.drawdownPercent} className={`p-4 rounded-xl border ${badgeColor}`}>
                <div className="text-[11px] uppercase opacity-80">
                  -{pt.drawdownPercent}% Drawdown
                </div>
                <div className="text-xl font-bold text-[#F7F4EE] mt-1">
                  +{pt.requiredGainPercentToRecover}%
                </div>
                <div className="text-[10px] text-[#B8B0C8] mt-1">
                  Gain needed on remaining {pt.remainingCapitalPercent}%
                </div>
              </div>
            );
          })}
        </div>

        <JeyStrategistCallout
          ruleText="Keep your maximum account drawdown above the 15% waterline. Below 30% drawdown, math starts fighting against you instead of for you."
          contextTag="SURVIVAL EQUATION"
        />
      </div>
    </div>
  );
}
