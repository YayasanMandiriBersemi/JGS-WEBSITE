'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import {
  SupportedCurrency,
  SupportedInstrument,
  AccountDenomination,
  INSTRUMENT_SPECS,
  calculateCentComparison,
  calculateBrokerSymbolPositionSize,
  convertUsdAndUsc
} from '@/lib/math/cent-calculator';
import {
  calculateRiskMetrics,
  calculateRequiredRecoveryGainPercent
} from '@/lib/math/risk-engine';
import {
  saveRiskPreset,
  loadRiskPresets,
  SavedRiskRulePreset
} from '@/lib/storage/jgs-local-store';
import { JeyStrategistCallout } from '@/components/brand/JeyStrategistCallout';
import { useLocale } from '@/i18n/LocaleContext';
import {
  Calculator,
  AlertTriangle,
  CheckCircle2,
  XOctagon,
  BookmarkPlus,
  ArrowRight,
  ArrowLeftRight,
  ShieldAlert,
  TrendingDown,
  Gauge,
  Sliders,
  Info
} from 'lucide-react';

interface BrokerSymbolQuickPreset {
  id: string;
  label: string;
  badge: string;
  equity: number;
  accountDenomination: AccountDenomination;
  riskPercentage: number;
  stopLossDistance: number;
  tickSize: number;
  tickValuePerLot: number;
  minimumLot: number;
  maximumLot: number;
  volumeStep: number;
  leverage: number;
  contractUnitsPerLot: number;
  referencePrice: number;
}

const BROKER_SYMBOL_PRESETS: BrokerSymbolQuickPreset[] = [
  {
    id: 'xauusd-cent-2500usc',
    label: 'XAUUSD Cent (2,500 USC / $25)',
    badge: 'APPROVED • 0.10 LOT',
    equity: 2500,
    accountDenomination: 'USC',
    riskPercentage: 1.0,
    stopLossDistance: 2.5,
    tickSize: 0.01,
    tickValuePerLot: 1.0,
    minimumLot: 0.01,
    maximumLot: 100.0,
    volumeStep: 0.01,
    leverage: 500,
    contractUnitsPerLot: 1,
    referencePrice: 2650.0
  },
  {
    id: 'xauusd-std-25usd-reject',
    label: 'XAUUSD Standard ($25 USD Trap)',
    badge: 'REJECTS OVER-RISK',
    equity: 25,
    accountDenomination: 'USD',
    riskPercentage: 1.0,
    stopLossDistance: 2.5,
    tickSize: 0.01,
    tickValuePerLot: 1.0,
    minimumLot: 0.01,
    maximumLot: 100.0,
    volumeStep: 0.01,
    leverage: 500,
    contractUnitsPerLot: 100,
    referencePrice: 2650.0
  },
  {
    id: 'eurusd-cent-5000usc',
    label: 'EURUSD Cent (5,000 USC / $50)',
    badge: 'APPROVED • 0.33 LOT',
    equity: 5000,
    accountDenomination: 'USC',
    riskPercentage: 1.0,
    stopLossDistance: 0.0015,
    tickSize: 0.00001,
    tickValuePerLot: 1.0,
    minimumLot: 0.01,
    maximumLot: 100.0,
    volumeStep: 0.01,
    leverage: 500,
    contractUnitsPerLot: 1000,
    referencePrice: 1.085
  },
  {
    id: 'usdjpy-cent-2500usc',
    label: 'USDJPY Cent (2,500 USC / $25)',
    badge: 'APPROVED • 0.13 LOT',
    equity: 2500,
    accountDenomination: 'USC',
    riskPercentage: 1.0,
    stopLossDistance: 0.2,
    tickSize: 0.001,
    tickValuePerLot: 0.95,
    minimumLot: 0.01,
    maximumLot: 100.0,
    volumeStep: 0.01,
    leverage: 500,
    contractUnitsPerLot: 1000,
    referencePrice: 152.4
  }
];

export function CentLabCalculator() {
  const { isId, l } = useLocale();
  // 1. Bidirectional Cent <-> USD Converter State
  const [converterUsdInput, setConverterUsdInput] = useState<number>(25);
  const [converterUscInput, setConverterUscInput] = useState<number>(2500);

  // 2. Broker-Specific Symbol Specification Position Sizer State
  const [equity, setEquity] = useState<number>(2500);
  const [accountDenomination, setAccountDenomination] = useState<AccountDenomination>('USC');
  const [riskPercentage, setRiskPercentage] = useState<number>(1.0);
  const [stopLossDistance, setStopLossDistance] = useState<number>(2.5);
  const [tickSize, setTickSize] = useState<number>(0.01);
  const [tickValuePerLot, setTickValuePerLot] = useState<number>(1.0);
  const [minimumLot, setMinimumLot] = useState<number>(0.01);
  const [maximumLot, setMaximumLot] = useState<number>(100.0);
  const [volumeStep, setVolumeStep] = useState<number>(0.01);

  // Margin Estimator Inputs
  const [leverage, setLeverage] = useState<number>(500);
  const [contractUnitsPerLot, setContractUnitsPerLot] = useState<number>(1);
  const [referencePrice, setReferencePrice] = useState<number>(2650.0);

  // 3. Drawdown Simulator & Side-by-Side Comparison State
  const [customDrawdownTestPct, setCustomDrawdownTestPct] = useState<number>(25);
  const [rewardToRiskRatio, setRewardToRiskRatio] = useState<number>(2.0);
  const [dailyMaxLossPercent, setDailyMaxLossPercent] = useState<number>(3.0);

  // 4. Side-by-Side Comparison Matrix State
  const [depositAmount, setDepositAmount] = useState<number>(25);
  const [depositCurrency, setDepositCurrency] = useState<SupportedCurrency>('USD');
  const [instrument, setInstrument] = useState<SupportedInstrument>('XAUUSD');
  const [stopLossPoints, setStopLossPoints] = useState<number>(250);

  const [savedNotice, setSavedNotice] = useState<string | null>(null);
  const [presets, setPresets] = useState<SavedRiskRulePreset[]>(() => loadRiskPresets());

  // Handlers for Bidirectional USD <-> USC Converter
  function handleUsdConverterChange(val: number) {
    setConverterUsdInput(val);
    const conv = convertUsdAndUsc(val, 'USD');
    setConverterUscInput(conv.usc);
  }

  function handleUscConverterChange(val: number) {
    setConverterUscInput(val);
    const conv = convertUsdAndUsc(val, 'USC');
    setConverterUsdInput(conv.usd);
  }

  function applyBrokerPreset(preset: BrokerSymbolQuickPreset) {
    setEquity(preset.equity);
    setAccountDenomination(preset.accountDenomination);
    setRiskPercentage(preset.riskPercentage);
    setStopLossDistance(preset.stopLossDistance);
    setTickSize(preset.tickSize);
    setTickValuePerLot(preset.tickValuePerLot);
    setMinimumLot(preset.minimumLot);
    setMaximumLot(preset.maximumLot);
    setVolumeStep(preset.volumeStep);
    setLeverage(preset.leverage);
    setContractUnitsPerLot(preset.contractUnitsPerLot);
    setReferencePrice(preset.referencePrice);
  }

  // Compute Broker-Specific Position Size (with strict rejection rule)
  const brokerSizingResult = useMemo(
    () =>
      calculateBrokerSymbolPositionSize({
        equity,
        accountDenomination,
        riskPercentage,
        stopLossDistance,
        tickSize,
        tickValuePerLot,
        minimumLot,
        maximumLot,
        volumeStep,
        leverage,
        contractUnitsPerLot,
        referencePrice
      }),
    [
      equity,
      accountDenomination,
      riskPercentage,
      stopLossDistance,
      tickSize,
      tickValuePerLot,
      minimumLot,
      maximumLot,
      volumeStep,
      leverage,
      contractUnitsPerLot,
      referencePrice
    ]
  );

  // Compute Drawdown & Streak Simulation
  const drawdownMetrics = useMemo(
    () =>
      calculateRiskMetrics({
        accountBalance: equity > 0 ? equity : 2500,
        accountUnit: accountDenomination,
        riskPercent: riskPercentage > 0 ? riskPercentage : 1.0,
        stopLossPoints: brokerSizingResult.stopLossTicks > 0 ? brokerSizingResult.stopLossTicks : 250,
        rewardToRiskRatio,
        dailyMaxLossPercent,
        pointValuePerMinLot: tickValuePerLot * minimumLot
      }),
    [
      equity,
      accountDenomination,
      riskPercentage,
      brokerSizingResult.stopLossTicks,
      rewardToRiskRatio,
      dailyMaxLossPercent,
      tickValuePerLot,
      minimumLot
    ]
  );

  const customRecoveryNeededPct = useMemo(
    () => calculateRequiredRecoveryGainPercent(customDrawdownTestPct),
    [customDrawdownTestPct]
  );

  // Compute Side-by-Side Comparison Matrix
  const comparisonResult = useMemo(
    () =>
      calculateCentComparison({
        depositAmount,
        depositCurrency,
        instrument,
        stopLossPoints,
        riskPercent: riskPercentage > 0 ? riskPercentage : 1.0,
        leverage
      }),
    [depositAmount, depositCurrency, instrument, stopLossPoints, riskPercentage, leverage]
  );

  function handleSavePreset() {
    const newPreset: SavedRiskRulePreset = {
      id: `preset-${Date.now()}`,
      name: `${instrument} • $${comparisonResult.depositUsd} (${comparisonResult.depositUsc} USC) @ ${riskPercentage}%`,
      depositUsd: comparisonResult.depositUsd,
      accountMode: accountDenomination === 'USC' ? 'CENT_USC' : 'STANDARD_USD',
      instrument,
      riskPercent: riskPercentage,
      dailyMaxLossPercent: Number((riskPercentage * 3).toFixed(1)),
      defaultStopLossPoints:
        brokerSizingResult.stopLossTicks > 0
          ? Math.round(brokerSizingResult.stopLossTicks)
          : stopLossPoints,
      createdAt: new Date().toISOString()
    };
    const next = saveRiskPreset(newPreset);
    setPresets(next);
    setSavedNotice('Saved to your Strategist Risk Presets.');
    setTimeout(() => setSavedNotice(null), 3500);
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-10">
      {/* Header */}
      <div className="jgs-panel p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D4AF37]">
            <Calculator className="w-4 h-4" />
            <span>
              {isId
                ? 'JGS CENT LAB • KALKULATOR SPESIFIKASI SIMBOL BROKER, MARGIN & DRAWDOWN'
                : 'JGS CENT LAB • BROKER SPECIFICATION SIZING, MARGIN & DRAWDOWN ENGINE'}
            </span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#F7F4EE]">
            {isId
              ? 'Kalkulator Ukuran Lot Berbasis Spesifikasi Broker & Simulasi Ketahanan Modal'
              : 'Precision Micro-Capital Position Sizing & Survivability Lab'}
          </h1>
          <p className="text-sm sm:text-base text-[#B8B0C8] leading-relaxed">
            {isId ? (
              <>
                Konversikan antara <span className="text-[#F3E5AB]">USD ($)</span> dan{' '}
                <span className="text-[#D4AF37]">US Cents (USC)</span>, hitung ukuran lot secara
                presisi menggunakan spesifikasi simbol broker Anda, estimasikan kebutuhan margin,
                dan uji ketahanan drawdown secara gratis.
              </>
            ) : (
              <>
                Convert between <span className="text-[#F3E5AB]">USD ($)</span> and{' '}
                <span className="text-[#D4AF37]">US Cents (USC)</span>, compute exact position
                volume using broker-specific symbol specifications, estimate margin requirements,
                and stress-test drawdown survivability.
              </>
            )}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3 shrink-0">
          <button type="button" onClick={handleSavePreset} className="jgs-btn-gold text-xs">
            <BookmarkPlus className="w-4 h-4" />
            <span>{isId ? 'Simpan Preset Risiko' : 'Save Sizing Preset'}</span>
          </button>
          <Link href={l('/playground')} className="jgs-btn-outline text-xs">
            <span>{isId ? 'Uji di Trading Playground' : 'Test in Trading Playground'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>
      </div>

      {/* Explicit Broker Specification Accuracy Notice */}
      <div className="rounded-xl border border-[#D4AF37]/40 bg-[#150E24] p-5 flex items-start gap-3.5">
        <Info className="w-5 h-5 text-[#D4AF37] shrink-0 mt-0.5" />
        <div className="space-y-1 text-xs sm:text-sm text-[#F7F4EE]/90 leading-relaxed">
          <strong className="block text-[#F3E5AB]">
            {isId
              ? 'Penting: Denominasi Cent (1 USD = 100 USC) Tidak Otomatis Berarti Ukuran Kontrak 100x Lebih Kecil'
              : 'Important: Cent Denomination (1 USD = 100 USC) Does Not Automatically Mean Contract Size Is 100x Smaller'}
          </strong>
          <p className="text-[#BEB6CE]">
            {isId
              ? 'Ukuran kontrak (Contract Size), nilai tick (Tick Value), dan volume minimum (Minimum Lot) berbeda-beda di setiap broker dan jenis simbol MT5. Selalu masukkan nilai Tick Size, Tick Value per Lot, dan Minimum Lot sesuai jendela "Specification" di MT5 Anda. Jika lot minimum melampaui batas risiko Anda, kalkulator ini akan menolak ukuran lot tersebut secara otomatis.'
              : 'Contract Size, Tick Value, and Minimum Volume vary across brokers and MT5 symbol types. Always input the exact Tick Size, Tick Value per Lot, and Minimum Lot from your MT5 Symbol Specification window. If the minimum lot exceeds your risk limit, this calculator will explicitly reject the trade size rather than rounding up.'}
          </p>
        </div>
      </div>

      {savedNotice && (
        <div className="p-3 rounded-xl bg-[#0F1B1D] border border-[#10B981] text-xs font-mono text-[#10B981] flex items-center justify-between">
          <span>✓ {savedNotice}</span>
          <Link href={l('/account')} className="underline">
            {isId ? 'Lihat di Akun →' : 'View in Strategist Account →'}
          </Link>
        </div>
      )}

      {/* =====================================================================
          SECTION 1: BIDIRECTIONAL CENT (USC) <-> USD CONVERTER
      ===================================================================== */}
      <div className="jgs-panel p-6 border-[#D4AF37]/30 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3">
          <div className="flex items-center gap-2">
            <ArrowLeftRight className="w-4 h-4 text-[#D4AF37]" />
            <h2 className="font-display text-lg font-bold text-[#F7F4EE]">
              1. Bidirectional USD ($) ↔ Cent Account (USC) Converter
            </h2>
          </div>
          <span className="text-xs font-mono text-[#D4AF37]">
            FIXED CONVERSION RATIO: $1.00 USD = 100.00 USC
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-center">
          <div className="md:col-span-5">
            <label htmlFor="conv-usd-input" className="jgs-label">
              US Dollar Capital (USD $)
            </label>
            <input
              id="conv-usd-input"
              type="number"
              min={0}
              step="any"
              value={converterUsdInput}
              onChange={(e) => handleUsdConverterChange(Number(e.target.value))}
              className="jgs-input text-base font-bold text-[#F7F4EE]"
            />
          </div>

          <div className="md:col-span-2 flex flex-col items-center justify-center py-2">
            <div className="px-3 py-1.5 rounded-full bg-[#191129] border border-[#D4AF37]/40 text-xs font-mono text-[#D4AF37]">
              × 100 / ÷ 100
            </div>
          </div>

          <div className="md:col-span-5">
            <label htmlFor="conv-usc-input" className="jgs-label">
              MT5 Cent Account Balance (USC ¢)
            </label>
            <input
              id="conv-usc-input"
              type="number"
              min={0}
              step="any"
              value={converterUscInput}
              onChange={(e) => handleUscConverterChange(Number(e.target.value))}
              className="jgs-input text-base font-bold text-[#D4AF37]"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-between gap-3 pt-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[11px] font-mono text-[#7E7494]">Quick Load Equity into Sizer:</span>
            {[10, 25, 50, 100].map((usdAmt) => (
              <button
                key={usdAmt}
                type="button"
                onClick={() => {
                  handleUsdConverterChange(usdAmt);
                  if (accountDenomination === 'USC') {
                    setEquity(usdAmt * 100);
                  } else {
                    setEquity(usdAmt);
                  }
                }}
                className="px-2.5 py-1 rounded bg-[#191129] border border-white/10 text-xs font-mono text-[#F3E5AB] hover:border-[#D4AF37] transition-colors"
              >
                ${usdAmt} ({(usdAmt * 100).toLocaleString()} USC)
              </button>
            ))}
          </div>

          <div className="text-xs font-mono text-[#B8B0C8]">
            1% Risk on ${converterUsdInput.toFixed(2)} ={' '}
            <span className="text-[#10B981] font-bold">
              {(converterUscInput * 0.01).toFixed(2)} USC (${(converterUsdInput * 0.01).toFixed(2)} USD)
            </span>
          </div>
        </div>
      </div>

      {/* =====================================================================
          SECTION 2: BROKER-SPECIFIC SYMBOL SPECIFICATION POSITION SIZER
          (WITH EXPLICIT REJECTION GUARD & MARGIN ESTIMATOR)
      ===================================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: 9 Broker Symbol Inputs + Margin Inputs */}
        <div className="lg:col-span-6 jgs-panel p-6 space-y-5">
          <div className="flex items-center justify-between border-b border-white/10 pb-3">
            <div className="flex items-center gap-2">
              <Sliders className="w-4 h-4 text-[#D4AF37]" />
              <h2 className="font-display text-lg font-bold text-[#F7F4EE]">
                2. Broker Symbol Specification Position Sizer
              </h2>
            </div>
            <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-[#191129] text-[#D4AF37]">
              Strict Risk Guard
            </span>
          </div>

          {/* Quick Broker Specification Presets */}
          <div className="space-y-2">
            <span className="text-[11px] font-mono uppercase tracking-wider text-[#B8B0C8] block">
              Load Broker Contract Specification Preset:
            </span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {BROKER_SYMBOL_PRESETS.map((preset) => (
                <button
                  key={preset.id}
                  type="button"
                  onClick={() => applyBrokerPreset(preset)}
                  className="text-left p-2.5 rounded-lg bg-[#09060F] border border-white/10 hover:border-[#D4AF37] transition-all"
                >
                  <div className="flex items-center justify-between gap-1">
                    <span className="text-xs font-mono font-bold text-[#F7F4EE] truncate">
                      {preset.label}
                    </span>
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded shrink-0 ${
                        preset.id.includes('reject')
                          ? 'bg-[#EF4444]/20 text-[#EF4444]'
                          : 'bg-[#10B981]/20 text-[#10B981]'
                      }`}
                    >
                      {preset.badge}
                    </span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Core Account & Risk Inputs (Equity, Denomination, Risk %, SL Distance) */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
            <div>
              <label htmlFor="spec-equity" className="jgs-label">
                1. Account Equity ({accountDenomination})
              </label>
              <input
                id="spec-equity"
                type="number"
                step="any"
                value={equity}
                onChange={(e) => setEquity(Number(e.target.value))}
                className="jgs-input"
              />
            </div>

            <div>
              <label htmlFor="spec-denomination" className="jgs-label">
                2. Account Denomination
              </label>
              <select
                id="spec-denomination"
                value={accountDenomination}
                onChange={(e) => setAccountDenomination(e.target.value as AccountDenomination)}
                className="jgs-input"
              >
                <option value="USC">USC (Cent Account • 1 USD = 100 USC)</option>
                <option value="USD">USD (Standard Account • $)</option>
              </select>
            </div>

            <div>
              <label htmlFor="spec-risk-pct" className="jgs-label">
                3. Risk Percentage (%)
              </label>
              <input
                id="spec-risk-pct"
                type="number"
                step="0.1"
                value={riskPercentage}
                onChange={(e) => setRiskPercentage(Number(e.target.value))}
                className="jgs-input"
              />
            </div>

            <div>
              <label htmlFor="spec-sl-distance" className="jgs-label">
                4. Stop-Loss Distance (Price Units)
              </label>
              <input
                id="spec-sl-distance"
                type="number"
                step="any"
                value={stopLossDistance}
                onChange={(e) => setStopLossDistance(Number(e.target.value))}
                className="jgs-input"
              />
            </div>
          </div>

          {/* Broker Symbol Specification Fields (Tick Size, Tick Value/Lot, Min Lot, Max Lot, Volume Step) */}
          <div className="p-4 rounded-xl bg-[#09060F] border border-white/10 space-y-3.5">
            <div className="text-xs font-mono uppercase tracking-wider text-[#A882DD] font-semibold">
              Broker Contract & Volume Constraints
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label htmlFor="spec-tick-size" className="jgs-label">
                  5. Tick Size (Min Price Step)
                </label>
                <input
                  id="spec-tick-size"
                  type="number"
                  step="any"
                  value={tickSize}
                  onChange={(e) => setTickSize(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>

              <div>
                <label htmlFor="spec-tick-value" className="jgs-label">
                  6. Tick Value per 1.00 Lot ({accountDenomination})
                </label>
                <input
                  id="spec-tick-value"
                  type="number"
                  step="any"
                  value={tickValuePerLot}
                  onChange={(e) => setTickValuePerLot(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-3">
              <div>
                <label htmlFor="spec-min-lot" className="jgs-label">
                  7. Minimum Lot
                </label>
                <input
                  id="spec-min-lot"
                  type="number"
                  step="any"
                  value={minimumLot}
                  onChange={(e) => setMinimumLot(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>

              <div>
                <label htmlFor="spec-max-lot" className="jgs-label">
                  8. Maximum Lot
                </label>
                <input
                  id="spec-max-lot"
                  type="number"
                  step="any"
                  value={maximumLot}
                  onChange={(e) => setMaximumLot(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>

              <div>
                <label htmlFor="spec-vol-step" className="jgs-label">
                  9. Volume Step
                </label>
                <input
                  id="spec-vol-step"
                  type="number"
                  step="any"
                  value={volumeStep}
                  onChange={(e) => setVolumeStep(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>
            </div>
          </div>

          {/* Margin Estimator Inputs */}
          <div className="p-4 rounded-xl bg-[#09060F] border border-white/10 space-y-3">
            <div className="text-xs font-mono uppercase tracking-wider text-[#D4AF37] font-semibold">
              Margin Estimator Parameters
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label htmlFor="spec-leverage" className="jgs-label">
                  Leverage (1:X)
                </label>
                <select
                  id="spec-leverage"
                  value={leverage}
                  onChange={(e) => setLeverage(Number(e.target.value))}
                  className="jgs-input"
                >
                  <option value={100}>1 : 100</option>
                  <option value={200}>1 : 200</option>
                  <option value={500}>1 : 500</option>
                  <option value={1000}>1 : 1000</option>
                </select>
              </div>
              <div>
                <label htmlFor="spec-contract-units" className="jgs-label">
                  Units / 1.00 Lot
                </label>
                <input
                  id="spec-contract-units"
                  type="number"
                  step="any"
                  value={contractUnitsPerLot}
                  onChange={(e) => setContractUnitsPerLot(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>
              <div>
                <label htmlFor="spec-ref-price" className="jgs-label">
                  Asset Price
                </label>
                <input
                  id="spec-ref-price"
                  type="number"
                  step="any"
                  value={referencePrice}
                  onChange={(e) => setReferencePrice(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right: Position Sizing Verdict, Explicit Rejection Guard & Margin Estimator */}
        <div className="lg:col-span-6 space-y-5">
          {/* Status / Verdict Card */}
          <div
            className={`rounded-xl p-6 border space-y-5 ${
              brokerSizingResult.status === 'REJECTED_RISK_LIMIT_EXCEEDED' ||
              brokerSizingResult.status === 'INVALID_PARAMETERS'
                ? 'bg-[#1A0D16] border-[#EF4444]'
                : 'bg-[#0F1B1D] border-[#10B981]/60'
            }`}
          >
            <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
              <span className="text-xs font-mono uppercase tracking-wider font-bold text-[#F7F4EE]">
                POSITION SIZING ENGINE VERDICT
              </span>
              {brokerSizingResult.status === 'REJECTED_RISK_LIMIT_EXCEEDED' && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#EF4444]/20 text-[#EF4444] text-xs font-mono font-bold">
                  <XOctagon className="w-4 h-4" />
                  REJECTED • EXCEEDS RISK LIMIT
                </span>
              )}
              {brokerSizingResult.status === 'INVALID_PARAMETERS' && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#EF4444]/20 text-[#EF4444] text-xs font-mono font-bold">
                  <AlertTriangle className="w-4 h-4" />
                  VALIDATION ERROR
                </span>
              )}
              {(brokerSizingResult.status === 'APPROVED' ||
                brokerSizingResult.status === 'CAPPED_AT_MAXIMUM_LOT') && (
                <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded bg-[#10B981]/20 text-[#10B981] text-xs font-mono font-bold">
                  <CheckCircle2 className="w-4 h-4" />
                  {brokerSizingResult.status === 'CAPPED_AT_MAXIMUM_LOT'
                    ? 'APPROVED (CAPPED AT MAX LOT)'
                    : 'RISK-COMPLIANT VOLUME APPROVED'}
                </span>
              )}
            </div>

            {/* Headline & Primary Volume Display */}
            <div className="p-4 rounded-xl bg-[#09060F]/90 border border-white/10 space-y-2">
              <div className="text-xs font-mono uppercase text-[#B8B0C8]">
                {brokerSizingResult.rejectionOrStatusHeadline}
              </div>

              {brokerSizingResult.isExecutable && brokerSizingResult.approvedLotSize !== null ? (
                <div className="flex flex-wrap items-baseline justify-between gap-4">
                  <div className="font-mono text-3xl sm:text-4xl font-bold text-[#D4AF37] tabular-nums">
                    {brokerSizingResult.approvedLotSize.toFixed(2)}{' '}
                    <span className="text-lg text-[#F7F4EE]">
                      {accountDenomination === 'USC' ? 'Cent Lots' : 'Standard Lots'}
                    </span>
                  </div>
                  <div className="font-mono text-sm text-[#10B981] font-bold">
                    Actual Risk: {brokerSizingResult.actualRiskAmount?.toFixed(2)}{' '}
                    {accountDenomination} ({brokerSizingResult.actualRiskPercentage}%)
                  </div>
                </div>
              ) : (
                <div className="space-y-2">
                  <div className="font-mono text-2xl sm:text-3xl font-bold text-[#EF4444]">
                    APPROVED VOLUME: REJECTED — DO NOT EXECUTE
                  </div>
                  <div className="text-xs font-mono text-[#F3E5AB]">
                    JGS Protection Rule: Position size is NEVER automatically rounded up to Minimum
                    Lot ({minimumLot}) when Minimum Lot violates your requested {riskPercentage}%
                    risk cap.
                  </div>
                </div>
              )}

              <p className="text-xs text-[#B8B0C8] leading-relaxed pt-1">
                {brokerSizingResult.rejectionOrStatusExplanation}
              </p>
            </div>

            {/* Validation Errors List (if any) */}
            {brokerSizingResult.validationErrors.length > 0 && (
              <div className="p-3.5 rounded-xl bg-[#EF4444]/15 border border-[#EF4444] text-xs font-mono text-[#F7F4EE] space-y-1">
                <div className="font-bold text-[#EF4444]">Please fix the following inputs:</div>
                <ul className="list-disc list-inside space-y-0.5">
                  {brokerSizingResult.validationErrors.map((err, i) => (
                    <li key={i}>{err}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Mathematical Specification Breakdown Table */}
            <div className="space-y-2 font-mono text-xs tabular-nums">
              <div className="flex justify-between py-1.5 border-b border-white/10">
                <span className="text-[#7E7494]">Account Equity Converted:</span>
                <span className="text-[#F7F4EE] font-semibold">
                  {brokerSizingResult.equityUscEquivalent.toLocaleString()} USC ($
                  {brokerSizingResult.equityUsdEquivalent.toFixed(2)} USD)
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/10">
                <span className="text-[#7E7494]">
                  Max Allowed Risk ({brokerSizingResult.riskPercentage}%):
                </span>
                <span className="text-[#D4AF37] font-bold">
                  {brokerSizingResult.maxAllowedRiskAmount.toFixed(2)} {accountDenomination} ($
                  {brokerSizingResult.maxAllowedRiskUsdEquivalent.toFixed(2)} USD)
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/10">
                <span className="text-[#7E7494]">Stop-Loss Ticks (Distance ÷ Tick Size):</span>
                <span className="text-[#F7F4EE]">{brokerSizingResult.stopLossTicks} Ticks</span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/10">
                <span className="text-[#7E7494]">Stop-Out Loss per 1.00 Full Lot:</span>
                <span className="text-[#F7F4EE]">
                  {brokerSizingResult.lossPerOneFullLot.toFixed(2)} {accountDenomination}
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/10">
                <span className="text-[#7E7494]">
                  Loss at Broker Minimum Lot ({minimumLot}):
                </span>
                <span
                  className={
                    brokerSizingResult.minimumLotRiskPercentage > riskPercentage
                      ? 'text-[#EF4444] font-bold'
                      : 'text-[#10B981]'
                  }
                >
                  {brokerSizingResult.lossAtMinimumLot.toFixed(2)} {accountDenomination} (
                  {brokerSizingResult.minimumLotRiskPercentage}% of equity)
                </span>
              </div>
              <div className="flex justify-between py-1.5 border-b border-white/10">
                <span className="text-[#7E7494]">Unrounded Ideal Mathematical Volume:</span>
                <span className="text-[#B8B0C8]">
                  {brokerSizingResult.rawIdealLotSize.toFixed(4)} Lots
                </span>
              </div>
              <div className="flex justify-between py-1.5">
                <span className="text-[#7E7494]">
                  Step-Quantized Volume (Step {volumeStep}):
                </span>
                <span
                  className={
                    brokerSizingResult.approvedLotSize !== null
                      ? 'text-[#10B981] font-bold'
                      : 'text-[#EF4444] font-bold'
                  }
                >
                  {brokerSizingResult.approvedLotSize !== null
                    ? `${brokerSizingResult.approvedLotSize.toFixed(2)} Lots (Unused Buffer: ${brokerSizingResult.unusedRiskBufferAmount?.toFixed(2)} ${accountDenomination})`
                    : 'REJECTED (Ideal Volume < Minimum Lot)'}
                </span>
              </div>
            </div>
          </div>

          {/* Margin Estimator Card */}
          <div className="jgs-panel p-6 space-y-4">
            <div className="flex items-center justify-between border-b border-white/10 pb-3">
              <div className="flex items-center gap-2">
                <Gauge className="w-4 h-4 text-[#D4AF37]" />
                <h3 className="font-display text-base font-bold text-[#F7F4EE]">
                  3. Margin & Free Equity Estimator (1:{leverage})
                </h3>
              </div>
              <span className="text-xs font-mono text-[#7E7494]">
                Ref Price: {referencePrice}
              </span>
            </div>

            {brokerSizingResult.isExecutable &&
            brokerSizingResult.estimatedMarginRequired !== null ? (
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono tabular-nums">
                <div className="p-3.5 rounded-xl bg-[#09060F] border border-white/10">
                  <div className="text-[10px] text-[#7E7494] uppercase">Used Margin</div>
                  <div className="text-lg font-bold text-[#D4AF37] mt-1">
                    {brokerSizingResult.estimatedMarginRequired.toFixed(2)} {accountDenomination}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#09060F] border border-white/10">
                  <div className="text-[10px] text-[#7E7494] uppercase">Free Margin</div>
                  <div className="text-lg font-bold text-[#10B981] mt-1">
                    {brokerSizingResult.estimatedFreeMargin?.toFixed(2)} {accountDenomination}
                  </div>
                </div>
                <div className="p-3.5 rounded-xl bg-[#09060F] border border-white/10">
                  <div className="text-[10px] text-[#7E7494] uppercase">Margin Level</div>
                  <div className="text-lg font-bold text-[#F7F4EE] mt-1">
                    {brokerSizingResult.estimatedMarginLevelPercent
                      ? `${brokerSizingResult.estimatedMarginLevelPercent.toLocaleString()}%`
                      : 'N/A'}
                  </div>
                </div>
              </div>
            ) : (
              <div className="p-4 rounded-xl bg-[#09060F] border border-white/10 text-xs font-mono text-[#B8B0C8]">
                Margin estimation is paused because the requested position size was rejected by the
                risk limit guard.
              </div>
            )}
          </div>
        </div>
      </div>

      {/* =====================================================================
          SECTION 3: INTERACTIVE DRAWDOWN SIMULATOR & STREAK STRESS-TESTER
      ===================================================================== */}
      <div className="jgs-panel p-6 sm:p-8 space-y-6">
        <div className="flex flex-wrap items-center justify-between gap-4 border-b border-white/10 pb-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-[#D4AF37] font-semibold">
              <TrendingDown className="w-4 h-4" />
              4. DRAWDOWN SIMULATOR & CONSECUTIVE LOSS STRESS-TESTER
            </div>
            <h2 className="font-display text-2xl font-bold text-[#F7F4EE]">
              Nonlinear Drawdown Recovery & Losing Streak Simulation
            </h2>
          </div>

          <div className="flex items-center gap-3 font-mono text-xs">
            <div className="px-3 py-1.5 rounded-lg bg-[#09060F] border border-white/10">
              <span className="text-[#7E7494]">Breakeven Win Rate (1:{rewardToRiskRatio}): </span>
              <span className="text-[#D4AF37] font-bold">
                {drawdownMetrics.breakevenWinRatePercent}%
              </span>
            </div>
            <div className="px-3 py-1.5 rounded-lg bg-[#09060F] border border-white/10">
              <span className="text-[#7E7494]">Daily Circuit Breaker: </span>
              <span className="text-[#10B981] font-bold">
                {drawdownMetrics.maxTradesBeforeDailyLock} losses (-{dailyMaxLossPercent}%)
              </span>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Interactive Drawdown Recovery Slider */}
          <div className="lg:col-span-5 p-5 rounded-xl bg-[#09060F] border border-white/10 space-y-5">
            <div className="flex items-center justify-between">
              <label htmlFor="dd-slider" className="text-xs font-mono uppercase text-[#B8B0C8]">
                Simulate Account Drawdown (%):
              </label>
              <span className="font-mono text-xl font-bold text-[#EF4444]">
                -{customDrawdownTestPct}%
              </span>
            </div>

            <input
              id="dd-slider"
              type="range"
              min={5}
              max={90}
              step={5}
              value={customDrawdownTestPct}
              onChange={(e) => setCustomDrawdownTestPct(Number(e.target.value))}
              className="w-full accent-[#D4AF37] cursor-pointer"
            />

            <div className="grid grid-cols-2 gap-3 font-mono">
              <div className="p-3.5 rounded-lg bg-[#110B1C] border border-white/10">
                <div className="text-[10px] text-[#7E7494] uppercase">Remaining Equity</div>
                <div className="text-lg font-bold text-[#F7F4EE] mt-1">
                  {((equity * (100 - customDrawdownTestPct)) / 100).toFixed(1)}{' '}
                  {accountDenomination}
                </div>
                <div className="text-[11px] text-[#B8B0C8]">
                  {100 - customDrawdownTestPct}% of starting capital
                </div>
              </div>

              <div className="p-3.5 rounded-lg bg-[#1A0D16] border border-[#EF4444]/40">
                <div className="text-[10px] text-[#EF4444] uppercase">Gain Needed to Break Even</div>
                <div className="text-xl font-bold text-[#D4AF37] mt-1">
                  +{customRecoveryNeededPct}%
                </div>
                <div className="text-[11px] text-[#B8B0C8]">Asymmetric recovery trap</div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-1">
              <div>
                <label htmlFor="sim-rr" className="jgs-label">
                  Target Reward:Risk (R:R)
                </label>
                <input
                  id="sim-rr"
                  type="number"
                  min={0.5}
                  max={10}
                  step={0.5}
                  value={rewardToRiskRatio}
                  onChange={(e) => setRewardToRiskRatio(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>
              <div>
                <label htmlFor="sim-daily-cap" className="jgs-label">
                  Daily Loss Cap (%)
                </label>
                <input
                  id="sim-daily-cap"
                  type="number"
                  min={1}
                  max={20}
                  step={0.5}
                  value={dailyMaxLossPercent}
                  onChange={(e) => setDailyMaxLossPercent(Number(e.target.value))}
                  className="jgs-input"
                />
              </div>
            </div>
          </div>

          {/* 10-Trade Consecutive Losing Streak Stress Table */}
          <div className="lg:col-span-7 p-5 rounded-xl bg-[#09060F] border border-white/10 overflow-x-auto">
            <div className="text-xs font-mono uppercase text-[#D4AF37] font-semibold mb-3">
              10-Consecutive Loss Stress-Test: Your {riskPercentage}% Risk vs. Aggressive 5% Risk
            </div>
            <table className="w-full text-left border-collapse font-mono text-xs tabular-nums">
              <thead>
                <tr className="border-b border-white/10 text-[#7E7494]">
                  <th className="py-2 pr-3">Streak</th>
                  <th className="py-2 px-3">Equity ({riskPercentage}% Risk)</th>
                  <th className="py-2 px-3">Drawdown ({riskPercentage}%)</th>
                  <th className="py-2 px-3">Equity (5% Risk)</th>
                  <th className="py-2 pl-3">Drawdown (5%)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {drawdownMetrics.streakSimulation.slice(0, 6).map((step) => (
                  <tr key={step.lossNumber} className="hover:bg-white/[0.02]">
                    <td className="py-2 pr-3 text-[#B8B0C8]">Loss #{step.lossNumber}</td>
                    <td className="py-2 px-3 text-[#10B981] font-semibold">
                      {step.remainingBalanceFixedPercent.toLocaleString()} {accountDenomination}
                    </td>
                    <td className="py-2 px-3 text-[#F3E5AB]">-{step.drawdownFixedPercent}%</td>
                    <td className="py-2 px-3 text-[#B8B0C8]">
                      {step.remainingBalanceAggressive5Percent.toLocaleString()}{' '}
                      {accountDenomination}
                    </td>
                    <td className="py-2 pl-3 text-[#EF4444] font-semibold">
                      -{step.drawdownAggressive5Percent}%
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* =====================================================================
          SECTION 4: SIDE-BY-SIDE STANDARD (USD) VS CENT (USC) COMPARISON
      ===================================================================== */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 jgs-panel p-6 space-y-5">
          <h2 className="font-display text-lg font-bold text-[#F7F4EE] border-b border-white/10 pb-3">
            5. Side-by-Side Standard vs. Cent Account Comparator
          </h2>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-1">
              <label htmlFor="cent-currency" className="jgs-label">
                Currency
              </label>
              <select
                id="cent-currency"
                value={depositCurrency}
                onChange={(e) => setDepositCurrency(e.target.value as SupportedCurrency)}
                className="jgs-input"
              >
                <option value="USD">USD ($)</option>
                <option value="EUR">EUR (€)</option>
                <option value="GBP">GBP (£)</option>
                <option value="IDR">IDR (Rp)</option>
              </select>
            </div>
            <div className="col-span-2">
              <label htmlFor="cent-deposit" className="jgs-label">
                Starting Capital ({depositCurrency})
              </label>
              <input
                id="cent-deposit"
                type="number"
                min={1}
                step={depositCurrency === 'IDR' ? 50000 : 5}
                value={depositAmount}
                onChange={(e) => setDepositAmount(Number(e.target.value))}
                className="jgs-input"
              />
            </div>
          </div>

          <div>
            <label className="jgs-label">Trading Instrument</label>
            <div className="grid grid-cols-2 gap-2">
              {(Object.keys(INSTRUMENT_SPECS) as SupportedInstrument[]).map((sym) => (
                <button
                  key={sym}
                  type="button"
                  onClick={() => setInstrument(sym)}
                  className={`p-3 rounded-lg border text-left transition-all ${
                    instrument === sym
                      ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F7F4EE]'
                      : 'bg-[#09060F] border-white/10 text-[#B8B0C8] hover:border-white/25'
                  }`}
                >
                  <div className="font-mono font-bold text-sm text-[#D4AF37]">{sym}</div>
                  <div className="text-[11px] text-[#B8B0C8] truncate">
                    {INSTRUMENT_SPECS[sym].name}
                  </div>
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between mb-1">
              <label htmlFor="cent-sl-points" className="jgs-label mb-0">
                Stop Loss Distance (MT5 Points)
              </label>
              <span className="text-xs font-mono text-[#D4AF37]">
                {comparisonResult.stopLossDollarMoveOnGoldOrPips}
              </span>
            </div>
            <input
              id="cent-sl-points"
              type="number"
              min={20}
              max={5000}
              step={10}
              value={stopLossPoints}
              onChange={(e) => setStopLossPoints(Number(e.target.value))}
              className="jgs-input"
            />
          </div>

          <div className="p-3.5 rounded-xl bg-[#09060F] border border-white/10 space-y-1 text-xs">
            <div className="font-mono text-[#A882DD] font-semibold flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5" />
              <span>{comparisonResult.instrumentSpec.symbol} CONTRACT SPECIFICATION</span>
            </div>
            <p className="text-[#B8B0C8]">{comparisonResult.instrumentSpec.pointExplanation}</p>
            <p className="text-[#7E7494] pt-1">{comparisonResult.instrumentSpec.beginnerNote}</p>
          </div>
        </div>

        <div className="lg:col-span-7 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Standard Account Card */}
            <div
              className={`rounded-xl p-6 border flex flex-col justify-between space-y-5 ${
                comparisonResult.standardAnalysis.isOverRiskTrap
                  ? 'bg-[#1A0D16] border-[#EF4444]/50'
                  : 'bg-[#110B1C] border-white/15'
              }`}
            >
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-2 pb-3 border-b border-white/10">
                  <span className="text-xs font-mono uppercase font-bold text-[#B8B0C8]">
                    STANDARD ACCOUNT (USD)
                  </span>
                  <span
                    className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold ${
                      comparisonResult.standardAnalysis.isOverRiskTrap
                        ? 'bg-[#EF4444]/20 text-[#EF4444]'
                        : 'bg-[#10B981]/20 text-[#10B981]'
                    }`}
                  >
                    <ShieldAlert className="w-3 h-3" />
                    {comparisonResult.standardAnalysis.verdictTitle}
                  </span>
                </div>

                <div className="space-y-2.5 font-mono text-xs tabular-nums">
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-[#7E7494]">Account Balance:</span>
                    <span className="text-[#F7F4EE] font-semibold">
                      {comparisonResult.standardAnalysis.balanceDisplay}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-[#7E7494]">Ideal Math Lot Size:</span>
                    <span className="text-[#B8B0C8]">
                      {comparisonResult.standardAnalysis.rawIdealLotSize.toFixed(4)} Lots
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-[#7E7494]">Risk-Compliant Lot:</span>
                    <span
                      className={`text-sm font-bold ${
                        comparisonResult.standardAnalysis.approvedLotSizeOrNull === null
                          ? 'text-[#EF4444]'
                          : 'text-[#F7F4EE]'
                      }`}
                    >
                      {comparisonResult.standardAnalysis.approvedLotSizeOrNull === null
                        ? 'REJECTED (< 0.01 Min)'
                        : `${comparisonResult.standardAnalysis.approvedLotSizeOrNull.toFixed(2)} Std Lot`}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-[#7E7494]">If Forced at 0.01 Min Lot:</span>
                    <span className="text-[#EF4444] font-bold">
                      -${comparisonResult.standardAnalysis.actualRiskAmount.toFixed(2)} USD (
                      {comparisonResult.standardAnalysis.actualRiskPercentOfAccount}%)
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-[#7E7494]">Losses to -25% Drawdown:</span>
                    <span className="text-[#F59E0B] font-bold">
                      {
                        comparisonResult.standardAnalysis
                          .survivableConsecutiveLossesTo25PercentDrawdown
                      }{' '}
                      trades
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-[#B8B0C8] leading-relaxed bg-[#09060F]/80 p-3 rounded-lg border border-white/5">
                {comparisonResult.standardAnalysis.verdictDetail}
              </p>
            </div>

            {/* Cent Account Card */}
            <div className="rounded-xl p-6 bg-[#0F1B1D] border border-[#10B981]/50 flex flex-col justify-between space-y-5">
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-2 pb-3 border-b border-white/10">
                  <span className="text-xs font-mono uppercase font-bold text-[#10B981]">
                    JGS CENT ACCOUNT (USC)
                  </span>
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#10B981]/20 text-[#10B981]">
                    <CheckCircle2 className="w-3 h-3" />
                    {comparisonResult.centAnalysis.verdictTitle}
                  </span>
                </div>

                <div className="space-y-2.5 font-mono text-xs tabular-nums">
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-[#7E7494]">Account Balance:</span>
                    <span className="text-[#D4AF37] font-semibold">
                      {comparisonResult.centAnalysis.balanceDisplay}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-[#7E7494]">Ideal Math Lot Size:</span>
                    <span className="text-[#B8B0C8]">
                      {comparisonResult.centAnalysis.rawIdealLotSize.toFixed(4)} Cent Lots
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-[#7E7494]">Approved Cent Volume:</span>
                    <span className="text-base font-bold text-[#D4AF37]">
                      {comparisonResult.centAnalysis.approvedLotSizeOrNull === null
                        ? 'REJECTED (< 0.01 Min)'
                        : `${comparisonResult.centAnalysis.approvedLotSizeOrNull.toFixed(2)} Cent Lot`}
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5 border-b border-white/5">
                    <span className="text-[#7E7494]">Actual Stop-Out Loss:</span>
                    <span className="text-[#10B981] font-bold">
                      -{comparisonResult.centAnalysis.actualRiskAmount.toFixed(2)} USC (-$
                      {comparisonResult.centAnalysis.actualRiskUsdEquivalent.toFixed(2)})
                    </span>
                  </div>
                  <div className="flex justify-between py-1.5">
                    <span className="text-[#7E7494]">Losses to -25% Drawdown:</span>
                    <span className="text-[#10B981] font-bold">
                      {comparisonResult.centAnalysis.survivableConsecutiveLossesTo25PercentDrawdown}{' '}
                      trades
                    </span>
                  </div>
                </div>
              </div>

              <p className="text-xs text-[#F7F4EE] leading-relaxed bg-[#09060F]/80 p-3 rounded-lg border border-[#10B981]/20">
                {comparisonResult.centAnalysis.verdictDetail}
              </p>
            </div>
          </div>

          <JeyStrategistCallout
            ruleText={comparisonResult.jeyStreetRule}
            contextTag="LIVE SIZING VERDICT"
          />

          {presets.length > 0 && (
            <div className="jgs-panel p-5 space-y-3">
              <div className="text-xs font-mono uppercase tracking-wider text-[#D4AF37]">
                YOUR SAVED CENT SIZING PRESETS ({presets.length})
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {presets.slice(0, 4).map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      setDepositCurrency('USD');
                      setDepositAmount(p.depositUsd);
                      setInstrument(p.instrument);
                      setRiskPercentage(p.riskPercent);
                      setStopLossPoints(p.defaultStopLossPoints);
                    }}
                    className="text-left p-3 rounded-lg bg-[#09060F] border border-white/10 hover:border-[#D4AF37] text-xs font-mono transition-colors"
                  >
                    <div className="text-[#F3E5AB] font-semibold">{p.name}</div>
                    <div className="text-[#7E7494] mt-0.5">
                      SL: {p.defaultStopLossPoints} pts • Daily Cap: -{p.dailyMaxLossPercent}%
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
