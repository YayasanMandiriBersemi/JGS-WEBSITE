'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import {
  DICTIONARY_TERMS,
  DICTIONARY_CATEGORY_LABELS,
  DictionaryCategory,
  DictionaryIllustrationType,
} from '@/lib/data/dictionary-terms';
import { useLocale } from '@/i18n/LocaleContext';
import {
  Search,
  BookOpen,
  AlertTriangle,
  Coins,
  Cpu,
  ArrowRight,
  RotateCcw,
  Link2,
} from 'lucide-react';

function TermIllustrationSVG({ type }: { type: DictionaryIllustrationType }) {
  switch (type) {
    case 'CENT_DIVISIBILITY':
      return (
        <svg
          viewBox="0 0 360 74"
          className="w-full h-auto"
          role="img"
          aria-label="Cent lot divisibility illustration"
        >
          <rect
            x={8}
            y={12}
            width={145}
            height={50}
            rx={6}
            fill="#1A0D16"
            stroke="#EF4444"
            strokeOpacity={0.45}
          />
          <text x={18} y={32} fill="#EF4444" fontSize="10" fontFamily="monospace" fontWeight="bold">
            STD 0.01 LOT = 1 OZ
          </text>
          <text x={18} y={48} fill="#BEB6CE" fontSize="9" fontFamily="monospace">
            $2.50 Move = -$2.50 (10%)
          </text>
          <path d="M162 37 L196 37" stroke="#D4AF37" strokeWidth={1.5} strokeDasharray="3 2" />
          <text
            x={179}
            y={29}
            textAnchor="middle"
            fill="#D4AF37"
            fontSize="8"
            fontFamily="monospace"
          >
            SPEC CHECK
          </text>
          <rect
            x={205}
            y={12}
            width={147}
            height={50}
            rx={6}
            fill="#0F1B1D"
            stroke="#10B981"
            strokeOpacity={0.55}
          />
          <text
            x={215}
            y={32}
            fill="#10B981"
            fontSize="10"
            fontFamily="monospace"
            fontWeight="bold"
          >
            MICRO CENT SPEC = 25 USC
          </text>
          <text x={215} y={48} fill="#F7F4EE" fontSize="9" fontFamily="monospace">
            1.0% Risk ($0.25)
          </text>
        </svg>
      );
    case 'SPREAD_MECHANICS':
      return (
        <svg
          viewBox="0 0 360 74"
          className="w-full h-auto"
          role="img"
          aria-label="Bid Ask Spread illustration"
        >
          <line
            x1={20}
            x2={340}
            y1={24}
            y2={24}
            stroke="#EF4444"
            strokeWidth={1.5}
            strokeDasharray="4 3"
          />
          <text x={24} y={18} fill="#EF4444" fontSize="9" fontFamily="monospace">
            ASK (BUY ENTRY / SHORT EXIT): 2650.20
          </text>
          <line x1={20} x2={340} y1={52} y2={52} stroke="#10B981" strokeWidth={1.5} />
          <text x={24} y={66} fill="#10B981" fontSize="9" fontFamily="monospace">
            BID (CHART LINE / LONG EXIT): 2650.00
          </text>
          <rect
            x={255}
            y={26}
            width={78}
            height={24}
            rx={4}
            fill="#191129"
            stroke="#D4AF37"
            strokeOpacity={0.4}
          />
          <text
            x={294}
            y={41}
            textAnchor="middle"
            fill="#D4AF37"
            fontSize="9"
            fontFamily="monospace"
          >
            20 PT SPREAD
          </text>
        </svg>
      );
    case 'LIQUIDITY_SWEEP':
      return (
        <svg
          viewBox="0 0 360 74"
          className="w-full h-auto"
          role="img"
          aria-label="Liquidity Sweep wick vs body close"
        >
          <line
            x1={15}
            x2={345}
            y1={32}
            y2={32}
            stroke="#D4AF37"
            strokeWidth={1.2}
            strokeDasharray="4 4"
          />
          <text x={20} y={26} fill="#D4AF37" fontSize="9" fontFamily="monospace">
            ASIAN HIGH LIQUIDITY ($2650.00)
          </text>
          <line x1={190} x2={190} y1={8} y2={62} stroke="#EF4444" strokeWidth={2} />
          <rect x={180} y={36} width={20} height={20} fill="#EF4444" rx={2} />
          <text x={210} y={20} fill="#F3E5AB" fontSize="9" fontFamily="monospace">
            ← Rejection Wick
          </text>
          <text x={210} y={50} fill="#10B981" fontSize="9" fontFamily="monospace">
            ← Body Closes Inside
          </text>
        </svg>
      );
    case 'ASYMMETRIC_RR':
      return (
        <svg
          viewBox="0 0 360 74"
          className="w-full h-auto"
          role="img"
          aria-label="Asymmetric Risk to Reward ratio"
        >
          <rect x={16} y={22} width={85} height={30} rx={4} fill="#1A0D16" stroke="#EF4444" />
          <text
            x={58}
            y={41}
            textAnchor="middle"
            fill="#EF4444"
            fontSize="10"
            fontFamily="monospace"
            fontWeight="bold"
          >
            -1.0R RISK
          </text>
          <rect x={112} y={14} width={232} height={46} rx={5} fill="#0F1B1D" stroke="#10B981" />
          <text
            x={228}
            y={41}
            textAnchor="middle"
            fill="#10B981"
            fontSize="11"
            fontFamily="monospace"
            fontWeight="bold"
          >
            +2.5R TARGET REWARD (28.6% BREAKEVEN)
          </text>
        </svg>
      );
    case 'DRAWDOWN_CLIFF':
      return (
        <svg
          viewBox="0 0 360 74"
          className="w-full h-auto"
          role="img"
          aria-label="Nonlinear drawdown recovery cliff"
        >
          <polyline
            fill="none"
            stroke="#EF4444"
            strokeWidth={2}
            points="20,60 90,56 160,48 230,32 300,10"
          />
          <circle cx={90} cy={56} r={3} fill="#10B981" />
          <text x={70} y={48} fill="#10B981" fontSize="8" fontFamily="monospace">
            -10% → +11%
          </text>
          <circle cx={230} cy={32} r={3} fill="#F59E0B" />
          <text x={185} y={24} fill="#F59E0B" fontSize="8" fontFamily="monospace">
            -50% → +100%
          </text>
          <circle cx={300} cy={10} r={3.5} fill="#EF4444" />
          <text x={275} y={26} fill="#EF4444" fontSize="8" fontFamily="monospace">
            -80% → +400%
          </text>
        </svg>
      );
    case 'ORDER_TYPES':
      return (
        <svg
          viewBox="0 0 360 74"
          className="w-full h-auto"
          role="img"
          aria-label="Limit vs Stop order geometry"
        >
          <polyline
            fill="none"
            stroke="#10B981"
            strokeWidth={2}
            points="20,58 75,34 115,52 175,16"
          />
          <circle cx={115} cy={52} r={4} fill="#D4AF37" />
          <text x={35} y={68} fill="#D4AF37" fontSize="9" fontFamily="monospace">
            BUY LIMIT (Pullback Entry)
          </text>
          <line x1={205} x2={340} y1={28} y2={28} stroke="#A882DD" strokeDasharray="3 3" />
          <circle cx={275} cy={28} r={4} fill="#A882DD" />
          <text x={212} y={48} fill="#A882DD" fontSize="9" fontFamily="monospace">
            BUY STOP (Breakout Entry)
          </text>
        </svg>
      );
    case 'EQUITY_VS_BALANCE':
    default:
      return (
        <svg
          viewBox="0 0 360 74"
          className="w-full h-auto"
          role="img"
          aria-label="Equity vs Balance divergence"
        >
          <polyline
            fill="none"
            stroke="#D4AF37"
            strokeWidth={2}
            points="20,54 120,42 220,30 330,18"
          />
          <polyline
            fill="none"
            stroke="#EF4444"
            strokeWidth={2}
            strokeDasharray="4 3"
            points="20,54 120,48 220,58 330,66"
          />
          <text x={24} y={24} fill="#D4AF37" fontSize="9" fontFamily="monospace">
            GOLD = CLOSED BALANCE
          </text>
          <text x={180} y={68} fill="#EF4444" fontSize="9" fontFamily="monospace">
            RED = FLOATING EQUITY DIVERGENCE
          </text>
        </svg>
      );
  }
}

export function DictionaryExplorer() {
  const { isId, l } = useLocale();
  const [query, setQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<DictionaryCategory | 'ALL'>('ALL');
  const [selectedDifficulty, setSelectedDifficulty] = useState<
    'ALL' | 'BEGINNER' | 'INTERMEDIATE' | 'QUANT'
  >('ALL');

  const filteredTerms = useMemo(() => {
    const q = query.trim().toLowerCase();
    return DICTIONARY_TERMS.filter((item) => {
      if (selectedCategory !== 'ALL' && item.category !== selectedCategory) return false;
      if (selectedDifficulty !== 'ALL' && item.difficulty !== selectedDifficulty) return false;
      if (!q) return true;
      return (
        item.term.toLowerCase().includes(q) ||
        item.slug.toLowerCase().includes(q) ||
        item.plainEnglish.toLowerCase().includes(q) ||
        item.technicalDefinition.toLowerCase().includes(q) ||
        item.centAccountExample.toLowerCase().includes(q)
      );
    });
  }, [query, selectedCategory, selectedDifficulty]);

  function handleSelectRelatedTerm(slug: string) {
    const target = DICTIONARY_TERMS.find((t) => t.slug === slug);
    setSelectedCategory('ALL');
    setSelectedDifficulty('ALL');
    setQuery(target ? target.term : slug);
  }

  function handleReset() {
    setQuery('');
    setSelectedCategory('ALL');
    setSelectedDifficulty('ALL');
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Header */}
      <div className="jgs-panel p-6 sm:p-8 space-y-4">
        <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#D4AF37]">
          <BookOpen className="w-4 h-4" />
          <span>
            {isId
              ? 'KAMUS TRADING JEY • ISTILAH TRADING & KUANTITATIF INTERAKTIF'
              : "JEY'S DICTIONARY • INTERACTIVE TRADING & QUANT TERMINOLOGY"}
          </span>
        </div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#F7F4EE]">
          {isId
            ? 'Penjelasan Sederhana, Ilustrasi Visual & Keterkaitan Istilah'
            : 'Simple Explanations, Visual Illustrations & Connected Terms'}
        </h1>
        <p className="text-sm sm:text-base text-[#BEB6CE] max-w-3xl leading-relaxed">
          {isId
            ? 'Setiap istilah dilengkapi: (1) Penjelasan Bahasa Sederhana, (2) Ilustrasi Skema Visual, (3) Definisi Teknis MT5, (4) Contoh Nyata Akun Cent $50 (5.000 USC), (5) Kesalahan Umum Ritel, dan tautan Istilah Terkait.'
            : 'Every term includes: (1) Plain-Language Explanation, (2) Visual Schematic Illustration, (3) Technical MT5 Definition, (4) A Concrete $50 (5,000 USC) Cent Account Example, (5) Common Retail Pitfalls, and clickable Related Terminology links.'}
        </p>

        {/* Search Input & Difficulty Filters */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 pt-2">
          <div className="lg:col-span-7 relative">
            <Search className="w-4 h-4 text-[#D4AF37] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder={
                isId
                  ? 'Cari istilah (misal: Cent Account, USC, Pip, Point, Spread, Martingale, R-Multiple)...'
                  : 'Search terminology (e.g. Cent Account, USC, Pip, Point, Spread, Martingale, R-Multiple)...'
              }
              className="jgs-input pl-10 font-sans"
              aria-label={isId ? 'Cari kamus trading' : 'Search trading dictionary'}
            />
          </div>

          <div className="lg:col-span-5 flex flex-wrap items-center gap-2">
            {(['ALL', 'BEGINNER', 'INTERMEDIATE', 'QUANT'] as const).map((diff) => (
              <button
                key={diff}
                type="button"
                onClick={() => setSelectedDifficulty(diff)}
                className={`px-3.5 py-2 rounded-lg text-xs font-medium transition-all ${
                  selectedDifficulty === diff
                    ? 'bg-[#D4AF37] text-[#08050E] font-bold'
                    : 'bg-[#08050E] border border-white/10 text-[#BEB6CE] hover:text-[#F7F4EE]'
                }`}
              >
                {diff === 'ALL'
                  ? isId
                    ? 'Semua Level'
                    : 'All Levels'
                  : diff === 'BEGINNER'
                  ? isId
                    ? 'Pemula'
                    : 'Beginner'
                  : diff === 'INTERMEDIATE'
                  ? isId
                    ? 'Menengah'
                    : 'Intermediate'
                  : isId
                  ? 'Sistem / Quant'
                  : 'Quant'}
              </button>
            ))}
          </div>
        </div>

        {/* Category Filter Pills */}
        <div className="flex flex-wrap items-center gap-2 pt-2">
          <button
            type="button"
            onClick={() => setSelectedCategory('ALL')}
            className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
              selectedCategory === 'ALL'
                ? 'bg-[#A882DD]/25 border border-[#A882DD] text-[#F7F4EE]'
                : 'bg-[#08050E] border border-white/10 text-[#BEB6CE] hover:text-[#F7F4EE]'
            }`}
          >
            {isId ? `Semua Kategori (${DICTIONARY_TERMS.length})` : `All Categories (${DICTIONARY_TERMS.length})`}
          </button>
          {(Object.keys(DICTIONARY_CATEGORY_LABELS) as DictionaryCategory[]).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                selectedCategory === cat
                  ? 'bg-[#A882DD]/25 border border-[#A882DD] text-[#F7F4EE]'
                  : 'bg-[#08050E] border border-white/10 text-[#BEB6CE] hover:text-[#F7F4EE]'
              }`}
            >
              {DICTIONARY_CATEGORY_LABELS[cat]}
            </button>
          ))}
        </div>
      </div>

      {/* Results Count & Filter Reset */}
      <div className="flex items-center justify-between text-xs font-medium text-[#BEB6CE]">
        <span>
          {isId ? 'Menampilkan ' : 'Showing '}
          <strong className="text-[#D4AF37]">{filteredTerms.length}</strong>{' '}
          {isId ? `dari ${DICTIONARY_TERMS.length} istilah` : `of ${DICTIONARY_TERMS.length} illustrated terms`}
        </span>
        {(query || selectedCategory !== 'ALL' || selectedDifficulty !== 'ALL') && (
          <button
            type="button"
            onClick={handleReset}
            className="inline-flex items-center gap-1 text-[#D4AF37] hover:underline"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{isId ? 'Reset Filter Kamus' : 'Reset Dictionary Filters'}</span>
          </button>
        )}
      </div>

      {/* Empty State */}
      {filteredTerms.length === 0 ? (
        <div className="jgs-panel p-12 text-center space-y-4">
          <BookOpen className="w-10 h-10 text-[#D4AF37] mx-auto opacity-80" />
          <h2 className="font-display text-xl font-bold text-[#F7F4EE]">
            {isId
              ? `Tidak Ada Istilah yang Cocok dengan "${query}"`
              : `No Trading Terms Matched "${query}"`}
          </h2>
          <p className="text-sm text-[#BEB6CE] max-w-md mx-auto">
            {isId
              ? 'Coba gunakan kata kunci yang lebih umum (seperti "Lot", "Stop", "Cent", "Spread", atau "EA") atau reset filter kategori.'
              : 'Try searching for a broader keyword (such as "Lot", "Stop", "Cent", "Spread", or "EA") or reset your category filter.'}
          </p>
          <button type="button" onClick={handleReset} className="jgs-btn-gold text-xs">
            {isId
              ? `Tampilkan Semua ${DICTIONARY_TERMS.length} Istilah`
              : `Show All ${DICTIONARY_TERMS.length} Terms`}
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {filteredTerms.map((item) => (
            <div
              key={item.slug}
              className="jgs-panel p-6 flex flex-col justify-between space-y-5"
            >
              <div className="space-y-4">
                {/* Term Header */}
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
                  <h2 className="font-display text-xl font-bold text-[#F7F4EE]">{item.term}</h2>
                  <div className="flex items-center gap-2">
                    <span className="text-xs px-2.5 py-0.5 rounded bg-[#191129] border border-white/10 text-[#BEB6CE]">
                      {DICTIONARY_CATEGORY_LABELS[item.category]}
                    </span>
                    <span className="text-xs font-semibold px-2.5 py-0.5 rounded bg-[#D4AF37]/15 border border-[#D4AF37]/30 text-[#D4AF37]">
                      {item.difficulty}
                    </span>
                  </div>
                </div>

                {/* Visual Schematic Illustration */}
                <div className="rounded-xl bg-[#08050E] border border-white/10 p-2.5">
                  <TermIllustrationSVG type={item.illustrationType} />
                </div>

                {/* 1. Plain-Language Translation */}
                <div className="space-y-1">
                  <div className="text-xs text-[#D4AF37] font-semibold">
                    {isId ? '1. Penjelasan Bahasa Sederhana' : '1. Simple Plain-Language Explanation'}
                  </div>
                  <p className="text-sm text-[#F7F4EE] leading-relaxed font-medium">
                    {item.plainEnglish}
                  </p>
                </div>

                {/* 2. Technical Definition */}
                <div className="space-y-1">
                  <div className="text-xs text-[#A882DD] font-semibold flex items-center gap-1">
                    <Cpu className="w-3.5 h-3.5" />
                    <span>
                      {isId ? '2. Spesifikasi Teknis & MT5' : '2. Technical & MT5 Specification'}
                    </span>
                  </div>
                  <p className="text-xs sm:text-sm text-[#BEB6CE] leading-relaxed">
                    {item.technicalDefinition}
                  </p>
                </div>

                {/* 3. $50 Cent Account Example */}
                <div className="p-3.5 rounded-xl bg-[#0F1B1D] border border-[#10B981]/30 space-y-1">
                  <div className="text-xs text-[#10B981] font-semibold flex items-center gap-1">
                    <Coins className="w-3.5 h-3.5" />
                    <span>
                      {isId
                        ? '3. Contoh Penerapan pada Saldo $50 (5.000 USC)'
                        : '3. Concrete $50 (5,000 USC) Cent Example'}
                    </span>
                  </div>
                  <p className="text-xs text-[#F7F4EE] leading-relaxed">
                    {item.centAccountExample}
                  </p>
                </div>

                {/* 4. Retail Trap */}
                <div className="p-3.5 rounded-xl bg-[#1A0D16] border border-[#EF4444]/30 space-y-1">
                  <div className="text-xs text-[#EF4444] font-semibold flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    <span>{isId ? '4. Kesalahan Umum Trader' : '4. Common Retail Pitfall'}</span>
                  </div>
                  <p className="text-xs text-[#F7F4EE]/90 leading-relaxed">{item.retailTrap}</p>
                </div>

                {/* 5. Related Terminology Links */}
                {item.relatedTerms.length > 0 && (
                  <div className="pt-1 space-y-1.5">
                    <div className="text-xs text-[#BEB6CE] flex items-center gap-1">
                      <Link2 className="w-3.5 h-3.5 text-[#D4AF37]" />
                      <span>
                        {isId
                          ? 'Istilah Terkait (Klik untuk melihat):'
                          : 'Related Terminology (Click to inspect):'}
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {item.relatedTerms.map((relSlug) => {
                        const relObj = DICTIONARY_TERMS.find((t) => t.slug === relSlug);
                        return (
                          <button
                            key={relSlug}
                            type="button"
                            onClick={() => handleSelectRelatedTerm(relSlug)}
                            className="px-2.5 py-1 rounded bg-[#08050E] border border-[#D4AF37]/25 text-xs text-[#F3E5AB] hover:border-[#D4AF37] transition-colors"
                          >
                            {relObj ? relObj.term : relSlug}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {item.calculatorLink && (
                <div className="pt-3 border-t border-white/10 flex justify-end">
                  <Link
                    href={l(item.calculatorLink)}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[#D4AF37] hover:underline"
                  >
                    <span>{isId ? 'Buka Lab Interaktif' : 'Open Interactive Lab'}</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </Link>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
