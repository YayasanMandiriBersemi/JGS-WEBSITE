'use client';

import React, { useState, useEffect } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import {
  loadStrategistSession,
  saveStrategistSession,
  loadOnboardingDossier,
  loadCompletedLessonSlugs,
  loadRiskPresets,
  loadJournalEntries,
  StrategistUserSession,
  OnboardingDossier,
  SavedRiskRulePreset,
} from '@/lib/storage/jgs-local-store';
import { ACADEMY_LESSONS } from '@/lib/data/academy-lessons';
import { JeyStrategistCallout } from '@/components/brand/JeyStrategistCallout';
import { useLocale } from '@/i18n/LocaleContext';
import {
  UserCheck,
  LogOut,
  Database,
  Compass,
  BookOpen,
  Calculator,
  NotebookPen,
  Crown,
  Lock,
  ArrowRight,
  AlertTriangle,
  ShieldCheck,
  Users,
} from 'lucide-react';

export function CommunityView() {
  const { isId, l } = useLocale();

  const charterArticles = isId
    ? [
        {
          code: 'PASAL 01',
          title: 'Mengukur Keberhasilan dalam R-Multiple, Bukan Pamer Nominal Uang',
          detail:
            'Baik menggunakan Akun Cent 2.500 USC ($25) maupun akun $25.000, diskusi dan evaluasi di komunitas JGS selalu menggunakan satuan R-Multiple (+2,2R, -1,0R) dan persentase risiko.',
        },
        {
          code: 'PASAL 02',
          title: 'Wajib Menggunakan Stop-Loss yang Terdefinisi',
          detail:
            'Setiap transaksi manual maupun algoritmik yang didiskusikan wajib memiliki titik invalidasi struktural (Stop-Loss) dan perhitungan ukuran lot sebelum entry.',
        },
        {
          code: 'PASAL 03',
          title: 'Disiplin Batas Kerugian Harian (Daily Circuit Breaker)',
          detail:
            'Ketika mencapai batas kerugian harian atau mengalami kekalahan berturut-turut sesuai rencana, protokol kami adalah menutup platform, mencatat jurnal, dan beristirahat hingga hari berikutnya.',
        },
        {
          code: 'PASAL 04',
          title: 'Kejujuran Data Tanpa Janji Profit Pasti',
          detail:
            'Tidak ada anggota atau pengajar yang boleh menjanjikan keuntungan pasti atau mempromosikan bot Martingale tanpa batas. Kerugian dicatat setransparan kemenangan.',
        },
      ]
    : [
        {
          code: 'ARTICLE 01',
          title: 'We Measure in R-Multiples, Never Ego Dollars',
          detail:
            'Whether trading a 2,500 USC ($25) Cent Account or a $25,000 account, setups are evaluated in R-Multiples (+2.2R, -1.0R) and Risk %.',
        },
        {
          code: 'ARTICLE 02',
          title: 'Defined Stop Losses on Every Position',
          detail:
            'Every manual or algorithmic trade discussed must define its structural invalidation point (Stop Loss) and verified lot size before entry.',
        },
        {
          code: 'ARTICLE 03',
          title: 'Respecting Daily Circuit Breakers',
          detail:
            'When a trader hits their planned daily loss limit, protocol is to close MT5, log the journal, and step away until the next trading session.',
        },
        {
          code: 'ARTICLE 04',
          title: 'Anti-Hype Data Honesty',
          detail:
            'No member or educator may promise guaranteed returns or promote uncapped Martingale grid bots. Losses are documented with the same transparency as wins.',
        },
      ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-10">
      <div className="jgs-panel p-6 sm:p-8 space-y-4">
        <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D4AF37]">
          <Users className="w-4 h-4" />
          <span>
            {isId
              ? 'KOMUNITAS JGS & PIAGAM DISIPLIN RISIKO'
              : 'JGS COMMUNITY & RISK DISCIPLINE CHARTER'}
          </span>
        </div>
        <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#F7F4EE]">
          {isId
            ? 'Budaya Disiplin Kuantitatif, Bukan Grup Sinyal Hype'
            : 'A Culture of Quantitative Discipline, Not Signal Hype'}
        </h1>
        <p className="text-sm sm:text-base text-[#B8B0C8] max-w-3xl leading-relaxed">
          {isId
            ? 'Komunitas THE JEY GANG STRATEGIST dibangun untuk trader yang memperlakukan modal $25 dengan disiplin dan ketelitian matematika yang sama seriusnya dengan portofolio besar.'
            : 'THE JEY GANG STRATEGIST community is built for traders who treat a $25 balance with the same respect and mathematical rigor as a large portfolio.'}
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {charterArticles.map((item) => (
          <div key={item.code} className="jgs-panel p-6 space-y-3">
            <div className="flex items-center justify-between text-xs font-mono">
              <span className="text-[#D4AF37] font-bold">{item.code}</span>
              <ShieldCheck className="w-4 h-4 text-[#10B981]" />
            </div>
            <h2 className="font-display text-xl font-bold text-[#F7F4EE]">{item.title}</h2>
            <p className="text-sm text-[#B8B0C8] leading-relaxed">{item.detail}</p>
          </div>
        ))}
      </div>

      <JeyStrategistCallout
        ruleText={
          isId
            ? 'Di JGS, kami jauh lebih menghargai trader yang berhenti sesuai batas kerugian hariannya daripada spekulan yang mempertaruhkan seluruh saldo akunnya dalam satu berita.'
            : 'At JGS, we respect a trader who stops at their planned daily loss limit far more than a gambler who risks their entire account on a single news candle.'
        }
        contextTag={isId ? 'BUDAYA KOMUNITAS' : 'COMMUNITY CULTURE'}
      />

      <div className="jgs-panel p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div className="space-y-1">
          <div className="text-xs text-[#D4AF37] font-semibold flex items-center gap-1.5">
            <Crown className="w-3.5 h-3.5" />
            <span>
              {isId ? 'MULAI BANGUN REKAM JEJAK DISIPLIN ANDA' : 'START BUILDING YOUR DISCIPLINE'}
            </span>
          </div>
          <h3 className="font-display text-xl font-bold text-[#F7F4EE]">
            {isId
              ? 'Selesaikan Panduan Awal & Catat Evaluasi Transaksi di Jurnal Gratis'
              : 'Complete Your Onboarding Roadmap & Log Your Trades in the Free Journal'}
          </h3>
        </div>
        <div className="flex flex-wrap gap-3">
          <Link href={l('/onboarding')} className="jgs-btn-gold text-xs">
            <span>{isId ? 'Panduan Awal Jey' : 'Start Onboarding'}</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </Link>
          <Link href={l('/journal')} className="jgs-btn-outline text-xs">
            <BookOpen className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isId ? 'Buka Jurnal Trader' : 'Open Trader Journal'}</span>
          </Link>
        </div>
      </div>
    </div>
  );
}

export function AccountView() {
  const { isId, l } = useLocale();
  const [session, setSession] = useState<StrategistUserSession | null>(null);
  const [dossier, setDossier] = useState<OnboardingDossier | null>(null);
  const [completedLessons, setCompletedLessons] = useState<string[]>([]);
  const [presets, setPresets] = useState<SavedRiskRulePreset[]>([]);
  const [journalCount, setJournalCount] = useState<number>(0);

  useEffect(() => {
    setSession(loadStrategistSession());
    setDossier(loadOnboardingDossier());
    setCompletedLessons(loadCompletedLessonSlugs());
    setPresets(loadRiskPresets());
    setJournalCount(loadJournalEntries().length);
  }, []);

  function handleSignOut() {
    saveStrategistSession(null);
    setSession(null);
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      <div className="jgs-panel p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-2xl overflow-hidden border border-[#D4AF37] bg-[#A882DD]/20">
            <img
              src="/images/jey-mascot.png"
              alt="Strategist Avatar"
              width={56}
              height={56}
              decoding="async"
              className="w-full h-full object-cover object-top"
            />
          </div>
          <div>
            <span className="text-xs text-[#D4AF37] font-semibold flex items-center gap-1.5">
              <UserCheck className="w-3.5 h-3.5" />
              {session
                ? isId
                  ? 'PROFIL PENGGUNA LOKAL AKTIF'
                  : 'LOCAL STRATEGIST PROFILE ACTIVE'
                : isId
                ? 'RUANG KERJA TAMU LOKAL (TANPA WAJIB LOGIN)'
                : 'LOCAL GUEST WORKSPACE (NO LOGIN REQUIRED)'}
            </span>
            <h1 className="font-display text-2xl sm:text-3xl font-bold text-[#F7F4EE]">
              {session
                ? session.displayName
                : isId
                ? 'Profil Tamu JGS'
                : 'Guest Strategist Profile'}
            </h1>
            <p className="text-xs text-[#B8B0C8]">
              {session
                ? `${session.email} • Role: ${session.role}`
                : isId
                ? 'Seluruh edukasi & kalkulator aktif 100% gratis tanpa paksaan registrasi'
                : 'All education & calculators active 100% free with no forced registration'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          {session ? (
            <button
              type="button"
              onClick={handleSignOut}
              className="jgs-btn-outline text-xs py-2 px-4"
            >
              <LogOut className="w-3.5 h-3.5 text-[#EF4444]" />
              <span>{isId ? 'Keluar' : 'Sign Out'}</span>
            </button>
          ) : (
            <Link href={l('/login')} className="jgs-btn-gold text-xs py-2.5 px-5">
              <span>{isId ? 'Simpan Profil Lokal (Opsional)' : 'Optional Profile Sign-In'}</span>
            </Link>
          )}
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
        <Link href={l('/onboarding')} className="jgs-panel-interactive p-5 space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-[#D4AF37]">
            <span>{isId ? 'PETA BELAJAR' : 'ONBOARDING PLAN'}</span>
            <Compass className="w-4 h-4" />
          </div>
          <div className="font-display text-xl font-bold text-[#F7F4EE]">
            {dossier
              ? `${dossier.recommendedCapitalUsc.toLocaleString()} USC`
              : isId
              ? 'Belum Diatur'
              : 'Not Configured'}
          </div>
          <p className="text-xs text-[#B8B0C8]">
            {dossier
              ? `${isId ? 'Risiko' : 'Risk'}: ${dossier.recommendedRiskPercent}% • ${
                  dossier.primaryInstrument
                }`
              : isId
              ? 'Klik untuk menyusun rencana belajar'
              : 'Click to complete the 4-step guide'}
          </p>
        </Link>

        <Link href={l('/academy')} className="jgs-panel-interactive p-5 space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-[#10B981]">
            <span>{isId ? 'PROGRES ACADEMY' : 'ACADEMY PROGRESS'}</span>
            <BookOpen className="w-4 h-4" />
          </div>
          <div className="font-display text-xl font-bold text-[#F7F4EE]">
            {completedLessons.length} / {ACADEMY_LESSONS.length}{' '}
            {isId ? 'Modul' : 'Modules'}
          </div>
          <p className="text-xs text-[#B8B0C8]">
            {Math.round((completedLessons.length / ACADEMY_LESSONS.length) * 100)}%{' '}
            {isId ? 'kurikulum selesai' : 'curriculum completed'}
          </p>
        </Link>

        <Link href={l('/calculators/cent')} className="jgs-panel-interactive p-5 space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-[#A882DD]">
            <span>{isId ? 'PRESET KALKULATOR' : 'SAVED RISK PRESETS'}</span>
            <Calculator className="w-4 h-4" />
          </div>
          <div className="font-display text-xl font-bold text-[#F7F4EE]">
            {presets.length} {isId ? 'Tersimpan' : 'Saved'}
          </div>
          <p className="text-xs text-[#B8B0C8]">
            {isId ? 'Konfigurasi ukuran lot di Cent Lab' : 'Saved Cent Lab sizing configurations'}
          </p>
        </Link>

        <Link href={l('/journal')} className="jgs-panel-interactive p-5 space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-[#F3E5AB]">
            <span>{isId ? 'CATATAN JURNAL' : 'JOURNAL ENTRIES'}</span>
            <NotebookPen className="w-4 h-4" />
          </div>
          <div className="font-display text-xl font-bold text-[#F7F4EE]">
            {journalCount} {isId ? 'Transaksi' : 'Trades'}
          </div>
          <p className="text-xs text-[#B8B0C8]">
            {isId
              ? 'Catatan disiplin & ekspektasi R'
              : 'Logged in your local Trader Journal'}
          </p>
        </Link>
      </div>

      <div className="jgs-panel p-6 space-y-3">
        <div className="flex items-center gap-2 text-xs font-semibold text-[#D4AF37]">
          <Database className="w-4 h-4" />
          <span>
            {isId
              ? 'ARSITEKTUR PENYIMPANAN LOKAL & PRIVASI'
              : 'LOCAL-FIRST STORAGE & PRIVACY ARCHITECTURE'}
          </span>
        </div>
        <p className="text-xs sm:text-sm text-[#B8B0C8] leading-relaxed">
          {isId
            ? 'Progres belajar Academy, preset kalkulator, dan catatan Jurnal Trader Anda disimpan secara langsung di browser perangkat Anda (localStorage) sehingga Anda dapat menggunakan seluruh fitur JGS secara instan tanpa kewajiban membuat akun.'
            : 'Your Academy progress, calculator presets, and Trader Journal entries are stored locally in your browser (localStorage) so you can use every JGS feature immediately with zero registration barriers.'}
        </p>
      </div>
    </div>
  );
}

export function LoginView() {
  const { isId, l } = useLocale();
  const router = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  function handleSignIn(e: React.FormEvent) {
    e.preventDefault();
    setErrorMessage(null);
    const cleanEmail = email.trim();
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setErrorMessage(
        isId
          ? 'Masukkan alamat email yang valid (contoh: trader@example.com).'
          : 'Please enter a valid email address (e.g. strategist@example.com).'
      );
      return;
    }
    if (password.length < 8) {
      setErrorMessage(
        isId
          ? 'Kata sandi harus terdiri dari minimal 8 karakter.'
          : 'Passphrase must be at least 8 characters long.'
      );
      return;
    }

    const nameFromEmail = cleanEmail.split('@')[0].replace(/[^a-zA-Z0-9]/g, ' ');
    saveStrategistSession({
      id: `usr-${Date.now()}`,
      email: cleanEmail,
      displayName: nameFromEmail.charAt(0).toUpperCase() + nameFromEmail.slice(1),
      role: 'STRATEGIST',
      signedInAt: new Date().toISOString(),
    });
    router.push(l('/account'));
  }

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="jgs-panel p-6 sm:p-8 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl overflow-hidden border border-[#D4AF37] bg-[#A882DD]/20">
            <img
              src="/images/jey-mascot.png"
              alt="Jey Mascot"
              width={48}
              height={48}
              decoding="async"
              className="w-full h-full object-cover object-top"
            />
          </div>
          <div>
            <div className="text-xs text-[#D4AF37] font-semibold flex items-center gap-1">
              <Crown className="w-3.5 h-3.5" />
              <span>{isId ? 'PROFIL LOKAL OPSIONAL' : 'OPTIONAL LOCAL PROFILE'}</span>
            </div>
            <h1 className="font-display text-2xl font-bold text-[#F7F4EE]">
              {isId ? 'Masuk ke Profil JGS' : 'Sign In to JGS'}
            </h1>
          </div>
        </div>

        <p className="text-xs text-[#B8B0C8] leading-relaxed">
          {isId
            ? 'Seluruh edukasi dan kalkulator JGS dapat diakses gratis tanpa login. Masuk di sini hanya jika Anda ingin menyematkan nama profil pada ruang kerja lokal Anda.'
            : 'All JGS education and calculators are free without login. Sign in here only if you wish to personalize your local workspace profile.'}
        </p>

        <div className="p-3 rounded-xl bg-[#09060F] border border-white/10 text-xs text-[#B8B0C8] flex items-start gap-2">
          <ShieldCheck className="w-4 h-4 text-[#10B981] shrink-0 mt-0.5" />
          <span>
            {isId
              ? 'Mode Privasi Lokal: Identitas profil disimpan di browser perangkat Anda. Kata sandi tidak pernah disimpan dalam teks biasa.'
              : 'Local-First Privacy Mode: Your profile badge is stored in your browser. Passphrases are never saved in localStorage.'}
          </span>
        </div>

        {errorMessage && (
          <div
            role="alert"
            className="p-3 rounded-xl bg-[#1A0D16] border border-[#EF4444] text-xs text-[#EF4444] flex items-start gap-2"
          >
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleSignIn} className="space-y-4">
          <div>
            <label htmlFor="login-email" className="jgs-label">
              Email
            </label>
            <input
              id="login-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="strategist@example.com"
              className="jgs-input"
            />
          </div>

          <div>
            <label htmlFor="login-password" className="jgs-label">
              {isId ? 'Kata Sandi (Min. 8 Karakter)' : 'Passphrase (Min. 8 Characters)'}
            </label>
            <input
              id="login-password"
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="jgs-input"
            />
          </div>

          <button type="submit" className="jgs-btn-gold w-full py-3 text-sm">
            <Lock className="w-4 h-4" />
            <span>{isId ? 'Aktifkan Profil Lokal' : 'Activate Local Profile'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-[#B8B0C8]">
          <span>{isId ? 'Belum punya profil?' : 'New to the platform?'}</span>
          <Link href={l('/register')} className="text-[#D4AF37] hover:underline font-semibold">
            {isId ? 'Buat Profil Lokal →' : 'Create Local Profile →'}
          </Link>
        </div>
      </div>
    </div>
  );
}

export function RegisterView() {
  const { isId, l } = useLocale();
  const router = useRouter();
  const [displayName, setDisplayName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  function handleRegister(e: React.FormEvent) {
    e.preventDefault();
    setErrorMessage(null);
    const cleanName = displayName.trim();
    const cleanEmail = email.trim();

    if (cleanName.length < 2) {
      setErrorMessage(
        isId ? 'Nama tampilan minimal 2 karakter.' : 'Display name must be at least 2 characters.'
      );
      return;
    }
    if (!cleanEmail || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(cleanEmail)) {
      setErrorMessage(
        isId ? 'Masukkan alamat email yang valid.' : 'Please enter a valid email address.'
      );
      return;
    }
    if (password.length < 8) {
      setErrorMessage(
        isId
          ? 'Kata sandi harus terdiri dari minimal 8 karakter.'
          : 'Passphrase must be at least 8 characters.'
      );
      return;
    }

    saveStrategistSession({
      id: `usr-${Date.now()}`,
      email: cleanEmail,
      displayName: cleanName,
      role: 'STRATEGIST',
      signedInAt: new Date().toISOString(),
    });
    router.push(l('/account'));
  }

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="jgs-panel p-6 sm:p-8 space-y-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-xl overflow-hidden border border-[#D4AF37] bg-[#A882DD]/20">
            <img
              src="/images/jey-mascot.png"
              alt="Jey Mascot"
              width={48}
              height={48}
              decoding="async"
              className="w-full h-full object-cover object-top"
            />
          </div>
          <div>
            <div className="text-xs text-[#D4AF37] font-semibold flex items-center gap-1">
              <Crown className="w-3.5 h-3.5" />
              <span>{isId ? 'REGISTRASI PROFIL OPSIONAL' : 'OPTIONAL PROFILE SETUP'}</span>
            </div>
            <h1 className="font-display text-2xl font-bold text-[#F7F4EE]">
              {isId ? 'Buat Profil Belajar Lokal' : 'Create Local Profile'}
            </h1>
          </div>
        </div>

        {errorMessage && (
          <div
            role="alert"
            className="p-3 rounded-xl bg-[#1A0D16] border border-[#EF4444] text-xs text-[#EF4444] flex items-start gap-2"
          >
            <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-4">
          <div>
            <label htmlFor="reg-name" className="jgs-label">
              {isId ? 'Nama Tampilan / Alias' : 'Display Name / Alias'}
            </label>
            <input
              id="reg-name"
              type="text"
              required
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="Jey Strategist"
              className="jgs-input"
            />
          </div>

          <div>
            <label htmlFor="reg-email" className="jgs-label">
              Email
            </label>
            <input
              id="reg-email"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="strategist@example.com"
              className="jgs-input"
            />
          </div>

          <div>
            <label htmlFor="reg-pass" className="jgs-label">
              {isId ? 'Kata Sandi (Min. 8 Karakter)' : 'Passphrase (Min. 8 Characters)'}
            </label>
            <input
              id="reg-pass"
              type="password"
              required
              minLength={8}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="jgs-input"
            />
          </div>

          <button type="submit" className="jgs-btn-gold w-full py-3 text-sm">
            <span>{isId ? 'Simpan Profil Lokal' : 'Save Local Profile'}</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </form>

        <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs text-[#B8B0C8]">
          <span>{isId ? 'Sudah punya profil?' : 'Already have a profile?'}</span>
          <Link href={l('/login')} className="text-[#D4AF37] hover:underline font-semibold">
            {isId ? 'Masuk →' : 'Sign In →'}
          </Link>
        </div>
      </div>
    </div>
  );
}
