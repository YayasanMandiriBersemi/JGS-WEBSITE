'use client';

import React, { useState, useEffect, useMemo } from 'react';
import Link from 'next/link';
import {
  TradeJournalItem,
  JournalAccountMode,
  JournalDirection,
  JournalEmotion,
  computeTradeRMultiple,
  computeJournalAnalytics
} from '@/lib/math/journal-analytics';
import {
  loadJournalEntries,
  saveJournalEntries,
  loadCompletedLessonSlugs,
  EDUCATIONAL_SAMPLE_JOURNAL_ENTRIES
} from '@/lib/storage/jgs-local-store';
import { ACADEMY_LESSONS } from '@/lib/data/academy-lessons';
import { JeyStrategistCallout } from '@/components/brand/JeyStrategistCallout';
import { useLocale } from '@/i18n/LocaleContext';
import {
  NotebookPen,
  PlusCircle,
  Download,
  Trash2,
  Database,
  CheckCircle2,
  AlertTriangle,
  GraduationCap,
  Search,
  RotateCcw,
  ArrowRight,
  HeartPulse,
  ShieldCheck
} from 'lucide-react';

export function TraderJournalWorkspace() {
  const { isId, l } = useLocale();
  const [entries, setEntries] = useState<TradeJournalItem[]>([]);
  const [completedSlugs, setCompletedSlugs] = useState<string[]>([]);
  const [isHydrated, setIsHydrated] = useState<boolean>(false);

  // Form State
  const [instrument, setInstrument] = useState('XAUUSD');
  const [accountMode, setAccountMode] = useState<JournalAccountMode>('CENT_USC');
  const [direction, setDirection] = useState<JournalDirection>('LONG');
  const [entryPrice, setEntryPrice] = useState<number>(2650.0);
  const [stopLoss, setStopLoss] = useState<number>(2647.5);
  const [takeProfit, setTakeProfit] = useState<number>(2655.0);
  const [exitPrice, setExitPrice] = useState<number>(2655.0);
  const [lotSize, setLotSize] = useState<number>(0.1);
  const [realizedPnl, setRealizedPnl] = useState<number>(50.0);
  const [setupTag, setSetupTag] = useState('London Liquidity Sweep Reclaim');
  const [emotionTag, setEmotionTag] = useState<JournalEmotion>('DISCIPLINED');
  const [ruleFollowedStopLoss, setRuleFollowedStopLoss] = useState(true);
  const [ruleProperLotSize, setRuleProperLotSize] = useState(true);
  const [ruleWaitedConfirmation, setRuleWaitedConfirmation] = useState(true);
  const [ruleWithinDailyLimit, setRuleWithinDailyLimit] = useState(true);
  const [notes, setNotes] = useState('');

  // Validation & Feedback State
  const [validationError, setValidationError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Ledger Filter State
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [emotionFilter, setEmotionFilter] = useState<'ALL' | JournalEmotion>('ALL');

  useEffect(() => {
    const stored = loadJournalEntries();
    if (stored.length > 0) {
      setEntries(stored);
    } else {
      setEntries(EDUCATIONAL_SAMPLE_JOURNAL_ENTRIES);
    }
    setCompletedSlugs(loadCompletedLessonSlugs());
    setIsHydrated(true);
  }, []);

  const previewRMultiple = useMemo(
    () => computeTradeRMultiple(direction, entryPrice, stopLoss, exitPrice),
    [direction, entryPrice, stopLoss, exitPrice]
  );

  const stats = useMemo(() => computeJournalAnalytics(entries), [entries]);

  const filteredEntries = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return entries.filter((item) => {
      const matchesEmotion = emotionFilter === 'ALL' || item.emotionTag === emotionFilter;
      const matchesQuery =
        q.length === 0 ||
        item.instrument.toLowerCase().includes(q) ||
        item.setupTag.toLowerCase().includes(q) ||
        item.notes.toLowerCase().includes(q) ||
        item.emotionTag.toLowerCase().includes(q);
      return matchesEmotion && matchesQuery;
    });
  }, [entries, searchQuery, emotionFilter]);

  // Learning Progress & Recommended Lessons based on Journal Audit
  const academyProgressPercent = Math.round(
    (completedSlugs.length / ACADEMY_LESSONS.length) * 100
  );

  const recommendedLessons = useMemo(() => {
    const hasLotSizeViolation = entries.some((e) => !e.ruleProperLotSize);
    const hasStopLossViolation = entries.some((e) => !e.ruleFollowedStopLoss);
    const hasEmotionalLeak = entries.some(
      (e) => e.emotionTag === 'FOMO' || e.emotionTag === 'REVENGE'
    );

    const prioritySlugs: string[] = [];
    if (hasLotSizeViolation) prioritySlugs.push('how-cent-accounts-work');
    if (hasStopLossViolation) prioritySlugs.push('why-small-accounts-blow-up');
    if (hasEmotionalLeak) prioritySlugs.push('circuit-breakers-and-daily-loss-limits');
    prioritySlugs.push('asymmetric-risk-to-reward');
    prioritySlugs.push('nonlinear-math-of-drawdown-recovery');

    return ACADEMY_LESSONS.filter((l) => prioritySlugs.includes(l.slug)).slice(0, 3);
  }, [entries]);

  function handleAddTrade(e: React.FormEvent) {
    e.preventDefault();
    setValidationError(null);
    setSuccessMessage(null);

    if (!instrument.trim()) {
      setValidationError('Please enter a valid trading instrument symbol (e.g. XAUUSD, EURUSD).');
      return;
    }
    if (
      !Number.isFinite(entryPrice) ||
      entryPrice <= 0 ||
      !Number.isFinite(stopLoss) ||
      stopLoss <= 0 ||
      !Number.isFinite(exitPrice) ||
      exitPrice <= 0
    ) {
      setValidationError('Entry price, Stop-Loss price, and Exit price must all be greater than 0.');
      return;
    }
    if (Math.abs(entryPrice - stopLoss) < 1e-8) {
      setValidationError('Entry price and Stop-Loss price cannot be identical (0 stop distance).');
      return;
    }
    if (direction === 'LONG' && stopLoss >= entryPrice) {
      setValidationError(
        'Validation Error: For a LONG (Buy) trade, initial Stop-Loss must be strictly BELOW Entry price.'
      );
      return;
    }
    if (direction === 'SHORT' && stopLoss <= entryPrice) {
      setValidationError(
        'Validation Error: For a SHORT (Sell) trade, initial Stop-Loss must be strictly ABOVE Entry price.'
      );
      return;
    }
    if (!Number.isFinite(lotSize) || lotSize <= 0) {
      setValidationError('Executed lot size must be greater than 0 (e.g. 0.01 or 0.10).');
      return;
    }

    const newEntry: TradeJournalItem = {
      id: `trade-${Date.now()}`,
      tradedAt: new Date().toISOString().slice(0, 16).replace('T', ' '),
      instrument: instrument.trim().toUpperCase(),
      accountMode,
      direction,
      entryPrice,
      stopLoss,
      takeProfit,
      exitPrice,
      lotSize,
      realizedPnl,
      realizedRMultiple: previewRMultiple,
      setupTag: setupTag.trim() || 'Discretionary Setup',
      emotionTag,
      ruleFollowedStopLoss,
      ruleProperLotSize,
      ruleWaitedConfirmation,
      ruleWithinDailyLimit,
      notes: notes.trim()
    };

    const next = [newEntry, ...entries];
    setEntries(next);
    saveJournalEntries(next);
    setNotes('');
    setSuccessMessage(
      `Logged ${newEntry.direction} ${newEntry.instrument} (${newEntry.realizedRMultiple >= 0 ? '+' : ''}${newEntry.realizedRMultiple}R) to your local strategist ledger.`
    );
    setTimeout(() => setSuccessMessage(null), 4000);
  }

  function handleDeleteEntry(id: string) {
    const next = entries.filter((item) => item.id !== id);
    setEntries(next);
    saveJournalEntries(next);
  }

  function handleLoadSampleData() {
    setValidationError(null);
    setEntries(EDUCATIONAL_SAMPLE_JOURNAL_ENTRIES);
    saveJournalEntries(EDUCATIONAL_SAMPLE_JOURNAL_ENTRIES);
  }

  function handleClearAll() {
    setValidationError(null);
    setEntries([]);
    saveJournalEntries([]);
  }

  function sanitizeCsvCell(value: string): string {
    const escaped = (value || '').replace(/"/g, '""');
    if (/^[=+\-@\t\r]/.test(escaped)) {
      return `"'${escaped}"`;
    }
    return `"${escaped}"`;
  }

  function handleExportCsv() {
    const headers = [
      'Date',
      'Instrument',
      'AccountMode',
      'Direction',
      'Entry',
      'StopLoss',
      'Exit',
      'Lots',
      'PnL',
      'R_Multiple',
      'Setup',
      'Emotion',
      'FollowedSL',
      'ProperLot',
      'WaitedConfirmation',
      'WithinDailyLimit',
      'Notes'
    ];
    const rows = entries.map((e) =>
      [
        e.tradedAt,
        sanitizeCsvCell(e.instrument),
        e.accountMode,
        e.direction,
        e.entryPrice,
        e.stopLoss,
        e.exitPrice,
        e.lotSize,
        e.realizedPnl,
        e.realizedRMultiple,
        sanitizeCsvCell(e.setupTag),
        e.emotionTag,
        e.ruleFollowedStopLoss,
        e.ruleProperLotSize,
        e.ruleWaitedConfirmation,
        e.ruleWithinDailyLimit,
        sanitizeCsvCell(e.notes || '')
      ].join(',')
    );
    const csvContent = [headers.join(','), ...rows].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `jgs-trader-journal-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Header */}
      <div className="jgs-panel p-6 sm:p-8 flex flex-col lg:flex-row lg:items-center justify-between gap-6">
        <div className="space-y-2 max-w-3xl">
          <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-[#D4AF37]">
            <NotebookPen className="w-4 h-4" />
            <span>
              {isId
                ? 'JURNAL TRADER JGS • PENCATATAN RISIKO, EMOSI & PROGRES BELAJAR'
                : 'JGS TRADER JOURNAL • RISK, EMOTION & LEARNING PROGRESS TRACKER'}
            </span>
          </div>
          <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#F7F4EE]">
            {isId
              ? 'Audit Ekspektasi (R), Catatan Emosi & Kepatuhan Aturan Risiko'
              : 'Audit Your Expectancy (R), Emotional Notes & Learning Progress'}
          </h1>
          <p className="text-sm sm:text-base text-[#B8B0C8] leading-relaxed">
            {isId
              ? 'Transaksi profit yang melanggar aturan risiko adalah kebiasaan buruk, sedangkan transaksi rugi -1R yang mematuhi seluruh rencana adalah bagian wajar dari strategi. Catat riwayat transaksi, kepatuhan aturan, dan progres belajar Anda di sini.'
              : 'A winning trade that broke your risk rules is a bad habit. A losing -1R trade that followed every rule is good discipline. Track your entry/exit records, risk adherence, emotional state, and Academy mastery in one workspace.'}
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5 shrink-0">
          <button
            type="button"
            onClick={handleLoadSampleData}
            className="jgs-btn-outline text-xs py-2 px-3.5"
          >
            <Database className="w-3.5 h-3.5 text-[#D4AF37]" />
            <span>{isId ? 'Muat Contoh Jurnal' : 'Load Sample Ledger'}</span>
          </button>
          <button
            type="button"
            onClick={handleExportCsv}
            disabled={entries.length === 0}
            className="jgs-btn-outline text-xs py-2 px-3.5 disabled:opacity-40"
          >
            <Download className="w-3.5 h-3.5 text-[#10B981]" />
            <span>{isId ? 'Ekspor CSV' : 'Export CSV'}</span>
          </button>
          <button
            type="button"
            onClick={handleClearAll}
            className="px-3 py-2 rounded-lg bg-[#1A0D16] border border-[#EF4444]/30 text-xs font-mono text-[#EF4444] hover:border-[#EF4444]"
          >
            {isId ? 'Hapus Semua' : 'Clear All'}
          </button>
        </div>
      </div>

      {/* Loading Skeleton before LocalStorage Hydration */}
      {!isHydrated ? (
        <div className="jgs-panel p-8 space-y-4 animate-pulse">
          <div className="h-4 w-56 bg-white/10 rounded" />
          <div className="grid grid-cols-2 sm:grid-cols-6 gap-4">
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <div key={n} className="h-20 bg-white/5 rounded-xl" />
            ))}
          </div>
        </div>
      ) : (
        <>
          {/* Computed Analytics Dashboard Strip */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 font-mono tabular-nums">
            <div className="jgs-panel p-4">
              <div className="text-[10px] text-[#7E7494] uppercase">Logged Trades</div>
              <div className="text-2xl font-bold text-[#F7F4EE] mt-1">{stats.totalTrades}</div>
              <div className="text-[11px] text-[#B8B0C8] mt-0.5">
                {stats.winCount}W / {stats.lossCount}L
              </div>
            </div>

            <div className="jgs-panel p-4">
              <div className="text-[10px] text-[#7E7494] uppercase">Win Rate</div>
              <div className="text-2xl font-bold text-[#D4AF37] mt-1">{stats.winRatePercent}%</div>
              <div className="text-[11px] text-[#B8B0C8] mt-0.5">
                Avg Win: +{stats.averageWinR}R
              </div>
            </div>

            <div className="jgs-panel p-4">
              <div className="text-[10px] text-[#7E7494] uppercase">Math Expectancy</div>
              <div
                className={`text-2xl font-bold mt-1 ${
                  stats.expectancyR >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                }`}
              >
                {stats.expectancyR >= 0 ? '+' : ''}
                {stats.expectancyR}R
              </div>
              <div className="text-[11px] text-[#B8B0C8] mt-0.5">Per trade average</div>
            </div>

            <div className="jgs-panel p-4">
              <div className="text-[10px] text-[#7E7494] uppercase">Net R-Multiple</div>
              <div
                className={`text-2xl font-bold mt-1 ${
                  stats.netRMultiple >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                }`}
              >
                {stats.netRMultiple >= 0 ? '+' : ''}
                {stats.netRMultiple}R
              </div>
              <div className="text-[11px] text-[#B8B0C8] mt-0.5">
                PF: {stats.profitFactor.toFixed(2)}
              </div>
            </div>

            <div className="jgs-panel p-4">
              <div className="text-[10px] text-[#7E7494] uppercase">JGS Discipline Score</div>
              <div
                className={`text-2xl font-bold mt-1 ${
                  stats.disciplineScorePercent >= 85 ? 'text-[#10B981]' : 'text-[#F59E0B]'
                }`}
              >
                {stats.disciplineScorePercent}%
              </div>
              <div className="text-[11px] text-[#B8B0C8] mt-0.5">4-Rule Checklist Audit</div>
            </div>

            <div className="jgs-panel p-4">
              <div className="text-[10px] text-[#7E7494] uppercase flex items-center gap-1">
                <HeartPulse className="w-3 h-3 text-[#D4AF37]" />
                <span>Primary Emotional Audit</span>
              </div>
              <div className="text-xs font-bold text-[#F3E5AB] mt-2 leading-snug">
                {stats.topEmotionalLeak}
              </div>
            </div>
          </div>

          {/* Learning Progress & Recommended Curriculum Integration Panel */}
          <div className="jgs-panel p-6 border-[#D4AF37]/30 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            <div className="lg:col-span-5 space-y-3">
              <div className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-[#D4AF37] font-semibold">
                <GraduationCap className="w-4 h-4" />
                LEARNING PROGRESS & DISCIPLINEMASTERY
              </div>
              <h2 className="font-display text-xl font-bold text-[#F7F4EE]">
                Academy Mastery: {completedSlugs.length} / {ACADEMY_LESSONS.length} Modules (
                {academyProgressPercent}%)
              </h2>
              <div className="w-full h-2 rounded-full bg-[#09060F] overflow-hidden border border-white/10">
                <div
                  className="h-full bg-gradient-to-r from-[#D4AF37] to-[#10B981] transition-all duration-300"
                  style={{ width: `${Math.max(6, academyProgressPercent)}%` }}
                />
              </div>
              <p className="text-xs text-[#B8B0C8] leading-relaxed">
                Your journal automatically cross-references rule violations and emotional tags
                (such as <span className="text-[#F3E5AB]">FOMO</span> or oversized lots) with JGS
                Academy lessons to reinforce your weak spots.
              </p>
            </div>

            <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-3">
              {recommendedLessons.map((lesson) => {
                const isDone = completedSlugs.includes(lesson.slug);
                return (
                  <Link
                    key={lesson.slug}
                    href={l(`/academy/${lesson.slug}`)}
                    className="p-3.5 rounded-xl bg-[#09060F] border border-white/10 hover:border-[#D4AF37] transition-all flex flex-col justify-between gap-2"
                  >
                    <div className="space-y-1">
                      <div className="flex items-center justify-between text-[10px] font-mono">
                        <span className="text-[#D4AF37]">MODULE {lesson.lessonNumber}</span>
                        <span
                          className={
                            isDone ? 'text-[#10B981] font-bold' : 'text-[#7E7494]'
                          }
                        >
                          {isDone ? '✓ COMPLETED' : 'RECOMMENDED'}
                        </span>
                      </div>
                      <div className="font-display font-bold text-xs text-[#F7F4EE] line-clamp-2">
                        {lesson.title}
                      </div>
                    </div>
                    <div className="inline-flex items-center gap-1 text-[11px] font-mono text-[#F3E5AB]">
                      <span>Review Module</span>
                      <ArrowRight className="w-3 h-3" />
                    </div>
                  </Link>
                );
              })}
            </div>
          </div>

          {/* Logger Form + Trade History Table */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Log New Trade Form */}
            <form onSubmit={handleAddTrade} className="lg:col-span-5 jgs-panel p-6 space-y-4">
              <div className="flex items-center justify-between border-b border-white/10 pb-3">
                <h2 className="font-display text-lg font-bold text-[#F7F4EE]">
                  Log Executed Trade
                </h2>
                <span className="text-[11px] font-mono text-[#D4AF37]">
                  Validated Risk Entry
                </span>
              </div>

              {validationError && (
                <div className="p-3.5 rounded-xl bg-[#1A0D16] border border-[#EF4444] text-xs font-mono text-[#EF4444] flex items-start gap-2">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{validationError}</span>
                </div>
              )}

              {successMessage && (
                <div className="p-3.5 rounded-xl bg-[#0F1B1D] border border-[#10B981] text-xs font-mono text-[#10B981] flex items-start gap-2">
                  <CheckCircle2 className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>{successMessage}</span>
                </div>
              )}

              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label htmlFor="journal-instrument" className="jgs-label">
                    Instrument
                  </label>
                  <input
                    id="journal-instrument"
                    type="text"
                    value={instrument}
                    onChange={(e) => setInstrument(e.target.value)}
                    className="jgs-input"
                  />
                </div>
                <div>
                  <label htmlFor="journal-account" className="jgs-label">
                    Account
                  </label>
                  <select
                    id="journal-account"
                    value={accountMode}
                    onChange={(e) => setAccountMode(e.target.value as JournalAccountMode)}
                    className="jgs-input"
                  >
                    <option value="CENT_USC">Cent (USC)</option>
                    <option value="STANDARD_USD">Std (USD)</option>
                    <option value="DEMO">Demo</option>
                  </select>
                </div>
                <div>
                  <label htmlFor="journal-direction" className="jgs-label">
                    Direction
                  </label>
                  <select
                    id="journal-direction"
                    value={direction}
                    onChange={(e) => setDirection(e.target.value as JournalDirection)}
                    className="jgs-input"
                  >
                    <option value="LONG">LONG (Buy)</option>
                    <option value="SHORT">SHORT (Sell)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div>
                  <label htmlFor="journal-entry" className="jgs-label">
                    Entry Price
                  </label>
                  <input
                    id="journal-entry"
                    type="number"
                    step="any"
                    value={entryPrice}
                    onChange={(e) => setEntryPrice(Number(e.target.value))}
                    className="jgs-input"
                  />
                </div>
                <div>
                  <label htmlFor="journal-sl" className="jgs-label">
                    Stop Loss
                  </label>
                  <input
                    id="journal-sl"
                    type="number"
                    step="any"
                    value={stopLoss}
                    onChange={(e) => setStopLoss(Number(e.target.value))}
                    className="jgs-input"
                  />
                </div>
                <div>
                  <label htmlFor="journal-tp" className="jgs-label">
                    Take Profit
                  </label>
                  <input
                    id="journal-tp"
                    type="number"
                    step="any"
                    value={takeProfit}
                    onChange={(e) => setTakeProfit(Number(e.target.value))}
                    className="jgs-input"
                  />
                </div>
                <div>
                  <label htmlFor="journal-exit" className="jgs-label">
                    Exit Price
                  </label>
                  <input
                    id="journal-exit"
                    type="number"
                    step="any"
                    value={exitPrice}
                    onChange={(e) => setExitPrice(Number(e.target.value))}
                    className="jgs-input"
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2.5">
                <div>
                  <label htmlFor="journal-lots" className="jgs-label">
                    Lot Size
                  </label>
                  <input
                    id="journal-lots"
                    type="number"
                    step="0.01"
                    value={lotSize}
                    onChange={(e) => setLotSize(Number(e.target.value))}
                    className="jgs-input"
                  />
                </div>
                <div>
                  <label htmlFor="journal-pnl" className="jgs-label">
                    Realized PnL ({accountMode === 'CENT_USC' ? 'USC' : 'USD'})
                  </label>
                  <input
                    id="journal-pnl"
                    type="number"
                    step="any"
                    value={realizedPnl}
                    onChange={(e) => setRealizedPnl(Number(e.target.value))}
                    className="jgs-input"
                  />
                </div>
                <div>
                  <label className="jgs-label">Auto R-Multiple</label>
                  <div className="jgs-input bg-[#191129] text-[#D4AF37] font-bold flex items-center">
                    {previewRMultiple >= 0 ? '+' : ''}
                    {previewRMultiple}R
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2.5">
                <div>
                  <label htmlFor="journal-setup" className="jgs-label">
                    Setup / Strategy Tag
                  </label>
                  <input
                    id="journal-setup"
                    type="text"
                    value={setupTag}
                    onChange={(e) => setSetupTag(e.target.value)}
                    className="jgs-input font-sans"
                  />
                </div>
                <div>
                  <label htmlFor="journal-emotion" className="jgs-label">
                    Emotional State
                  </label>
                  <select
                    id="journal-emotion"
                    value={emotionTag}
                    onChange={(e) => setEmotionTag(e.target.value as JournalEmotion)}
                    className="jgs-input"
                  >
                    <option value="DISCIPLINED">DISCIPLINED</option>
                    <option value="CALM">CALM</option>
                    <option value="HESITANT">HESITANT</option>
                    <option value="FOMO">FOMO (Chased)</option>
                    <option value="REVENGE">REVENGE</option>
                    <option value="OVERCONFIDENT">OVERCONFIDENT</option>
                  </select>
                </div>
              </div>

              {/* 4-Point Pre-Trade Rule Checklist */}
              <div className="p-3.5 rounded-xl bg-[#09060F] border border-white/10 space-y-2">
                <div className="text-xs font-mono uppercase text-[#D4AF37] font-semibold flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>4-POINT PRE-TRADE RISK & DISCIPLINE CHECKLIST</span>
                </div>
                {[
                  {
                    checked: ruleFollowedStopLoss,
                    setter: setRuleFollowedStopLoss,
                    label: 'Hard Stop Loss placed & never widened against price'
                  },
                  {
                    checked: ruleProperLotSize,
                    setter: setRuleProperLotSize,
                    label: 'Lot size calculated via Cent Lab (<= 1.5% risk cap)'
                  },
                  {
                    checked: ruleWaitedConfirmation,
                    setter: setRuleWaitedConfirmation,
                    label: 'Waited for candle close confirmation inside active session'
                  },
                  {
                    checked: ruleWithinDailyLimit,
                    setter: setRuleWithinDailyLimit,
                    label: 'Executed within 3% Daily Loss Circuit Breaker'
                  }
                ].map((rule, idx) => (
                  <label
                    key={idx}
                    className="flex items-center gap-2.5 text-xs text-[#F7F4EE] cursor-pointer"
                  >
                    <input
                      type="checkbox"
                      checked={rule.checked}
                      onChange={(e) => rule.setter(e.target.checked)}
                      className="accent-[#D4AF37] w-4 h-4 rounded"
                    />
                    <span>{rule.label}</span>
                  </label>
                ))}
              </div>

              <div>
                <label htmlFor="journal-notes" className="jgs-label">
                  Trade & Emotional Notes
                </label>
                <textarea
                  id="journal-notes"
                  rows={2}
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Record execution context, emotional triggers, or post-trade lessons..."
                  className="jgs-input font-sans"
                />
              </div>

              <button type="submit" className="jgs-btn-gold w-full text-xs py-3">
                <PlusCircle className="w-4 h-4" />
                <span>Record Trade in Journal</span>
              </button>
            </form>

            {/* Right: Trade Ledger List with Search, Emotion Filter & Empty State */}
            <div className="lg:col-span-7 space-y-4">
              {/* Filter Bar */}
              <div className="jgs-panel p-4 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                <div className="relative flex-1">
                  <Search className="w-4 h-4 text-[#7E7494] absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="search"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Filter journal by instrument, setup, or notes..."
                    aria-label="Filter journal entries"
                    className="w-full pl-9 pr-3 py-2 rounded-lg bg-[#09060F] border border-white/10 text-xs text-[#F7F4EE] placeholder-[#7E7494] focus:outline-none focus:border-[#D4AF37]"
                  />
                </div>

                <select
                  value={emotionFilter}
                  onChange={(e) =>
                    setEmotionFilter(e.target.value as 'ALL' | JournalEmotion)
                  }
                  aria-label="Filter by emotional state"
                  className="px-3 py-2 rounded-lg bg-[#09060F] border border-white/10 text-xs font-mono text-[#F3E5AB]"
                >
                  <option value="ALL">All Emotions ({entries.length})</option>
                  <option value="DISCIPLINED">DISCIPLINED</option>
                  <option value="CALM">CALM</option>
                  <option value="HESITANT">HESITANT</option>
                  <option value="FOMO">FOMO</option>
                  <option value="REVENGE">REVENGE</option>
                  <option value="OVERCONFIDENT">OVERCONFIDENT</option>
                </select>
              </div>

              {/* Empty State vs Ledger Items */}
              {filteredEntries.length === 0 ? (
                <div className="jgs-panel p-10 text-center space-y-4">
                  <div className="font-display text-xl font-bold text-[#F7F4EE]">
                    {entries.length === 0
                      ? 'Your Trader Journal Ledger Is Currently Empty'
                      : 'No Journal Records Match Your Filter'}
                  </div>
                  <p className="text-sm text-[#B8B0C8] max-w-md mx-auto">
                    {entries.length === 0
                      ? 'Log your first trade using the form on the left, or load the educational sample ledger to inspect how JGS audits R-multiples and emotional leaks.'
                      : 'Clear your search query or emotion filter to view all recorded trades.'}
                  </p>
                  <div className="flex items-center justify-center gap-3">
                    {entries.length === 0 ? (
                      <button
                        type="button"
                        onClick={handleLoadSampleData}
                        className="jgs-btn-gold text-xs"
                      >
                        <Database className="w-3.5 h-3.5" />
                        <span>Load Sample Educational Ledger</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={() => {
                          setSearchQuery('');
                          setEmotionFilter('ALL');
                        }}
                        className="jgs-btn-outline text-xs"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Reset Journal Filters</span>
                      </button>
                    )}
                  </div>
                </div>
              ) : (
                filteredEntries.map((item) => {
                  const rulesPassed =
                    (item.ruleFollowedStopLoss ? 1 : 0) +
                    (item.ruleProperLotSize ? 1 : 0) +
                    (item.ruleWaitedConfirmation ? 1 : 0) +
                    (item.ruleWithinDailyLimit ? 1 : 0);

                  return (
                    <div key={item.id} className="jgs-panel p-5 space-y-3">
                      <div className="flex flex-wrap items-center justify-between gap-2 pb-2.5 border-b border-white/10">
                        <div className="flex flex-wrap items-center gap-2">
                          <span
                            className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold ${
                              item.direction === 'LONG'
                                ? 'bg-[#10B981]/20 text-[#10B981]'
                                : 'bg-[#EF4444]/20 text-[#EF4444]'
                            }`}
                          >
                            {item.direction}
                          </span>
                          <span className="font-mono font-bold text-base text-[#F7F4EE]">
                            {item.instrument}
                          </span>
                          <span className="text-xs font-mono text-[#7E7494]">
                            • {item.tradedAt}
                          </span>
                          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-[#191129] text-[#B8B0C8]">
                            {item.setupTag}
                          </span>
                        </div>

                        <div className="flex items-center gap-3 font-mono">
                          <span
                            className={`text-sm font-bold ${
                              item.realizedRMultiple >= 0 ? 'text-[#10B981]' : 'text-[#EF4444]'
                            }`}
                          >
                            {item.realizedRMultiple >= 0 ? '+' : ''}
                            {item.realizedRMultiple}R ({item.realizedPnl >= 0 ? '+' : ''}
                            {item.realizedPnl}{' '}
                            {item.accountMode === 'CENT_USC' ? 'USC' : 'USD'})
                          </span>
                          <button
                            type="button"
                            onClick={() => handleDeleteEntry(item.id)}
                            className="text-[#7E7494] hover:text-[#EF4444]"
                            title="Delete trade entry"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-xs font-mono text-[#B8B0C8] tabular-nums">
                        <div>Entry: {item.entryPrice}</div>
                        <div>SL: {item.stopLoss}</div>
                        <div>Exit: {item.exitPrice}</div>
                        <div>Lots: {item.lotSize}</div>
                        <div className="flex items-center gap-1">
                          {rulesPassed === 4 ? (
                            <span className="text-[#10B981] inline-flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> 4/4 ({item.emotionTag})
                            </span>
                          ) : (
                            <span className="text-[#F59E0B] inline-flex items-center gap-1">
                              <AlertTriangle className="w-3.5 h-3.5" /> {rulesPassed}/4 (
                              {item.emotionTag})
                            </span>
                          )}
                        </div>
                      </div>

                      {item.notes && (
                        <p className="text-xs text-[#B8B0C8] bg-[#09060F] p-3 rounded-lg border border-white/5">
                          {item.notes}
                        </p>
                      )}
                    </div>
                  );
                })
              )}

              <JeyStrategistCallout
                ruleText="Your Discipline Score matters more than any single trade outcome. Keep your rule adherence above 90%, and positive mathematical expectancy will take care of the equity curve."
                contextTag="JOURNAL AUDIT"
              />
            </div>
          </div>
        </>
      )}
    </div>
  );
}
