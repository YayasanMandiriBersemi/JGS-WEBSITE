'use client';

import React, { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Menu, X, ChevronDown, ArrowRight, Globe } from 'lucide-react';
import { useLocale } from '@/i18n/LocaleContext';
import { stripLocalePrefix } from '@/i18n/config';

interface NavSubItem {
  href: string;
  labelId: string;
  labelEn: string;
  descId: string;
  descEn: string;
}

interface MainNavItem {
  key: string;
  href: string;
  labelId: string;
  labelEn: string;
  matchPrefixes: string[];
  children?: NavSubItem[];
}

const MAIN_NAV_ITEMS: MainNavItem[] = [
  {
    key: 'learn',
    href: '/learn',
    labelId: 'Belajar',
    labelEn: 'Learn',
    matchPrefixes: ['/learn', '/academy', '/dictionary', '/onboarding'],
    children: [
      {
        href: '/academy',
        labelId: 'JGS Academy',
        labelEn: 'JGS Academy',
        descId: 'Jalur belajar terstruktur untuk pemula hingga sistem kuantitatif.',
        descEn: 'Structured learning paths from beginner foundations to quantitative systems.'
      },
      {
        href: '/dictionary',
        labelId: 'Kamus Trading',
        labelEn: 'Trading Dictionary',
        descId: 'Penjelasan istilah market dan manajemen risiko dengan bahasa sederhana.',
        descEn: 'Plain-language trading and risk management terminology with visual diagrams.'
      },
      {
        href: '/onboarding',
        labelId: 'Panduan Awal (Onboarding)',
        labelEn: 'Guided Onboarding',
        descId: 'Rekomendasi jalur belajar sesuai pengalaman Anda.',
        descEn: 'Tailored starting path based on your experience level.'
      }
    ]
  },
  {
    key: 'tools',
    href: '/tools',
    labelId: 'Trading Tools',
    labelEn: 'Trading Tools',
    matchPrefixes: ['/tools', '/calculators', '/playground', '/journal'],
    children: [
      {
        href: '/calculators/cent',
        labelId: 'Cent Lab',
        labelEn: 'Cent Lab',
        descId: 'Konversi USD ↔ USC dan perbandingan spesifikasi kontrak broker.',
        descEn: 'USD ↔ USC conversion and broker-specific contract specification analysis.'
      },
      {
        href: '/calculators/position-size',
        labelId: 'Kalkulator Ukuran Posisi',
        labelEn: 'Position Sizing Calculator',
        descId: 'Hitung lot berdasarkan ekuitas, batas risiko, ukuran tick, dan nilai tick.',
        descEn: 'Compute exact volume from equity, risk cap, tick size, and tick value.'
      },
      {
        href: '/calculators/drawdown',
        labelId: 'Simulator Drawdown',
        labelEn: 'Drawdown Simulator',
        descId: 'Simulasi pemulihan modal non-linear dan uji ketahanan beruntun.',
        descEn: 'Simulate nonlinear capital recovery and consecutive loss streaks.'
      },
      {
        href: '/playground',
        labelId: 'Trading Playground',
        labelEn: 'Trading Playground',
        descId: 'Latihan keputusan Buy, Sell, atau Wait pada skenario edukasi historis.',
        descEn: 'Practice Buy, Sell, or Wait decisions on historical educational scenarios.'
      },
      {
        href: '/journal',
        labelId: 'Jurnal Trader',
        labelEn: 'Trader Journal',
        descId: 'Catat transaksi, disiplin risiko, dan evaluasi psikologi trading.',
        descEn: 'Log trades, risk discipline, and emotional execution notes.'
      }
    ]
  },
  {
    key: 'research',
    href: '/research',
    labelId: 'Riset Market',
    labelEn: 'Market Research',
    matchPrefixes: ['/research']
  },
  {
    key: 'strategy',
    href: '/strategy',
    labelId: 'Strategi Kami',
    labelEn: 'Our Strategy',
    matchPrefixes: ['/strategy', '/quant-lab', '/ea-testing', '/copy-trading'],
    children: [
      {
        href: '/quant-lab',
        labelId: 'Quant Lab',
        labelEn: 'Quant Lab',
        descId: 'Dokumentasi arsitektur eksekusi MT5 dan pengendalian risiko algoritmik.',
        descEn: 'MT5 execution architecture and algorithmic risk control documentation.'
      },
      {
        href: '/ea-testing',
        labelId: 'EA Testing Toolkit',
        labelEn: 'EA Testing Toolkit',
        descId: 'Alat evaluasi kualitas backtest, ketahanan spread, dan deteksi overfitting.',
        descEn: 'Audit backtest modeling quality, spread resilience, and curve-fitting risks.'
      },
      {
        href: '/copy-trading',
        labelId: 'Informasi Copy Trading',
        labelEn: 'Copy Trading Information',
        descId: 'Penjelasan mekanisme High-Water Mark, biaya performa 30%, dan risiko.',
        descEn: 'High-Water Mark mechanics, proposed 30% performance fee, and risk disclosures.'
      }
    ]
  },
  {
    key: 'performance',
    href: '/performance',
    labelId: 'Performa',
    labelEn: 'Performance',
    matchPrefixes: ['/performance']
  },
  {
    key: 'about',
    href: '/about',
    labelId: 'Tentang JGS',
    labelEn: 'About JGS',
    matchPrefixes: ['/about', '/community']
  }
];

export function Navbar() {
  const pathname = usePathname() || '/';
  const { locale, isId, l, switchLocale } = useLocale();
  const [mobileOpen, setMobileOpen] = useState(false);
  const [openDropdownKey, setOpenDropdownKey] = useState<string | null>(null);

  const barePath = stripLocalePrefix(pathname);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 jgs-glass">
      <div className="max-w-7xl mx-auto px-3 sm:px-6">
        <div className="flex items-center justify-between h-20 gap-2 sm:gap-4">
          {/* Brand Identity */}
          <Link
            href={l('/')}
            className="flex items-center gap-2.5 sm:gap-3.5 group min-w-0"
            onClick={() => setMobileOpen(false)}
          >
            <div className="relative w-9 h-9 sm:w-10 sm:h-10 rounded-xl overflow-hidden border border-[#D4AF37]/60 bg-[#1A102B] p-0.5 shrink-0 transition-transform duration-200 group-hover:scale-105">
              <img
                src="/images/jey-mascot.png"
                alt="Jey — Mascot of The Jey Gang Strategist"
                width={40}
                height={40}
                decoding="async"
                className="w-full h-full object-cover object-top rounded-[9px]"
              />
            </div>
            <div className="min-w-0">
              <div className="font-display font-bold text-xs sm:text-base tracking-wide text-[#F7F4EE] flex items-center gap-1 sm:gap-1.5 truncate">
                <span>THE JEY GANG</span>
                <span className="text-[#D4AF37]">STRATEGIST</span>
              </div>
              <div className="font-serif italic text-[11px] sm:text-[13px] text-[#F3E5AB]/90 truncate">
                Small Capital. Serious Strategy.
              </div>
            </div>
          </Link>

          {/* Simplified 6-Pillar Desktop Navigation */}
          <nav
            className="hidden lg:flex items-center gap-1"
            aria-label={isId ? 'Navigasi Utama' : 'Primary Navigation'}
          >
            {MAIN_NAV_ITEMS.map((item) => {
              const isActive = item.matchPrefixes.some(
                (prefix) => barePath === prefix || barePath.startsWith(`${prefix}/`)
              );
              const label = isId ? item.labelId : item.labelEn;

              if (!item.children) {
                return (
                  <Link
                    key={item.key}
                    href={l(item.href)}
                    className={`px-3.5 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                      isActive
                        ? 'text-[#F3E5AB] bg-white/[0.06]'
                        : 'text-[#BEB6CE] hover:text-[#F7F4EE] hover:bg-white/[0.04]'
                    }`}
                  >
                    {label}
                  </Link>
                );
              }

              return (
                <div
                  key={item.key}
                  className="relative"
                  onMouseEnter={() => setOpenDropdownKey(item.key)}
                  onMouseLeave={() => setOpenDropdownKey(null)}
                >
                  <Link
                    href={l(item.href)}
                    className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap ${
                      isActive
                        ? 'text-[#F3E5AB] bg-white/[0.06]'
                        : 'text-[#BEB6CE] hover:text-[#F7F4EE] hover:bg-white/[0.04]'
                    }`}
                  >
                    <span>{label}</span>
                    <ChevronDown className="w-3.5 h-3.5 opacity-75" />
                  </Link>

                  {openDropdownKey === item.key && (
                    <div className="absolute left-0 top-full pt-2 w-80 z-50">
                      <div className="rounded-2xl bg-[#120B1E] border border-[#D4AF37]/30 shadow-2xl p-2 space-y-1">
                        {item.children.map((sub) => (
                          <Link
                            key={sub.href}
                            href={l(sub.href)}
                            onClick={() => setOpenDropdownKey(null)}
                            className="block p-3 rounded-xl hover:bg-white/[0.05] transition-colors"
                          >
                            <div className="font-display font-semibold text-sm text-[#F7F4EE]">
                              {isId ? sub.labelId : sub.labelEn}
                            </div>
                            <div className="text-xs text-[#BEB6CE] mt-0.5 leading-snug">
                              {isId ? sub.descId : sub.descEn}
                            </div>
                          </Link>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              );
            })}
          </nav>

          {/* Right Cluster: Visible Language Switcher (ID | EN) & Primary CTA */}
          <div className="hidden sm:flex items-center gap-3 shrink-0">
            <div
              role="group"
              aria-label={isId ? 'Pilih Bahasa' : 'Select Language'}
              className="inline-flex items-center rounded-xl bg-[#120B1E] border border-white/15 p-1"
            >
              <Globe className="w-3.5 h-3.5 text-[#D4AF37] ml-2 mr-1" />
              <button
                type="button"
                onClick={() => switchLocale('id')}
                aria-pressed={locale === 'id'}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  locale === 'id'
                    ? 'bg-[#D4AF37] text-[#08050E]'
                    : 'text-[#BEB6CE] hover:text-[#F7F4EE]'
                }`}
              >
                ID
              </button>
              <button
                type="button"
                onClick={() => switchLocale('en')}
                aria-pressed={locale === 'en'}
                className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                  locale === 'en'
                    ? 'bg-[#D4AF37] text-[#08050E]'
                    : 'text-[#BEB6CE] hover:text-[#F7F4EE]'
                }`}
              >
                EN
              </button>
            </div>

            <Link
              href={l('/academy')}
              className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-[#D4AF37] text-[#08050E] font-semibold text-xs sm:text-sm hover:bg-[#F3E5AB] transition-colors whitespace-nowrap"
            >
              <span>{isId ? 'Mulai Belajar' : 'Start Learning'}</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>

          {/* Mobile Controls */}
          <div className="flex lg:hidden items-center gap-2">
            <div
              role="group"
              aria-label={isId ? 'Pilih Bahasa' : 'Select Language'}
              className="inline-flex sm:hidden items-center rounded-xl bg-[#120B1E] border border-white/15 p-1"
            >
              <button
                type="button"
                onClick={() => switchLocale('id')}
                aria-pressed={locale === 'id'}
                className={`px-2 py-1 rounded-lg text-xs font-semibold ${
                  locale === 'id' ? 'bg-[#D4AF37] text-[#08050E]' : 'text-[#BEB6CE]'
                }`}
              >
                ID
              </button>
              <button
                type="button"
                onClick={() => switchLocale('en')}
                aria-pressed={locale === 'en'}
                className={`px-2 py-1 rounded-lg text-xs font-semibold ${
                  locale === 'en' ? 'bg-[#D4AF37] text-[#08050E]' : 'text-[#BEB6CE]'
                }`}
              >
                EN
              </button>
            </div>

            <button
              type="button"
              onClick={() => setMobileOpen(!mobileOpen)}
              className="p-2.5 rounded-xl bg-[#120B1E] border border-white/15 text-[#F7F4EE]"
              aria-label={isId ? 'Buka Menu Navigasi' : 'Toggle Navigation Menu'}
              aria-expanded={mobileOpen}
            >
              {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Navigation Drawer */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-white/10 bg-[#08050E] px-4 sm:px-6 py-6 space-y-6">
          <div className="space-y-4">
            {MAIN_NAV_ITEMS.map((item) => {
              const label = isId ? item.labelId : item.labelEn;
              return (
                <div key={item.key} className="space-y-2">
                  <Link
                    href={l(item.href)}
                    onClick={() => setMobileOpen(false)}
                    className="block font-display font-bold text-base text-[#F7F4EE] hover:text-[#D4AF37]"
                  >
                    {label}
                  </Link>
                  {item.children && (
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pl-3 border-l border-white/10">
                      {item.children.map((sub) => (
                        <Link
                          key={sub.href}
                          href={l(sub.href)}
                          onClick={() => setMobileOpen(false)}
                          className="p-2.5 rounded-xl bg-[#120B1E] border border-white/5 text-sm text-[#BEB6CE] hover:text-[#F7F4EE]"
                        >
                          <div className="font-medium text-[#F7F4EE]">
                            {isId ? sub.labelId : sub.labelEn}
                          </div>
                          <div className="text-xs text-[#8E84A4] mt-0.5">
                            {isId ? sub.descId : sub.descEn}
                          </div>
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              );
            })}
          </div>

          <div className="pt-4 border-t border-white/10 flex flex-wrap items-center justify-between gap-3">
            <Link
              href={l('/academy')}
              onClick={() => setMobileOpen(false)}
              className="jgs-btn-gold text-sm w-full sm:w-auto"
            >
              <span>{isId ? 'Mulai Belajar Gratis' : 'Start Learning for Free'}</span>
              <ArrowRight className="w-4 h-4" />
            </Link>
            <Link
              href={l('/tools')}
              onClick={() => setMobileOpen(false)}
              className="jgs-btn-outline text-sm w-full sm:w-auto"
            >
              <span>{isId ? 'Coba Trading Tools' : 'Explore Trading Tools'}</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
