'use client';

import React, { useState, useMemo } from 'react';
import Link from 'next/link';
import {
  PLAYGROUND_SCENARIOS,
  PlaygroundScenario,
  ScenarioDecisionOption
} from '@/lib/data/playground-scenarios';
import {
  PlaygroundAction,
  simulatePlaygroundDecision
} from '@/lib/math/playground-engine';
import { JeyStrategistCallout } from '@/components/brand/JeyStrategistCallout';
import { useLocale } from '@/i18n/LocaleContext';
import {
  Gamepad2,
  Play,
  RotateCcw,
  StepForward,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  Sliders,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  PauseCircle,
  Award,
  Database
} from 'lucide-react';

function getDefaultSlTpForScenario(
  scenario: PlaygroundScenario,
  action: PlaygroundAction
): { sl: number; tp: number } {
  const entry = scenario.candles[scenario.decisionBarIndex].close;
  const isGold = scenario.instrument === 'XAUUSD';
  const defaultStopDist = isGold ? 2.5 : 0.002;
  const defaultTpDist = isGold ? 5.5 : 0.0045;
  const decimals = isGold ? 2 : 4;

  if (action === 'BUY') {
    return {
      sl: Number((entry - defaultStopDist).toFixed(decimals)),
      tp: Number((entry + defaultTpDist).toFixed(decimals))
    };
  }
  if (action === 'SELL') {
    return {
      sl: Number((entry + defaultStopDist).toFixed(decimals)),
      tp: Number((entry - defaultTpDist).toFixed(decimals))
    };
  }
  return { sl: entry, tp: entry };
}

export function PlaygroundSimulator() {
  const { isId, l } = useLocale();
  const [selectedScenarioId, setSelectedScenarioId] = useState<string>(
    PLAYGROUND_SCENARIOS[0].id
  );
  const scenario: PlaygroundScenario =
    PLAYGROUND_SCENARIOS.find((s) => s.id === selectedScenarioId) ?? PLAYGROUND_SCENARIOS[0];

  const [visibleBarIndex, setVisibleBarIndex] = useState<number>(scenario.decisionBarIndex);
  const [executionMode, setExecutionMode] = useState<'CUSTOM_ORDER' | 'CURATED_OPTIONS'>(
    'CUSTOM_ORDER'
  );

  // Custom Order Builder State (Buy / Sell / Wait + SL + TP + Equity/Risk)
  const initialLevels = getDefaultSlTpForScenario(scenario, 'SELL');
  const [customAction, setCustomAction] = useState<PlaygroundAction>('SELL');
  const [customStopLoss, setCustomStopLoss] = useState<number>(initialLevels.sl);
  const [customTakeProfit, setCustomTakeProfit] = useState<number>(initialLevels.tp);
  const [customEquityUsc, setCustomEquityUsc] = useState<number>(2500);
  const [customRiskPercent, setCustomRiskPercent] = useState<number>(1.0);
  const [hasExecutedCustom, setHasExecutedCustom] = useState<boolean>(false);

  // Curated Option State
  const [chosenOptionId, setChosenOptionId] = useState<string | null>(null);

  const decisionCandle = scenario.candles[scenario.decisionBarIndex];
  const entryPrice = decisionCandle.close;
  const decimals = scenario.instrument === 'XAUUSD' ? 2 : 4;

  function handleSelectScenario(newId: string) {
    const target = PLAYGROUND_SCENARIOS.find((s) => s.id === newId) ?? PLAYGROUND_SCENARIOS[0];
    setSelectedScenarioId(target.id);
    setVisibleBarIndex(target.decisionBarIndex);
    setChosenOptionId(null);
    setHasExecutedCustom(false);

    const optimalPreset = target.options.find((o) => o.isOptimalChoice);
    const defaultAction: PlaygroundAction =
      optimalPreset?.actionType === 'SHORT'
        ? 'SELL'
        : optimalPreset?.actionType === 'STAND_ASIDE'
          ? 'WAIT'
          : 'BUY';
    setCustomAction(defaultAction);
    const lvls = getDefaultSlTpForScenario(target, defaultAction === 'WAIT' ? 'BUY' : defaultAction);
    setCustomStopLoss(lvls.sl);
    setCustomTakeProfit(lvls.tp);
  }

  function handleActionChange(nextAction: PlaygroundAction) {
    setCustomAction(nextAction);
    setHasExecutedCustom(false);
    if (nextAction !== 'WAIT') {
      const lvls = getDefaultSlTpForScenario(scenario, nextAction);
      setCustomStopLoss(lvls.sl);
      setCustomTakeProfit(lvls.tp);
    }
  }

  function applyQuickRrPreset(rrMultiplier: number, isTightTrap = false) {
    const isGold = scenario.instrument === 'XAUUSD';
    const baseStop = isTightTrap
      ? isGold
        ? 0.9
        : 0.0008
      : isGold
        ? 2.8
        : 0.0022;
    const tpDist = baseStop * rrMultiplier;

    if (customAction === 'SELL') {
      setCustomStopLoss(Number((entryPrice + baseStop).toFixed(decimals)));
      setCustomTakeProfit(Number((entryPrice - tpDist).toFixed(decimals)));
    } else {
      setCustomAction('BUY');
      setCustomStopLoss(Number((entryPrice - baseStop).toFixed(decimals)));
      setCustomTakeProfit(Number((entryPrice + tpDist).toFixed(decimals)));
    }
    setHasExecutedCustom(false);
  }

  function handleRunCustomSimulation() {
    setHasExecutedCustom(true);
    setChosenOptionId(null);
    setVisibleBarIndex(scenario.candles.length - 1);
  }

  function handleExecuteCuratedOption(option: ScenarioDecisionOption) {
    setChosenOptionId(option.id);
    setHasExecutedCustom(false);
    setVisibleBarIndex(scenario.candles.length - 1);
  }

  function handleStepBar() {
    if (visibleBarIndex < scenario.candles.length - 1) {
      setVisibleBarIndex((prev) => prev + 1);
    }
  }

  function handleResetScenario() {
    setVisibleBarIndex(scenario.decisionBarIndex);
    setChosenOptionId(null);
    setHasExecutedCustom(false);
  }

  // Live Custom Simulation Computation
  const customSimResult = useMemo(
    () =>
      simulatePlaygroundDecision({
        scenario,
        action: customAction,
        stopLossPrice: customStopLoss,
        takeProfitPrice: customTakeProfit,
        equityUsc: customEquityUsc,
        riskPercent: customRiskPercent
      }),
    [scenario, customAction, customStopLoss, customTakeProfit, customEquityUsc, customRiskPercent]
  );

  const visibleCandles = scenario.candles.slice(0, visibleBarIndex + 1);
  const chosenOption = scenario.options.find((o) => o.id === chosenOptionId) ?? null;

  // Determine which Entry/SL/TP lines to render on the SVG chart
  const chartEntryLine =
    executionMode === 'CUSTOM_ORDER'
      ? customAction !== 'WAIT'
        ? entryPrice
        : undefined
      : chosenOption?.entryPrice;

  const chartSlLine =
    executionMode === 'CUSTOM_ORDER'
      ? customAction !== 'WAIT'
        ? customStopLoss
        : undefined
      : chosenOption?.stopLoss;

  const chartTpLine =
    executionMode === 'CUSTOM_ORDER'
      ? customAction !== 'WAIT'
        ? customTakeProfit
        : undefined
      : chosenOption?.takeProfit;

  // Compute SVG chart price bounds
  const allPrices = visibleCandles.flatMap((c) => [c.high, c.low]);
  if (chartSlLine) allPrices.push(chartSlLine);
  if (chartTpLine) allPrices.push(chartTpLine);
  allPrices.push(scenario.keyLevelPrice);

  const minPrice = Math.min(...allPrices);
  const maxPrice = Math.max(...allPrices);
  const priceRange = Math.max(0.0005, maxPrice - minPrice);
  const paddedMin = minPrice - priceRange * 0.15;
  const paddedMax = maxPrice + priceRange * 0.15;
  const paddedRange = paddedMax - paddedMin;

  const chartHeight = 320;
  const chartWidth = 760;

  function priceToY(p: number): number {
    return chartHeight - ((p - paddedMin) / paddedRange) * (chartHeight - 40) - 20;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-10 space-y-8">
      {/* Header & Historical Data Provenance Banner */}
      <div className="jgs-panel p-6 sm:p-8 space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="inline-flex items-center gap-2 text-xs font-semibold text-[#D4AF37]">
              <Gamepad2 className="w-4 h-4" />
              <span>
                {isId
                  ? 'JGS TRADING PLAYGROUND • SIMULATOR KEPUTUSAN & SKENARIO HISTORIS'
                  : 'JGS TRADING PLAYGROUND • INTERACTIVE DECISION & RISK SIMULATOR'}
              </span>
            </div>
            <h1 className="font-display text-3xl sm:text-4xl font-bold text-[#F7F4EE]">
              {isId
                ? 'Latih Keputusan Buy, Sell & Wait pada Skenario Market Historis'
                : 'Practice Buy, Sell & Wait Decisions on Historical Market Scenarios'}
            </h1>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <span className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#191129] border border-[#D4AF37]/40 text-xs font-medium text-[#F3E5AB]">
              <Database className="w-3.5 h-3.5 text-[#D4AF37]" />
              {isId
                ? 'DATA SKENARIO EDUKASI HISTORIS • BUKAN DATA LIVE'
                : 'HISTORICAL EDUCATIONAL SCENARIO DATA • NOT LIVE MARKET DATA'}
            </span>
            <Link href={l('/journal')} className="jgs-btn-outline text-xs">
              <span>{isId ? 'Catat di Jurnal Trader' : 'Log in Trader Journal'}</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>

        <p className="text-sm sm:text-base text-[#B8B0C8] max-w-3xl leading-relaxed">
          {isId ? (
            <>
              Amati struktur harga pada Decision Bar, pilih apakah akan{' '}
              <span className="text-[#10B981] font-semibold">BUY</span>,{' '}
              <span className="text-[#EF4444] font-semibold">SELL</span>, atau{' '}
              <span className="text-[#D4AF37] font-semibold">WAIT</span>, tentukan titik{' '}
              <span className="text-[#F3E5AB]">Stop-Loss</span> dan{' '}
              <span className="text-[#F3E5AB]">Take-Profit</span>, lalu pelajari evaluasi kualitas
              keputusan Anda. Seluruh simulasi menggunakan data skenario edukasi historis.
            </>
          ) : (
            <>
              Inspect the price structure at the Decision Bar, choose whether to{' '}
              <span className="text-[#10B981] font-semibold">BUY</span>,{' '}
              <span className="text-[#EF4444] font-semibold">SELL</span>, or{' '}
              <span className="text-[#D4AF37] font-semibold">WAIT</span>, set your exact{' '}
              <span className="text-[#F3E5AB]">Stop-Loss</span> and{' '}
              <span className="text-[#F3E5AB]">Take-Profit</span> levels, and receive an instant
              Decision Quality Audit. All scenarios use explicitly identified historical educational
              OHLC structures.
            </>
          )}
        </p>

        {/* Scenario Selector Tabs */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-2">
          {PLAYGROUND_SCENARIOS.map((item) => {
            const isSelected = item.id === scenario.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => handleSelectScenario(item.id)}
                className={`text-left p-4 rounded-xl border transition-all ${
                  isSelected
                    ? 'bg-[#D4AF37]/15 border-[#D4AF37] text-[#F7F4EE]'
                    : 'bg-[#09060F] border-white/10 text-[#B8B0C8] hover:border-white/25'
                }`}
              >
                <div className="flex items-center justify-between text-[11px] font-mono">
                  <span className="text-[#D4AF37] font-bold">{item.code}</span>
                  <span className="px-2 py-0.5 rounded bg-[#191129] text-[#F3E5AB]">
                    {item.instrument} • {item.timeframe}
                  </span>
                </div>
                <div className="font-display font-bold text-sm text-[#F7F4EE] mt-1.5 line-clamp-2">
                  {item.title}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Simulator Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Candlestick Replay Chart */}
        <div className="lg:col-span-7 jgs-panel p-6 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-[#D4AF37] uppercase font-semibold">
                  {scenario.sessionContext}
                </span>
                <span className="px-2 py-0.5 rounded bg-white/5 border border-white/10 text-[10px] font-mono text-[#B8B0C8]">
                  SAMPLE HISTORICAL REPLAY
                </span>
              </div>
              <h2 className="font-display text-xl font-bold text-[#F7F4EE] mt-1">
                {scenario.title}
              </h2>
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleStepBar}
                disabled={visibleBarIndex >= scenario.candles.length - 1}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#191129] border border-[#D4AF37]/30 text-xs font-mono text-[#F3E5AB] disabled:opacity-40"
              >
                <StepForward className="w-3.5 h-3.5" />
                <span>Step Next Bar</span>
              </button>
              <button
                type="button"
                onClick={handleResetScenario}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg bg-[#09060F] border border-white/15 text-xs font-mono text-[#B8B0C8] hover:text-[#F7F4EE]"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Reset Replay</span>
              </button>
            </div>
          </div>

          {/* Scenario Briefing */}
          <div className="p-4 rounded-xl bg-[#09060F] border border-white/10 text-xs sm:text-sm text-[#F7F4EE]/90 leading-relaxed">
            <span className="font-mono font-bold text-[#D4AF37] uppercase block mb-1">
              Historical Scenario Briefing (Decision Bar:{' '}
              {scenario.candles[scenario.decisionBarIndex].timeLabel} @{' '}
              {entryPrice.toFixed(decimals)}):
            </span>
            {scenario.briefing}
          </div>

          {/* SVG Candlestick Chart */}
          <div className="bg-[#09060F] border border-white/10 rounded-xl p-4 overflow-x-auto">
            <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-[#7E7494] mb-2">
              <span>
                Showing Bar 1 to {visibleBarIndex + 1} of {scenario.candles.length} (Historical
                Educational Data)
              </span>
              <span className="text-[#D4AF37]">{scenario.keyLevelLabel}</span>
            </div>

            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-auto min-w-[540px]"
              role="img"
              aria-label={`Candlestick replay chart for ${scenario.title}`}
            >
              {/* Horizontal Key Level Line */}
              <line
                x1={20}
                x2={chartWidth - 105}
                y1={priceToY(scenario.keyLevelPrice)}
                y2={priceToY(scenario.keyLevelPrice)}
                stroke="#D4AF37"
                strokeWidth={1.5}
                strokeDasharray="6 4"
              />
              <text
                x={chartWidth - 100}
                y={priceToY(scenario.keyLevelPrice) + 4}
                fill="#D4AF37"
                fontSize="10"
                fontFamily="monospace"
              >
                KEY {scenario.keyLevelPrice.toFixed(decimals)}
              </text>

              {/* Entry Line */}
              {chartEntryLine !== undefined && (
                <>
                  <line
                    x1={20}
                    x2={chartWidth - 105}
                    y1={priceToY(chartEntryLine)}
                    y2={priceToY(chartEntryLine)}
                    stroke="#A882DD"
                    strokeWidth={1.3}
                  />
                  <text
                    x={chartWidth - 100}
                    y={priceToY(chartEntryLine) + 4}
                    fill="#A882DD"
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    ENTRY {chartEntryLine.toFixed(decimals)}
                  </text>
                </>
              )}

              {/* Stop-Loss Line */}
              {chartSlLine !== undefined && (
                <>
                  <line
                    x1={20}
                    x2={chartWidth - 105}
                    y1={priceToY(chartSlLine)}
                    y2={priceToY(chartSlLine)}
                    stroke="#EF4444"
                    strokeWidth={1.5}
                    strokeDasharray="3 3"
                  />
                  <text
                    x={chartWidth - 100}
                    y={priceToY(chartSlLine) + 4}
                    fill="#EF4444"
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    SL {chartSlLine.toFixed(decimals)}
                  </text>
                </>
              )}

              {/* Take-Profit Line */}
              {chartTpLine !== undefined && (
                <>
                  <line
                    x1={20}
                    x2={chartWidth - 105}
                    y1={priceToY(chartTpLine)}
                    y2={priceToY(chartTpLine)}
                    stroke="#10B981"
                    strokeWidth={1.5}
                    strokeDasharray="3 3"
                  />
                  <text
                    x={chartWidth - 100}
                    y={priceToY(chartTpLine) + 4}
                    fill="#10B981"
                    fontSize="10"
                    fontFamily="monospace"
                  >
                    TP {chartTpLine.toFixed(decimals)}
                  </text>
                </>
              )}

              {/* Candlesticks */}
              {visibleCandles.map((candle, idx) => {
                const slotWidth = (chartWidth - 135) / scenario.candles.length;
                const centerX = 45 + idx * slotWidth;
                const isBull = candle.close >= candle.open;
                const color = isBull ? '#10B981' : '#EF4444';
                const highY = priceToY(candle.high);
                const lowY = priceToY(candle.low);
                const openY = priceToY(candle.open);
                const closeY = priceToY(candle.close);
                const bodyTop = Math.min(openY, closeY);
                const bodyHeight = Math.max(3, Math.abs(closeY - openY));
                const isDecisionBar = idx === scenario.decisionBarIndex;

                return (
                  <g key={candle.index}>
                    {isDecisionBar && (
                      <rect
                        x={centerX - 18}
                        y={12}
                        width={36}
                        height={chartHeight - 28}
                        fill="rgba(212, 175, 55, 0.08)"
                        stroke="rgba(212, 175, 55, 0.35)"
                        strokeDasharray="2 2"
                        rx={4}
                      />
                    )}
                    <line
                      x1={centerX}
                      x2={centerX}
                      y1={highY}
                      y2={lowY}
                      stroke={color}
                      strokeWidth={2}
                    />
                    <rect
                      x={centerX - 11}
                      y={bodyTop}
                      width={22}
                      height={bodyHeight}
                      fill={color}
                      rx={2}
                    />
                    <text
                      x={centerX}
                      y={chartHeight - 4}
                      textAnchor="middle"
                      fill={isDecisionBar ? '#D4AF37' : '#7E7494'}
                      fontSize="10"
                      fontFamily="monospace"
                    >
                      {candle.timeLabel}
                    </text>
                  </g>
                );
              })}
            </svg>

            {/* Latest Visible Bar Annotation */}
            <div className="mt-3 pt-3 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
              <span className="text-[#F3E5AB]">
                Bar {visibleBarIndex + 1} ({visibleCandles[visibleCandles.length - 1].timeLabel}):{' '}
                {visibleCandles[visibleCandles.length - 1].annotation}
              </span>
              <span className="text-[#7E7494]">
                Close: {visibleCandles[visibleCandles.length - 1].close.toFixed(decimals)}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Interactive Decision & SL/TP Execution Deck */}
        <div className="lg:col-span-5 space-y-5">
          {/* Mode Switcher */}
          <div className="jgs-panel p-5 space-y-4">
            <div className="flex items-center justify-between gap-2 border-b border-white/10 pb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37] font-semibold">
                EXECUTION TERMINAL ({scenario.instrument})
              </span>
              <div className="inline-flex rounded-lg bg-[#09060F] p-1 border border-white/10 text-[11px] font-mono">
                <button
                  type="button"
                  onClick={() => setExecutionMode('CUSTOM_ORDER')}
                  className={`px-2.5 py-1 rounded ${
                    executionMode === 'CUSTOM_ORDER'
                      ? 'bg-[#D4AF37] text-[#09060F] font-bold'
                      : 'text-[#B8B0C8]'
                  }`}
                >
                  Custom SL/TP Builder
                </button>
                <button
                  type="button"
                  onClick={() => setExecutionMode('CURATED_OPTIONS')}
                  className={`px-2.5 py-1 rounded ${
                    executionMode === 'CURATED_OPTIONS'
                      ? 'bg-[#D4AF37] text-[#09060F] font-bold'
                      : 'text-[#B8B0C8]'
                  }`}
                >
                  Scenario Presets
                </button>
              </div>
            </div>

            {executionMode === 'CUSTOM_ORDER' ? (
              <div className="space-y-4">
                {/* 1. BUY / SELL / WAIT Decision Selector */}
                <div>
                  <label className="jgs-label">
                    1. Select Decision at {decisionCandle.timeLabel} ({entryPrice.toFixed(decimals)})
                  </label>
                  <div className="grid grid-cols-3 gap-2.5">
                    <button
                      type="button"
                      onClick={() => handleActionChange('BUY')}
                      className={`p-3 rounded-xl border font-mono text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                        customAction === 'BUY'
                          ? 'bg-[#0F1B1D] border-[#10B981] text-[#10B981]'
                          : 'bg-[#09060F] border-white/10 text-[#B8B0C8] hover:border-white/25'
                      }`}
                    >
                      <TrendingUp className="w-4 h-4" />
                      <span>BUY (LONG)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleActionChange('SELL')}
                      className={`p-3 rounded-xl border font-mono text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                        customAction === 'SELL'
                          ? 'bg-[#1A0D16] border-[#EF4444] text-[#EF4444]'
                          : 'bg-[#09060F] border-white/10 text-[#B8B0C8] hover:border-white/25'
                      }`}
                    >
                      <TrendingDown className="w-4 h-4" />
                      <span>SELL (SHORT)</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => handleActionChange('WAIT')}
                      className={`p-3 rounded-xl border font-mono text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                        customAction === 'WAIT'
                          ? 'bg-[#191129] border-[#D4AF37] text-[#D4AF37]'
                          : 'bg-[#09060F] border-white/10 text-[#B8B0C8] hover:border-white/25'
                      }`}
                    >
                      <PauseCircle className="w-4 h-4" />
                      <span>WAIT (PASS)</span>
                    </button>
                  </div>
                </div>

                {/* 2. Stop-Loss & Take-Profit Selection (when BUY or SELL) */}
                {customAction !== 'WAIT' && (
                  <div className="space-y-3.5 p-4 rounded-xl bg-[#09060F] border border-white/10">
                    <div className="flex items-center justify-between">
                      <span className="text-xs font-mono uppercase text-[#F3E5AB] font-semibold flex items-center gap-1.5">
                        <Sliders className="w-3.5 h-3.5 text-[#D4AF37]" />
                        2. Select Stop-Loss & Take-Profit
                      </span>
                      <span className="text-xs font-mono text-[#D4AF37]">
                        Planned R:R = 1:{customSimResult.plannedRewardToRisk}
                      </span>
                    </div>

                    {/* Quick R:R Geometry Buttons */}
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[10px] font-mono text-[#7E7494]">Quick Levels:</span>
                      <button
                        type="button"
                        onClick={() => applyQuickRrPreset(1.5, false)}
                        className="px-2 py-1 rounded bg-[#191129] border border-white/10 text-[11px] font-mono text-[#F3E5AB] hover:border-[#D4AF37]"
                      >
                        1:1.5 R:R
                      </button>
                      <button
                        type="button"
                        onClick={() => applyQuickRrPreset(2.0, false)}
                        className="px-2 py-1 rounded bg-[#191129] border border-white/10 text-[11px] font-mono text-[#10B981] hover:border-[#10B981]"
                      >
                        1:2.0 Structural
                      </button>
                      <button
                        type="button"
                        onClick={() => applyQuickRrPreset(2.5, false)}
                        className="px-2 py-1 rounded bg-[#191129] border border-white/10 text-[11px] font-mono text-[#D4AF37] hover:border-[#D4AF37]"
                      >
                        1:2.5 Asymmetric
                      </button>
                      <button
                        type="button"
                        onClick={() => applyQuickRrPreset(2.0, true)}
                        className="px-2 py-1 rounded bg-[#1A0D16] border border-[#EF4444]/40 text-[11px] font-mono text-[#EF4444]"
                      >
                        Tight Stop Trap
                      </button>
                    </div>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label htmlFor="pg-sl-input" className="jgs-label text-[#EF4444]">
                          Stop-Loss Price
                        </label>
                        <input
                          id="pg-sl-input"
                          type="number"
                          step={scenario.instrument === 'XAUUSD' ? 0.1 : 0.0001}
                          value={customStopLoss}
                          onChange={(e) => {
                            setCustomStopLoss(Number(e.target.value));
                            setHasExecutedCustom(false);
                          }}
                          className="jgs-input border-[#EF4444]/40"
                        />
                        <div className="text-[10px] font-mono text-[#7E7494] mt-1">
                          Distance: {customSimResult.stopLossPoints} pts
                        </div>
                      </div>

                      <div>
                        <label htmlFor="pg-tp-input" className="jgs-label text-[#10B981]">
                          Take-Profit Price
                        </label>
                        <input
                          id="pg-tp-input"
                          type="number"
                          step={scenario.instrument === 'XAUUSD' ? 0.1 : 0.0001}
                          value={customTakeProfit}
                          onChange={(e) => {
                            setCustomTakeProfit(Number(e.target.value));
                            setHasExecutedCustom(false);
                          }}
                          className="jgs-input border-[#10B981]/40"
                        />
                        <div className="text-[10px] font-mono text-[#7E7494] mt-1">
                          Target: {customSimResult.takeProfitPoints} pts
                        </div>
                      </div>
                    </div>

                    {/* Cent Account Equity & Risk % */}
                    <div className="grid grid-cols-2 gap-3 pt-1 border-t border-white/10">
                      <div>
                        <label htmlFor="pg-equity-usc" className="jgs-label">
                          Cent Equity (USC)
                        </label>
                        <input
                          id="pg-equity-usc"
                          type="number"
                          min={500}
                          step={500}
                          value={customEquityUsc}
                          onChange={(e) => setCustomEquityUsc(Number(e.target.value))}
                          className="jgs-input"
                        />
                      </div>
                      <div>
                        <label htmlFor="pg-risk-pct" className="jgs-label">
                          Risk Per Trade (%)
                        </label>
                        <input
                          id="pg-risk-pct"
                          type="number"
                          min={0.25}
                          max={10}
                          step={0.25}
                          value={customRiskPercent}
                          onChange={(e) => setCustomRiskPercent(Number(e.target.value))}
                          className="jgs-input"
                        />
                      </div>
                    </div>
                  </div>
                )}

                {/* Validation Error Banner (if SL/TP invalid for chosen direction) */}
                {!customSimResult.isValidConfiguration && customSimResult.validationError && (
                  <div className="p-3.5 rounded-xl bg-[#1A0D16] border border-[#EF4444] text-xs font-mono text-[#EF4444] flex items-start gap-2">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{customSimResult.validationError}</span>
                  </div>
                )}

                <button
                  type="button"
                  disabled={!customSimResult.isValidConfiguration}
                  onClick={handleRunCustomSimulation}
                  className="jgs-btn-gold w-full text-xs py-3 disabled:opacity-40"
                >
                  <Play className="w-4 h-4" />
                  <span>
                    Execute {customAction} Decision & Replay Outcome →
                  </span>
                </button>
              </div>
            ) : (
              /* Curated Scenario Options */
              <div className="space-y-3">
                <p className="text-xs text-[#B8B0C8]">
                  Or select one of the 3 pre-built execution templates to compare $25 Standard vs.
                  2,500 USC Cent outcomes:
                </p>
                {scenario.options.map((opt) => {
                  const isSelected = chosenOptionId === opt.id;
                  return (
                    <button
                      key={opt.id}
                      type="button"
                      onClick={() => handleExecuteCuratedOption(opt)}
                      className={`w-full text-left p-4 rounded-xl border transition-all ${
                        isSelected
                          ? opt.isOptimalChoice
                            ? 'bg-[#0F1B1D] border-[#10B981] text-[#F7F4EE]'
                            : 'bg-[#1A0D16] border-[#F59E0B] text-[#F7F4EE]'
                          : 'bg-[#09060F] border-white/10 text-[#B8B0C8] hover:border-[#D4AF37]/50'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="font-display font-bold text-sm text-[#F7F4EE]">
                          {opt.label}
                        </span>
                        <Play className="w-3.5 h-3.5 text-[#D4AF37] shrink-0" />
                      </div>
                      <div className="text-xs font-mono text-[#B8B0C8] mt-1">{opt.subtitle}</div>
                    </button>
                  );
                })}
              </div>
            )}
          </div>

          {/* =================================================================
              DECISION QUALITY FEEDBACK CARD (FOR CUSTOM ORDER EXECUTION)
          ================================================================= */}
          {executionMode === 'CUSTOM_ORDER' && hasExecutedCustom && (
            <div className="jgs-panel p-6 border-[#D4AF37]/50 space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <Award className="w-4 h-4 text-[#D4AF37]" />
                  <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37] font-semibold">
                    DECISION QUALITY FEEDBACK & OUTCOME
                  </span>
                </div>
                <span
                  className={`px-2.5 py-1 rounded text-xs font-mono font-bold ${
                    customSimResult.decisionQualityScore >= 80
                      ? 'bg-[#10B981]/20 text-[#10B981]'
                      : customSimResult.decisionQualityScore >= 65
                        ? 'bg-[#D4AF37]/20 text-[#D4AF37]'
                        : 'bg-[#EF4444]/20 text-[#EF4444]'
                  }`}
                >
                  {customSimResult.decisionGrade} ({customSimResult.decisionQualityScore}/100)
                </span>
              </div>

              {/* Outcome Headline & Explanation */}
              <div className="p-4 rounded-xl bg-[#09060F] border border-white/10 space-y-2">
                <div
                  className={`font-mono text-sm font-bold ${
                    customSimResult.realizedRMultiple > 0 ||
                    customSimResult.outcomeType === 'WAITED_DISCIPLINED'
                      ? 'text-[#10B981]'
                      : customSimResult.realizedRMultiple < 0
                        ? 'text-[#EF4444]'
                        : 'text-[#F3E5AB]'
                  }`}
                >
                  {customSimResult.outcomeHeadline}
                </div>
                <p className="text-xs text-[#B8B0C8] leading-relaxed">
                  {customSimResult.outcomeExplanation}
                </p>

                {customSimResult.sizingResult && customSimResult.sizingResult.approvedLotSize && (
                  <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-[#F3E5AB]">
                    <span>
                      Sized Volume: {customSimResult.sizingResult.approvedLotSize.toFixed(2)} Cent
                      Lots
                    </span>
                    <span>
                      Risked: {customSimResult.sizingResult.actualRiskAmount?.toFixed(2)} USC (
                      {customSimResult.sizingResult.actualRiskPercentage}%)
                    </span>
                  </div>
                )}
              </div>

              {/* 4-Factor Decision Quality Breakdown Bars */}
              <div className="space-y-2.5 font-mono text-xs">
                <div className="text-[11px] uppercase text-[#7E7494]">
                  4-Factor Decision Quality Audit:
                </div>
                {[
                  {
                    label: 'Directional Read & Market Structure',
                    score: customSimResult.qualityBreakdown.directionScore,
                    max: 30
                  },
                  {
                    label: 'Stop-Loss Placement Outside Noise',
                    score: customSimResult.qualityBreakdown.stopPlacementScore,
                    max: 25
                  },
                  {
                    label: 'Reward-to-Risk Asymmetry (R:R)',
                    score: customSimResult.qualityBreakdown.asymmetryScore,
                    max: 25
                  },
                  {
                    label: 'Cent Risk Cap Compliance (<= 1.5%)',
                    score: customSimResult.qualityBreakdown.sizingComplianceScore,
                    max: 20
                  }
                ].map((factor) => {
                  const pct = Math.round((factor.score / factor.max) * 100);
                  return (
                    <div key={factor.label} className="space-y-1">
                      <div className="flex justify-between text-[11px]">
                        <span className="text-[#B8B0C8]">{factor.label}</span>
                        <span className="text-[#F3E5AB]">
                          {factor.score}/{factor.max} pts
                        </span>
                      </div>
                      <div className="w-full h-1.5 rounded-full bg-[#09060F] overflow-hidden">
                        <div
                          className="h-full bg-[#D4AF37]"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })}
              </div>

              <JeyStrategistCallout
                title="JEY'S DECISION QUALITY COACHING"
                ruleText={customSimResult.jeyCoachingFeedback}
                contextTag={`${scenario.code} • ${customSimResult.decisionGrade}`}
              />
            </div>
          )}

          {/* =================================================================
              CURATED OPTION OUTCOME CARD
          ================================================================= */}
          {executionMode === 'CURATED_OPTIONS' && chosenOption && (
            <div className="jgs-panel p-6 border-[#D4AF37]/40 space-y-5">
              <div className="flex items-center justify-between gap-2 pb-3 border-b border-white/10">
                <span className="text-xs font-mono uppercase tracking-wider text-[#D4AF37] font-semibold">
                  SCENARIO OUTCOME & ACCOUNT COMPARISON
                </span>
                {chosenOption.isOptimalChoice ? (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-[#10B981]/20 text-[#10B981] text-xs font-mono font-bold">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    OPTIMAL STRATEGY
                  </span>
                ) : (
                  <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded bg-[#F59E0B]/20 text-[#F59E0B] text-xs font-mono font-bold">
                    <AlertTriangle className="w-3.5 h-3.5" />
                    SUB-OPTIMAL / RISK LESSON
                  </span>
                )}
              </div>

              <div className="grid grid-cols-1 gap-3 font-mono text-xs">
                <div className="p-3.5 rounded-xl bg-[#1A0D16] border border-[#EF4444]/35 space-y-1">
                  <div className="text-[#EF4444] font-bold uppercase">
                    On a $25 Standard Account ({chosenOption.standard25UsdOutcome.lotSize})
                  </div>
                  <div className="text-sm font-bold text-[#F7F4EE]">
                    Result: {chosenOption.standard25UsdOutcome.resultUsd}
                  </div>
                  <p className="text-[#B8B0C8] font-sans">
                    {chosenOption.standard25UsdOutcome.accountImpactSummary}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-[#0F1B1D] border border-[#10B981]/35 space-y-1">
                  <div className="text-[#10B981] font-bold uppercase">
                    On a 2,500 USC Cent Account ({chosenOption.cent2500UscOutcome.lotSize})
                  </div>
                  <div className="text-sm font-bold text-[#F7F4EE]">
                    Result: {chosenOption.cent2500UscOutcome.resultUsc} (
                    {chosenOption.cent2500UscOutcome.resultR})
                  </div>
                  <p className="text-[#B8B0C8] font-sans">
                    {chosenOption.cent2500UscOutcome.accountImpactSummary}
                  </p>
                </div>
              </div>

              <JeyStrategistCallout
                title="JEY'S POST-SCENARIO DEBRIEF"
                ruleText={chosenOption.jeyDebrief}
                contextTag={scenario.code}
              />
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
